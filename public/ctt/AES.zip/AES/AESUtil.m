//
//  AESUtil.m
//  TestAES
//
//  Created by vin on 2018/4/10.
//  Copyright © 2018年 vin. All rights reserved.
//

#import "AESUtil.h"

@implementation AESUtil

+ (void)testAES
{
    NSString* skey = @"0123456789abcdef";
    NSString* sin = @"0123456789abcdefghijklmnopqrst";
    
    NSData* encodeData = [self aesEncrypt:sin andKey:skey];
    
    NSString* decodeStr = [self aesDecrypt:encodeData andKey:skey];
    
    NSLog(@">>>>%@", decodeStr);
}

+ (NSData*)aesEncrypt:(NSString*)input andKey:(NSString*)key
{
    unsigned char aesKeyBuffer[64] = { 0 };
    memcpy(aesKeyBuffer, (uint8*)[key cStringUsingEncoding:NSUTF8StringEncoding], (int)key.length);
    aes_context aesCtx;
    aes_set_key(&aesCtx, aesKeyBuffer, 256);
    //
    NSUInteger len = input.length;
    NSUInteger len1 = (len/16 + 1) * 16;
    
    Byte* bin1 = malloc(len1 * sizeof(Byte));
    for (int i = 0; i < len1; ++i) {
        if (i < len)
            bin1[i] = [input characterAtIndex:i];
        else
            bin1[i] = 0;
    }
    
    
    Byte* output = malloc(len1 * sizeof(Byte));
    Byte sbin[16];
    Byte sbout[16];
    for (int i = 0; i < len1/16; ++i) {
        for (int j=0; j<16; ++j){
            sbin[j] = bin1[i*16+j];
        }
        
        aes_encrypt( &aesCtx, sbin, sbout );
        
        for (int j = 0; j < 16; ++j) {
            output[i*16+j] = sbout[j];
        }
    }
    
    
    for (int i = 0; i < len1; ++i) {
        printf("0x%02x ", output[i]);
    }
    printf("%c%c", '\n', '\n');
    
    return [[NSData alloc] initWithBytes:output length:len1];
}

+ (NSString*)aesDecrypt:(NSData*)input andKey:(NSString*)key
{
    unsigned char aesKeyBuffer[64] = { 0 };
    memcpy(aesKeyBuffer, (uint8*)[key cStringUsingEncoding:NSUTF8StringEncoding], (int)key.length);
    aes_context aesCtx;
    aes_set_key(&aesCtx, aesKeyBuffer, 256);
    //
    NSUInteger len1 = input.length;
    
    Byte* intput1 = malloc(len1 * sizeof(Byte));
    memcpy(intput1, input.bytes, len1);
    Byte* output = malloc(len1 * sizeof(Byte));
    Byte sbin[16];
    Byte sbout[16];
    for (int i = 0; i < len1/16; ++i) {
        for (int j = 0; j < 16; ++j){
            sbin[j] = intput1[i*16+j];
        }
        
        aes_decrypt( &aesCtx, sbin, sbout );
        
        for (int j = 0; j < 16; ++j) {
            output[i*16+j] = sbout[j];
        }
    }
    
    for (int i = 0; i < len1; ++i) {
        printf("0x%02x ", output[i]);
    }
    printf("%c%c", '\n', '\n');
    
    return [[NSString alloc] initWithBytes:output length:len1 encoding:NSUTF8StringEncoding];
}

@end
