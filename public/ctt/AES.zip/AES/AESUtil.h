//
//  AESUtil.h
//  TestAES
//
//  Created by vin on 2018/4/10.
//  Copyright © 2018年 vin. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "aes.h"

@interface AESUtil : NSObject

+ (NSData*)aesEncrypt:(NSString*)input andKey:(NSString*)key;
+ (NSString*)aesDecrypt:(NSData*)input andKey:(NSString*)key;

//
+ (void)testAES;

@end
