#include <stdio.h>
#include <SDL2/SDL.h>

//gcc tinygame.c -o tinygame -framework SDL2

int globalTime = 0;

typedef struct{
    float x, y, dy;
    int aindex;
    SDL_Texture* manTex;
    int faceLeft;//1:朝左 0:朝右
    int isWalk;//1:在移动 0:没有移动
    int alive;//1:活着 0:死亡
    int visible;//1:显示 0:不显示
} Man;

SDL_Texture* bgTex;

SDL_Texture* bulletTex;
typedef struct{
    float x, y, dx;
    SDL_Texture* btTex;
    int visible;//1:显示 0:不显示
} Bullet;
Bullet *bullets[1000] = { NULL };

Man* enemy;//敌人

void addBullet(float x, float y, float dx) {
    for(int i = 0; i < 1000; i++) {
        if(bullets[i] == NULL) {
            bullets[i] = malloc(sizeof(Bullet));
            bullets[i]->x = x;
            bullets[i]->y = y;
            bullets[i]->dx = dx;
            bullets[i]->btTex = bulletTex;
            bullets[i]->visible = 1;
            break;
        }
    }
}

void subBullet(int i) {
    if(bullets[i]) {
        free(bullets[i]);
        bullets[i] = NULL;
    }
}

SDL_Texture* createTex(SDL_Renderer* render, char* filename)
{
    SDL_Texture* tempTex;
    SDL_Surface *sfa = SDL_LoadBMP(filename);
    if(!sfa){
        return NULL;
    }
    tempTex = SDL_CreateTextureFromSurface(render, sfa);
    SDL_FreeSurface(sfa);
    
    return tempTex;
}

void updateManState(Man* man)
{
    const Uint8 *state = SDL_GetKeyboardState(NULL);
    if(state[SDL_SCANCODE_LEFT]){
        man->x -= 3;
        man->faceLeft = 1;
        man->isWalk = 1;
        
        if(globalTime % 6 == 0){
            man->aindex++;
            man->aindex %= 4;
        }
        
    } else if(state[SDL_SCANCODE_RIGHT]) {
        man->x += 3;
        man->faceLeft = 0;
        man->isWalk = 1;
        
        if(globalTime % 6 == 0){
            man->aindex++;
            man->aindex %= 4;
        }
        
    } else if(state[SDL_SCANCODE_UP] && man->y == 60) {
        man->dy = -8;//跳跃
        man->isWalk = 0;
    } else if(state[SDL_SCANCODE_SPACE] && man->isWalk == 0) {
        //射击
        if(globalTime % 6 == 0) {
            //射击角色动画
            if (man->aindex == 4) {
                man->aindex = 5;
            }else{
                man->aindex = 4;
            }
            //添加子弹
            if (man->faceLeft == 0) {
                addBullet(man->x+35, man->y+20, 3);
            }else{
                addBullet(man->x+5, man->y+20, -3);
            }
        }
    } else {
        man->aindex = 4;
        man->isWalk = 0;
    }
}

int handleEvents(SDL_Window* window, Man* man)
{
    SDL_Event event;
    int done = 0;
    
    while(SDL_PollEvent(&event)){
        switch(event.type){
            case SDL_WINDOWEVENT_CLOSE:{
                if(window){
                    SDL_DestroyWindow(window);
                    window = NULL;
                    done = 1;
                }
            }
                break;
            case SDL_KEYDOWN:{
                switch(event.key.keysym.sym){
                    case SDLK_ESCAPE:
                        done = 1;
                        break;
                }
            }
                break;
            case SDL_QUIT:
                //quit out of the game
                done = 1;
                break;
        }
    }
    
    updateManState(man);

    return done;
}

void handleLogic(Man* man)
{
    //实现跳跃
    man->y += man->dy;
    man->dy += 0.5;
    if (man->y > 60) {
        man->y = 60;//落到地面
        man->dy = 0;
    }
    
    //修改子弹的位置
    for(int i = 0; i < 1000; i++) if(bullets[i]) {
        bullets[i]->x += bullets[i]->dx;
        
        //简单子弹跟敌人的碰撞检测
        if (enemy->alive == 1) {
            if(bullets[i]->x > enemy->x && bullets[i]->x < enemy->x+40 &&
               bullets[i]->y > enemy->y && bullets[i]->y < enemy->y+50){
                enemy->alive = 0;//击中死亡
                bullets[i]->visible = 0;
            }
        }
        
        if(bullets[i]->x < -1000 || bullets[i]->x > 1000 || bullets[i]->visible == 0) {
            subBullet(i);//超出屏幕外就要移除掉子弹
        }
    }
    
    //实现敌人的死亡动画
    if(enemy->alive == 0 && globalTime % 6 == 0) {
        if(enemy->aindex < 6) {
            enemy->aindex = 6;
        } else if(enemy->aindex >= 6) {
            enemy->aindex++;
            if(enemy->aindex > 7) {
                enemy->visible = 0;
                enemy->aindex = 7;
            }
        }
    }
    
    //更新时间
    globalTime++;
}

void handleRender(SDL_Renderer* render, Man* man)
{
    SDL_SetRenderDrawColor(render, 0, 0, 255, 255);
    SDL_RenderClear(render);
    SDL_SetRenderDrawColor(render, 255, 255, 255, 255);
    
    //渲染背景和主角
    SDL_RenderCopy(render, bgTex, NULL, NULL);
    SDL_Rect srcRect = { 40*man->aindex, 0, 40, 50 };
    SDL_Rect rect = { man->x, man->y, 40, 50 };
    SDL_RenderCopyEx(render, man->manTex, &srcRect, &rect, 0, NULL, man->faceLeft);
    
    //渲染敌人
    if (enemy->visible) {
        SDL_Rect eSrcRect = { 40*enemy->aindex, 0, 40, 50 };
        SDL_Rect eRect = { enemy->x, enemy->y, 40, 50 };
        SDL_RenderCopyEx(render, enemy->manTex, &eSrcRect, &eRect, 0, NULL, enemy->faceLeft);
    }
    
    //渲染子弹
    for(int i = 0; i < 1000; i++) if(bullets[i]) {
        SDL_Rect rect = { bullets[i]->x, bullets[i]->y, 8, 8 };
        SDL_RenderCopy(render, bullets[i]->btTex, NULL, &rect);
    }
    
    SDL_RenderPresent(render);
}

int main(int argc, char** argv)
{
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Window* window = SDL_CreateWindow("Game Test", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 640, 480, 0);
    SDL_Renderer* render = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    SDL_RenderSetLogicalSize(render, 320, 240);
    
    bgTex = createTex(render, "bg.bmp");
    if (!bgTex) {
        printf("Cannot find bg bmp\n");
        return 1;
    }
    
    Man man;
    man.x = 50;
    man.y = 60;
    man.aindex = 4;
    man.faceLeft = 0;
    man.isWalk = 0;
    man.alive = 1;
    man.visible = 1;
    man.manTex = createTex(render, "man_sheet.bmp");
    if (!man.manTex) {
        printf("Cannot find man bmp\n");
        return 1;
    }
    
    Man enemy_man;
    enemy = &enemy_man;
    enemy_man.x = 250;
    enemy_man.y = 60;
    enemy_man.aindex = 4;
    enemy_man.faceLeft = 1;
    enemy_man.isWalk = 0;
    enemy_man.alive = 1;
    enemy_man.visible = 1;
    enemy_man.manTex = createTex(render, "enemy_sheet.bmp");
    if (!enemy_man.manTex) {
        printf("Cannot find enemy bmp\n");
        return 1;
    }
    
    bulletTex = createTex(render, "bullet.bmp");
    if (!bulletTex) {
        printf("Cannot find bullet bmp\n");
        return 1;
    }
    
    int done = 0;
    while(!done){
        
        done = handleEvents(window, &man);
        
        handleLogic(&man);
        
        handleRender(render, &man);
        
        SDL_Delay(10);
    }
    
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(render);
    SDL_DestroyTexture(bgTex);
    SDL_DestroyTexture(man.manTex);
    SDL_DestroyTexture(bulletTex);
    SDL_DestroyTexture(enemy_man.manTex);
    
    for(int i = 0; i < 1000; i++) {
        subBullet(i);
    }
    
    SDL_Quit();
    
    return 0;
}
