//
//  ViewController.m
//  TestNetworkReachability
//
//  Created by arvin on 2017/12/14.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import "ViewController.h"

#import "NKReachability.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self testReachability];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)testReachability
{
    [[NKReachability sharedManager] startMonitoring];
    [[NKReachability sharedManager] setReachabilityStatusChangeBlock:^(NKReachabilityStatus status)
    {
        switch (status) {
                
            case NKReachabilityStatusUnknown:
                NSLog(@"%@", @"Network Unknown!");
                break;
            case NKReachabilityStatusNotReachable:
                NSLog(@"%@", @"Network Not Reachable!");
                break;
            case NKReachabilityStatusReachableViaWWAN:
                NSLog(@"%@", @"Network Via WWAN!");
                break;
            case NKReachabilityStatusReachableViaWiFi:
                NSLog(@"%@", @"Network Via WiFi!");
                break;
            default:
                NSLog(@"%@", @"未知错误!");
                break;
        }
    }];
}


@end
