//
//  NKReachability.h
//  TestNetworkReachability
//
//  Created by arvin on 2017/12/14.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import <Foundation/Foundation.h>

#if !TARGET_OS_WATCH
#import <SystemConfiguration/SystemConfiguration.h>

typedef NS_ENUM(NSInteger, NKReachabilityStatus) {
    NKReachabilityStatusUnknown          = -1,
    NKReachabilityStatusNotReachable     = 0,
    NKReachabilityStatusReachableViaWWAN = 1,
    NKReachabilityStatusReachableViaWiFi = 2,
};

NS_ASSUME_NONNULL_BEGIN

@interface NKReachability : NSObject

@property (readonly, nonatomic, assign) NKReachabilityStatus networkReachabilityStatus;

@property (readonly, nonatomic, assign, getter = isReachable) BOOL reachable;

@property (readonly, nonatomic, assign, getter = isReachableViaWWAN) BOOL reachableViaWWAN;

@property (readonly, nonatomic, assign, getter = isReachableViaWiFi) BOOL reachableViaWiFi;

+ (instancetype)sharedManager;

+ (instancetype)managerForAddress:(const void *)address;

+ (instancetype)managerForDomain:(NSString *)domain;

- (instancetype)initWithReachability:(SCNetworkReachabilityRef)reachability NS_DESIGNATED_INITIALIZER;

- (nullable instancetype)init NS_UNAVAILABLE;

- (void)startMonitoring;

- (void)stopMonitoring;

- (void)setReachabilityStatusChangeBlock:(nullable void (^)(NKReachabilityStatus status))block;

@end

NS_ASSUME_NONNULL_END

#endif
