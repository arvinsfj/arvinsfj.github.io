//
//  NKReachability.m
//  TestNetworkReachability
//
//  Created by arvin on 2017/12/14.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import "NKReachability.h"

#if !TARGET_OS_WATCH

#import <netinet/in.h>
#import <netinet6/in6.h>
#import <arpa/inet.h>
#import <ifaddrs.h>
#import <netdb.h>

typedef void (^NKReachabilityStatusBlock)(NKReachabilityStatus status);

//私有方法
static NKReachabilityStatus NKReachabilityStatusForFlags(SCNetworkReachabilityFlags flags)
{
    BOOL isReachable = ((flags & kSCNetworkReachabilityFlagsReachable) != 0);
    BOOL needConn = ((flags & kSCNetworkReachabilityFlagsConnectionRequired) != 0);
    BOOL canAutoConn = (((flags & kSCNetworkReachabilityFlagsConnectionOnDemand) != 0) || ((flags & kSCNetworkReachabilityFlagsConnectionOnTraffic) != 0));
    BOOL canConnWithoutUserInteraction = (canAutoConn && ((flags & kSCNetworkReachabilityFlagsInterventionRequired) == 0));
    BOOL isNetworkReachable = (isReachable && (!needConn || canConnWithoutUserInteraction));
    
    NKReachabilityStatus status = NKReachabilityStatusUnknown;
    if (!isNetworkReachable) {
        status = NKReachabilityStatusNotReachable;
    }
#if TARGET_OS_IPHONE
    else if ((flags & kSCNetworkReachabilityFlagsIsWWAN) != 0) {
        status = NKReachabilityStatusReachableViaWWAN;//电信蜂窝网络
    }
#endif
    else {
        status = NKReachabilityStatusReachableViaWiFi;//本地WiFi
    }
    
    return status;
}

//网络状态消息发送方法
static void NKPostReachabilityStatusChange(SCNetworkReachabilityFlags flags, NKReachabilityStatusBlock block)
{
    NKReachabilityStatus status = NKReachabilityStatusForFlags(flags);
    dispatch_async(dispatch_get_main_queue(), ^{
        //主线程发送消息
        if (block) {
            block(status);
        }
    });
}

//网络状态回调方法
static void NKReachabilityCallback(SCNetworkReachabilityRef __unused target, SCNetworkReachabilityFlags flags, void* info)
{
    NKPostReachabilityStatusChange(flags, (__bridge NKReachabilityStatusBlock)(info));
}

static const void* NKReachabilityRetainCallback(const void* info)
{
    return Block_copy(info);
}

static void NKReachabilityReleaseCallback(const void* info)
{
    return Block_release(info);
}
//网络状态回调方法结束

@interface NKReachability ()

@property (readonly, nonatomic, assign) SCNetworkReachabilityRef networkReachability;
@property (readwrite, nonatomic, assign) NKReachabilityStatus networkReachabilityStatus;
@property (readwrite, nonatomic, copy) NKReachabilityStatusBlock networkReachabilityStatusBlock;

@end

@implementation NKReachability

+ (instancetype)sharedManager
{
    static NKReachability* _shareInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _shareInstance = [self manager];
    });
    
    return _shareInstance;
}

+ (instancetype)manager
{
#if (defined(__IPHONE_OS_VERSION_MIN_REQUIRED) && __IPHONE_OS_VERSION_MIN_REQUIRED >= 90000) || (defined(__MAC_OS_X_VERSION_MIN_REQUIRED) && __MAC_OS_X_VERSION_MIN_REQUIRED >= 101100)
    struct sockaddr_in6 address;
    bzero(&address, sizeof(address));
    address.sin6_len = sizeof(address);
    address.sin6_family = AF_INET6;
#else
    struct sockaddr_in address;
    bzero(&address, sizeof(address));
    address.sin_len = sizeof(address);
    address.sin_family = AF_INET;
#endif
    return [self managerForAddress:&address];
}

+ (instancetype)managerForAddress:(const void *)address
{
    SCNetworkReachabilityRef reachability = SCNetworkReachabilityCreateWithAddress(kCFAllocatorDefault, (const struct sockaddr *)address);
    NKReachability *manager = [[self alloc] initWithReachability:reachability];
    CFRelease(reachability);
    
    return manager;
}

+ (instancetype)managerForDomain:(NSString *)domain
{
    SCNetworkReachabilityRef reachability = SCNetworkReachabilityCreateWithName(kCFAllocatorDefault, [domain UTF8String]);
    NKReachability* manager = [[self alloc] initWithReachability:reachability];
    CFRelease(reachability);
    
    return manager;
}

- (instancetype)initWithReachability:(SCNetworkReachabilityRef)reachability
{
    if (self = [super init]) {
        _networkReachability = CFRetain(reachability);
        _networkReachabilityStatus = NKReachabilityStatusUnknown;
    }
    return self;
}

- (instancetype)init NS_UNAVAILABLE
{
    return nil;
}

- (void)dealloc
{
    [self stopMonitoring];
    
    if (_networkReachability) {
        CFRelease(_networkReachability);
    }
}

//业务逻辑
- (BOOL)isReachable
{
    return ([self isReachableViaWWAN] || [self isReachableViaWiFi]);
}

- (BOOL)isReachableViaWWAN
{
    return self.networkReachabilityStatus == NKReachabilityStatusReachableViaWWAN;
}

- (BOOL)isReachableViaWiFi
{
    return self.networkReachabilityStatus == NKReachabilityStatusReachableViaWiFi;
}

- (void)startMonitoring
{
    [self stopMonitoring];
    
    if (!self.networkReachability) {
        return;
    }
    
    __weak __typeof(self)weakSelf = self;
    NKReachabilityStatusBlock callback = ^(NKReachabilityStatus status){
        __strong __typeof(self) strongSelf = weakSelf;
        strongSelf.networkReachabilityStatus = status;
        if (strongSelf.networkReachabilityStatusBlock) {
            strongSelf.networkReachabilityStatusBlock(status);
        }
    };
    
    //核心代码
    SCNetworkReachabilityContext ctx = {0, (__bridge void * _Nullable)(callback), NKReachabilityRetainCallback, NKReachabilityReleaseCallback, NULL};
    SCNetworkReachabilitySetCallback(self.networkReachability, NKReachabilityCallback, &ctx);
    SCNetworkReachabilityScheduleWithRunLoop(self.networkReachability, CFRunLoopGetMain(), kCFRunLoopCommonModes);
    
    //发送当前的网络状态
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        SCNetworkReachabilityFlags flags;
        if (SCNetworkReachabilityGetFlags(self.networkReachability, &flags)) {
            NKPostReachabilityStatusChange(flags, callback);
        }
    });
}

- (void)stopMonitoring
{
    if (!self.networkReachability) {
        return;
    }
    SCNetworkReachabilityUnscheduleFromRunLoop(self.networkReachability, CFRunLoopGetMain(), kCFRunLoopCommonModes);
}

- (void)setReachabilityStatusChangeBlock:(nullable void (^)(NKReachabilityStatus status))block;
{
    self.networkReachabilityStatusBlock = block;
}

//KVO 依赖键
+ (NSSet *)keyPathsForValuesAffectingValueForKey:(NSString *)key
{
    if ([key isEqualToString:@"reachable"] || [key isEqualToString:@"reachableViaWWAN"] || [key isEqualToString:@"reachableViaWiFi"]) {
        return [NSSet setWithObject:@"networkReachabilityStatus"];
    }
    return [super keyPathsForValuesAffectingValueForKey:key];
}

@end

#endif

