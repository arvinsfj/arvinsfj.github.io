//
//  NetworkSecurityPolicy.h
//  TestHTTPS
//
//  Created by vin on 21/12/2017.
//  Copyright © 2017 vin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Security/Security.h>

typedef NS_ENUM(NSUInteger, NKSSLPinningMode) {
    NKSSLPinningModeNone,
    NKSSLPinningModePublicKey,
    NKSSLPinningModeCertificate,
};

NS_ASSUME_NONNULL_BEGIN

@interface NetworkSecurityPolicy : NSObject

@property (readonly, nonatomic, assign) NKSSLPinningMode SSLPinningMode;

@property (nonatomic, strong, nullable) NSSet <NSData *> *pinnedCertificates;

@property (nonatomic, assign) BOOL allowInvalidCertificates;

@property (nonatomic, assign) BOOL validatesDomainName;

+ (NSSet <NSData *> *)certificatesInBundle:(NSBundle *)bundle;

+ (instancetype)defaultPolicy;
+ (instancetype)policyWithPinningMode:(NKSSLPinningMode)pinningMode;
+ (instancetype)policyWithPinningMode:(NKSSLPinningMode)pinningMode withPinnedCertificates:(NSSet <NSData *> *)pinnedCertificates;

- (BOOL)evaluateServerTrust:(SecTrustRef)serverTrust forDomain:(nullable NSString *)domain;

@end

NS_ASSUME_NONNULL_END
