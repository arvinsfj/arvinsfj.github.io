
/*
 edit: replace the current line with a new text line
 delete: delete the current line
 insert: insert a new line after the current line
 append: append a new line after the last line
 show: show the current line text
 all: show all text lines
 up[num]: navigate up [num] lines
 down[num]: navigate down [num] lines
 top: move to very top
 bottom: move to very bottom
 save: write the text buffer to a file
 load: load a file content to the buffer
 status: output file status statistics
 help: output help info
 execute: execute the buffer text as a program
 quit: quit the editor
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef void (*Callback)(char*);

struct CMD {
    char* cmd_name;
    Callback cmd_fn;
};

struct {
    char* lines[10000];
    long  ln;//当前行下标
    long  lmax;//最后一行的下标
    
    struct CMD   fn[16];//16条命令
    
    char  changed;
    char  running;
    char* filename;
} txt;

void strltrim(char *pStr)
{
    char *pTmp = pStr;
    while (*pTmp == ' '){
        pTmp++;
    }
    while(*pTmp != '\0'){
        *pStr = *pTmp;
        pStr++;
        pTmp++;
    }
    *pStr = '\0';
}

void strrtrim(char *pStr)
{
    char *pTmp = pStr+strlen(pStr)-1;
    while (*pTmp == ' '){
        *pTmp = '\0';
        pTmp--;
    }
}

char* nextToken(char* line)
{
    char* pp = strchr(line, ' ');
    if (pp) {
        long plen = strlen(pp)+1;
        char* tmpParam = malloc(plen);
        memcpy(tmpParam, pp, plen);
        strltrim(tmpParam);
        strrtrim(tmpParam);
        if (strlen(tmpParam)) {
            return tmpParam;
        }
    }
    
    return NULL;
}

//load
void load(char* param)
{
    char* filename = nextToken(param);
    if (filename&&strlen(filename)) {
        memset(txt.lines, 0, 10000);
        txt.filename = filename;
        FILE *fp = fopen(filename, "r");
        if(fp){
            char line[1000] = {0};
            long ln = 0;
            while(!feof(fp)&&ln<10000){
                memset(line, 0, 1000);
                fgets(line, 1000, fp);
                long llen = strlen(line);//包含'\n',最后一行不包含'\n'
                if (line[llen-1] != '\n') {
                    llen+=1;
                }
                txt.lines[ln] = malloc(llen);
                memset(txt.lines[ln], 0, llen);
                memcpy(txt.lines[ln], line, llen-1);//不包含'\n',但是是完整的字符串
                
                txt.ln = ln;
                ln++;
            }
            txt.lmax = txt.ln;
            printf("%ld lines read successfully from %s\n", ln, filename);
            
        }else{
            printf("failed to open file: %s\n", filename);
        }
        fclose(fp);
    }else{
        printf("error: must specify filename\n");
    }
}

//save
void save(char* param)
{
    char* filename = nextToken(param);
    if (filename&&strlen(filename)) {
        txt.filename = filename;
        FILE *fp = fopen(filename, "w");
        if(fp){
            long ln = 0;
            for (ln = 0; ln <= txt.lmax; ln++) {
                fputs(txt.lines[ln], fp);
                if (ln != txt.lmax) {
                    fputc('\n', fp);
                }
            }
            printf("%ld lines write to file %s successfully\n", ln, filename);
            
        }else{
            printf("failed to open file: %s\n", filename);
        }
        fclose(fp);
    }else{
        printf("error: must specify filename\n");
    }
}

//quit
void quit(char* param)
{
    txt.running = 0;
}

//help
void help(char* param)
{
    printf("help info!\n[cmd] [param]\n");
}

//execute
void execute(char* param)
{
    printf("not implement!\n");
}

//status
void status(char* param)
{
    printf("filename: %s\n", !txt.filename?"<undefined>":txt.filename);
    printf("current line: %ld\n", txt.ln<=0?0:txt.ln);
    char* line = txt.lines[txt.lmax];
    printf("total lines: %ld\n", txt.lmax+1);
}

//top
void top(char* param)
{
    if (txt.ln>=0) {
        txt.ln = 0;
    }
}

//bottom
void bottom(char* param)
{
    txt.ln = txt.lmax;
}

//up
void up(char* param)
{
    char* num = nextToken(param);
    long ln = atoi(num);
    if (txt.ln-ln<=-1) {
        txt.ln = -1;
        return;
    }else{
        txt.ln = txt.ln-ln;
    }
}

//down
void down(char* param)
{
    char* num = nextToken(param);
    long ln = atoi(num);
    if (txt.ln+ln>=txt.lmax) {
        txt.ln = txt.lmax;
        return;
    }else{
        txt.ln = txt.ln+ln;
    }
}

//show
void show(char* param)
{
    if (txt.ln>=0&&txt.ln<=txt.lmax) {
        printf("%04u %s\n", (unsigned int)txt.ln, txt.lines[txt.ln]);
    }
}

//all
void all(char* param)
{
    for (long i = 0; i <= txt.lmax; i++) {
        printf("%04u %s\n", (unsigned int)i, txt.lines[i]);
    }
}

//append
void append(char* param)
{
    char* line = nextToken(param);
    long llen = strlen(line)+1;
    if (llen>1&&txt.lmax<9999) {
        bottom(param);
        txt.ln++;
        txt.lines[txt.ln] = malloc(llen);
        memcpy(txt.lines[txt.ln], line, llen);
        txt.lmax++;
    }else{
        printf("not enough memory or have not line text!\n");
    }
}

//insert
void insert(char* param)
{
    char* line = nextToken(param);
    long llen = strlen(line)+1;
    if (llen>1&&txt.lmax<9999) {
        for (long i = txt.lmax; i >= txt.ln+1; i--) {
            txt.lines[i+1] = txt.lines[i];
        }
        txt.ln++;
        txt.lines[txt.ln] = malloc(llen);
        memcpy(txt.lines[txt.ln], line, llen);
        txt.lmax++;
    }else{
        printf("not enough memory or have not line text!\n");
    }
}

//delete
void delete(char* param)
{
    if (txt.ln>=0) {
        free(txt.lines[txt.ln]);
        for (long i = txt.ln; i <= txt.lmax; i++) {
            txt.lines[i] = txt.lines[i+1];
        }
        txt.lines[txt.lmax] = 0;
        txt.lmax--;
        if (txt.ln>=txt.lmax) {
            txt.ln = txt.lmax;
        }
    }else{
        printf("have no line\n");
    }
}

//edit
void edit(char* param)
{
    char* line = nextToken(param);
    long llen = strlen(line)+1;
    if (llen>1) {
        free(txt.lines[txt.ln]);
        txt.lines[txt.ln] = malloc(llen);
        memcpy(txt.lines[txt.ln], line, llen);
    }else{
        printf("have not line text!\n");
    }
}

//下面是txt初始化函数
void setup()
{
    memset(txt.lines, 0, 10000);
    txt.ln = -1;
    txt.lmax = -1;
    txt.changed = 0;
    txt.running = 1;
    txt.filename = 0;
    
    //
    struct CMD cmd_load = {"load", load};
    struct CMD cmd_save = {"save", save};
    struct CMD cmd_quit = {"quit", quit};
    struct CMD cmd_help = {"help", help};
    struct CMD cmd_execute = {"execute", execute};
    struct CMD cmd_status = {"status", status};
    struct CMD cmd_top = {"top", top};
    struct CMD cmd_bottom = {"bottom", bottom};
    struct CMD cmd_up = {"up", up};
    struct CMD cmd_down = {"down", down};
    struct CMD cmd_show = {"show", show};
    struct CMD cmd_all = {"all", all};
    struct CMD cmd_append = {"append", append};
    struct CMD cmd_insert = {"insert", insert};
    struct CMD cmd_delete = {"delete", delete};
    struct CMD cmd_edit = {"edit", edit};
    txt.fn[0] = cmd_load;
    txt.fn[1] = cmd_save;
    txt.fn[2] = cmd_quit;
    txt.fn[3] = cmd_help;
    txt.fn[4] = cmd_execute;
    txt.fn[5] = cmd_status;
    txt.fn[6] = cmd_top;
    txt.fn[7] = cmd_bottom;
    txt.fn[8] = cmd_up;
    txt.fn[9] = cmd_down;
    txt.fn[10] = cmd_show;
    txt.fn[11] = cmd_all;
    txt.fn[12] = cmd_append;
    txt.fn[13] = cmd_insert;
    txt.fn[14] = cmd_delete;
    txt.fn[15] = cmd_edit;
}

void handleInput(char* line)
{
    line[strlen(line)-1] = '\0';
    //printf("%s\n", line);
    int lcmd = 0;
    char* endp = strchr(line, ' ');
    if (endp) {
        lcmd = endp - line + 1;
    }else{
        lcmd = strlen(line) + 1;
    }
    
    char* cmd = malloc(lcmd);
    memset(cmd, 0, lcmd);
    memcpy(cmd, line, lcmd-1);
    //printf("%s\n", cmd);
    char isvalid = 0;
    for (int i = 0; i < 16; i++) {
        struct CMD scmd = txt.fn[i];
        if (!strncmp(scmd.cmd_name, cmd, lcmd)) {
            scmd.cmd_fn(line);
            isvalid = 1;
            break;
        }
    }
    if (!isvalid) {
        printf("invalid command: %s\n", cmd);
    }
}

int main(int argc, char** argv)
{
    setup();
    
    printf("editor version: %s\n", "0.1");
    char line[1000] = {0};
    do {
        // Command prompt
        printf(">> ");
        memset(line, 0, 1000);
        fgets(line, 1000, stdin);//char '\n' included
        handleInput(line);
    } while (txt.running);
    
    return 0;
}
