

int main(int argc, char** argv)
{
    asm volatile("movl %0, %%ebp; movl $0x2f4b2f4f, 0(%%ebp)"::"r"(0xb8000+0));
    asm volatile("movl %0, %%ebp; movl $0x2f4f2f4b, 0(%%ebp)"::"r"(0xb8000+14));
    asm volatile("hlt"::);
    return 0;
}
