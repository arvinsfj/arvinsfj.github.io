//
//  ViewController.m
//  TestAudioReplaykit
//
//  Created by arvin on 2017/11/20.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import "ViewController.h"

#import <AVFoundation/AVFoundation.h>

#import "ScreenReplay.h"


@interface ViewController ()
{
    AVAudioPlayer* player_music;
}
@property (weak, nonatomic) IBOutlet UITextField *urlTextField;
@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (weak, nonatomic) IBOutlet UIButton *loadBtn;
@property (weak, nonatomic) IBOutlet UIButton *replayBtn;
@property (weak, nonatomic) IBOutlet UIButton *stopBtn;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSError *error = nil;
    [[AVAudioSession sharedInstance] setActive:YES error:&error];
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:&error];
    
    
    _urlTextField.text = @"http://www.baidu.com/";
    
    _webView.allowsInlineMediaPlayback = YES;
    _webView.scalesPageToFit = YES;
    
    [_loadBtn addTarget:self action:@selector(loadBtnclicked:) forControlEvents:UIControlEventTouchUpInside];
    
    [_replayBtn addTarget:self action:@selector(replayBtnclicked:) forControlEvents:UIControlEventTouchUpInside];
    
    [_stopBtn addTarget:self action:@selector(stopBtnclicked:) forControlEvents:UIControlEventTouchUpInside];
    
    _stopBtn.userInteractionEnabled = NO;
    _stopBtn.backgroundColor = [UIColor lightGrayColor];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)loadBtnclicked:(UIButton*)btn
{
    if (_urlTextField.text) {
        NSURL* url = [NSURL URLWithString:_urlTextField.text];
        NSURLRequest* request = [[NSURLRequest alloc] initWithURL:url];
        [_webView loadRequest:request];
    }
}

- (void)replayBtnclicked:(UIButton*)btn
{
    btn.userInteractionEnabled = NO;
    btn.backgroundColor = [UIColor lightGrayColor];
    _stopBtn.userInteractionEnabled = YES;
    _stopBtn.backgroundColor = [UIColor orangeColor];
    [[ScreenReplay shareClient] replayStart];
}

- (void)stopBtnclicked:(UIButton*)btn
{
    btn.userInteractionEnabled = NO;
    btn.backgroundColor = [UIColor lightGrayColor];
    _replayBtn.userInteractionEnabled = YES;
    _replayBtn.backgroundColor = [UIColor orangeColor];
    [[ScreenReplay shareClient] replayStop:self];
}

@end

