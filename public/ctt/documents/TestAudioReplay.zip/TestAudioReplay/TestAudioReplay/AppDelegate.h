//
//  AppDelegate.h
//  TestAudioReplay
//
//  Created by arvin on 2017/11/20.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

