//
//  ScreenReplay.h
//  iFuWoiPhone
//
//  Created by arvin on 2017/10/20.
//  Copyright © 2017年 fuwo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ScreenReplay : NSObject

+ (instancetype)shareClient;
- (void)replayStart;
- (void)replayStop:(UIViewController*)vc;

@end
