//
//  TestGame.c
//  
//
//  Created by arvin on 7/26/17.
//
//

#include <stdio.h>
#include <SDL2/SDL.h>
#include <SDL2_image/SDL_image.h>

typedef struct
{
    float x,y;
    SDL_Texture* sheetTex;
} Man;

SDL_Texture* bgTex;

int handleEvents(SDL_Window* window, Man* man)
{
    SDL_Event event;
    int done = 0;
    
    while(SDL_PollEvent(&event))
    {
        switch(event.type)
        {
            case SDL_WINDOWEVENT_CLOSE:
            {
                if(window)
                {
                    SDL_DestroyWindow(window);
                    window = NULL;
                    done = 1;
                }
            }
                break;
            case SDL_KEYDOWN:
            {
                switch(event.key.keysym.sym)
                {
                    case SDLK_ESCAPE:
                        done = 1;
                        break;
                }
            }
                break;
            case SDL_QUIT:
                //quit out of the game
                done = 1;
                break;
        }
    }
    
    return done;
}

void doRender(SDL_Renderer* renderer, Man* man)
{
    //set the drawing color to blue
    SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
    
    //Clear the screen (to blue)
    SDL_RenderClear(renderer);
    
    //set the drawing color to white
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    
    //SDL_RenderFillRect(renderer, &rect);
    SDL_RenderCopy(renderer, bgTex, NULL, NULL);
    
    //warrior
    if(man)
    {
        SDL_Rect srcRect = { 40*4, 0, 40, 50 };
        SDL_Rect rect = { man->x, man->y, 40, 50 };
        SDL_RenderCopyEx(renderer, man->sheetTex, &srcRect, &rect, 0, NULL, 0);
    }
    
    //We are done drawing, "present" or show to the screen what we've drawn
    SDL_RenderPresent(renderer);
}

void updateLogic(Man *man)
{
    //
    return;
}

int main(int argc, char** argv)
{
    SDL_Window *window;                    // Declare a window
    SDL_Renderer *renderer;                // Declare a renderer
    SDL_Init(SDL_INIT_VIDEO);              // Initialize SDL2
    
    Man man;
    man.x = 50;
    man.y = 60;
    
    //Create an application window with the following settings:
    window = SDL_CreateWindow("Game Window",                     // window title
                              SDL_WINDOWPOS_UNDEFINED,           // initial x position
                              SDL_WINDOWPOS_UNDEFINED,           // initial y position
                              640,                               // width, in pixels
                              480,                               // height, in pixels
                              0                                  // flags
                              );
    
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    
    SDL_RenderSetLogicalSize(renderer, 320, 240);
    
    SDL_Surface *sheet = IMG_Load("png/sheet.png");
    if(!sheet)
    {
        printf("Cannot find sheet\n");
        return 1;
    }
    
    man.sheetTex = SDL_CreateTextureFromSurface(renderer, sheet);
    SDL_FreeSurface(sheet);
    
    //load the bg
    SDL_Surface *bg = IMG_Load("png/background.png");
    
    if(!bg)
    {
        printf("Cannot find background\n");
        return 1;
    }
    
    bgTex = SDL_CreateTextureFromSurface(renderer, bg);
    SDL_FreeSurface(bg);
    
    // The window is open: enter program loop (see SDL_PollEvent)
    int done = 0;
    
    //Event loop
    while(!done)
    {
        //Check for events
        done = handleEvents(window, &man);
        
        //Update logic
        updateLogic(&man);
        
        //Render display
        doRender(renderer, &man);
        
        //don't burn up the CPU
        SDL_Delay(10);
    }
    
    
    // Close and destroy the window
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyTexture(man.sheetTex);
    SDL_DestroyTexture(bgTex);
    
    // Clean up
    SDL_Quit();
    return 0;
}






















