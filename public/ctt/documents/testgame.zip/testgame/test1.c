#include <stdio.h>
#include <SDL2/SDL.h>

typedef struct{
    float x, y;
    int aindex;
    SDL_Texture* manTex;
    int faceLeft;//1:朝左 0:朝右
} Man;

SDL_Texture* bgTex;

SDL_Texture* createTex(SDL_Renderer* render, char* filename)
{
    SDL_Texture* tempTex;
    SDL_Surface *sfa = SDL_LoadBMP(filename);
    if(!sfa){
        return NULL;
    }
    tempTex = SDL_CreateTextureFromSurface(render, sfa);
    SDL_FreeSurface(sfa);
    
    return tempTex;
}

int handleEvents(SDL_Window* window, Man* man)
{
    SDL_Event event;
    int done = 0;
    
    while(SDL_PollEvent(&event)){
        switch(event.type){
            case SDL_WINDOWEVENT_CLOSE:{
                if(window){
                    SDL_DestroyWindow(window);
                    window = NULL;
                    done = 1;
                }
            }
                break;
            case SDL_KEYDOWN:{
                switch(event.key.keysym.sym){
                    case SDLK_ESCAPE:
                        done = 1;
                        break;
                }
            }
                break;
            case SDL_QUIT:
                //quit out of the game
                done = 1;
                break;
        }
    }
    
    const Uint8 *state = SDL_GetKeyboardState(NULL);
    if(state[SDL_SCANCODE_LEFT]){
        man->x -= 3;
        man->faceLeft = 1;
        
        man->aindex++;
        man->aindex %= 4;
        
    } else if(state[SDL_SCANCODE_RIGHT]) {
        man->x += 3;
        man->faceLeft = 0;
        
        man->aindex++;
        man->aindex %= 4;
        
    } else if(state[SDL_SCANCODE_UP]) {
        //man->dy = -8;
    } else if(state[SDL_SCANCODE_DOWN]) {
        //man->y += 10;
    } else {
        man->aindex = 4;
    }

    return done;
}

void handleRender(SDL_Renderer* render, Man* man)
{
    SDL_SetRenderDrawColor(render, 0, 0, 255, 255);
    SDL_RenderClear(render);
    SDL_SetRenderDrawColor(render, 255, 255, 255, 255);
    
    SDL_RenderCopy(render, bgTex, NULL, NULL);
    SDL_Rect srcRect = { 40*man->aindex, 0, 40, 50 };
    SDL_Rect rect = { man->x, man->y, 40, 50 };
    SDL_RenderCopyEx(render, man->manTex, &srcRect, &rect, 0, NULL, man->faceLeft);
    
    SDL_RenderPresent(render);
}

int main(int argc, char** argv)
{
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Window* window = SDL_CreateWindow("Game Test", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 640, 480, 0);
    SDL_Renderer* render = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    SDL_RenderSetLogicalSize(render, 320, 240);
    
    bgTex = createTex(render, "bg.bmp");
    if (!bgTex) {
        printf("Cannot find bg bmp\n");
        return 1;
    }
    
    Man man;
    man.x = 50;
    man.y = 60;
    man.aindex = 4;
    man.faceLeft = 0;
    man.manTex = createTex(render, "man_sheet.bmp");
    if (!man.manTex) {
        printf("Cannot find man bmp\n");
        return 1;
    }
    
    int done = 0;
    while(!done){
        done = handleEvents(window, &man);
        
        handleRender(render, &man);
        
        SDL_Delay(10);
    }
    
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(render);
    SDL_DestroyTexture(bgTex);
    SDL_DestroyTexture(man.manTex);
    
    SDL_Quit();
    
    return 0;
}
