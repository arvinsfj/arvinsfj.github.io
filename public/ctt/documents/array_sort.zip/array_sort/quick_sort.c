#include <stdio.h>

void quick_sort(int* L, int left, int right)
{
	if (left >= right){
		return;
	}

	int i = left, j = right, key = L[left];
	
	while(i < j){
		while(i < j && key <= L[j]){
			j--;
		}
		L[i] = L[j];
		while(i < j && key >= L[i]){
			i++;
		}
		L[j] = L[i];
	}	

	L[i] = key;
	quick_sort(L, left, i - 1);
	quick_sort(L, i + 1, right);
	
}

int main()
{
	int L[] = {3, 14, 13, 7, 45, 23, 78, 34, 24, 76, 99, 13};	
	int size = sizeof(L)/sizeof(int);

	quick_sort(L, 0, size - 1);

	printf("array: ");
	for (int k = 0; k < size; k++){
		printf("%d ", L[k]);
	}
	printf("\n");

	return 0;
}
