#include <stdio.h>

int main()
{
	int L[] = {3, 17, 5, 4, 34, 23, 1, 99, 45};
	int size = sizeof(L)/sizeof(int);
	int tmp, i, j, min;

	for (i = 0; i < size - 1; i++){
		min = i;
		for (j = i + 1; j < size; j++){
			if (L[min] > L[j]){
				min = j;
			}
		}
		if (min != i){
			tmp = L[min];
			L[min] = L[i];
			L[i] = tmp;
		}
	}

	printf("array: ");
	for (int k = 0; k < size; k++){
		printf("%d ", L[k]);
	}
	printf("\n");

	return 0;
}
