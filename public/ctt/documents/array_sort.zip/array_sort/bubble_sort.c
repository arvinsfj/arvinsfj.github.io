#include <stdio.h>

int main()
{
	int L[] = {19, 7, 3, 99, 4, 13};
	int size = sizeof(L)/sizeof(int);
	int tmp;	

	for (int i = 0; i < size - 1; i++){
		for (int j = 0; j < size - 1 - i; j++){
			if (L[j] > L[j+1]){
				tmp = L[j];
				L[j] = L[j+1];
				L[j+1] = tmp;		
			}
		}
	}

	printf("array: ");
	for (int k = 0; k < size; k++){
		printf("%d ", L[k]);
	}
	printf("\n");
	
	return 0;
}
