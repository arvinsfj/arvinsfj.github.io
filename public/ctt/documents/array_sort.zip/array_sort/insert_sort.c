#include <stdio.h>

int main()
{
	int L[] = {16, 4, 7, 2, 17, 99, 35, 6};
	int size = sizeof(L)/sizeof(int);
	int tmp, i, j;

	for (i = 1; i < size; i++){
		tmp = L[i];
		for (j = i - 1; j >= 0 && L[j] > tmp; j--){
			L[j+1] = L[j];
		}
		L[j+1] = tmp;
	}

	printf("array: ");
	for (int k = 0; k < size; k++){
		printf("%d ", L[k]);
	}
	printf("\n");
	
	return 0;
}
