//
//  jsonload.c
//  TestSoftEngine
//
//  Created by dika on 2018/11/29.
//  Copyright © 2018 dika. All rights reserved.
//

#include "jsonload.h"

cJSON* json_load(const char* filepath)
{
    FILE* file = fopen(filepath,"r");
    fseek(file, 0, SEEK_END);
    long len = ftell(file);
    unsigned char* json_data = (unsigned char*)malloc(sizeof(unsigned char)*len);
    rewind(file);
    fread(json_data, len, 1, file);
    fclose(file);
    //
    cJSON* root = cJSON_Parse((const char*)json_data);
    if (!root) {
        printf("Error before: [%s]\n",cJSON_GetErrorPtr());
        return NULL;
    }
    return root;
}
