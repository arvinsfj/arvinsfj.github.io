//
//  textprint.h
//  TestSoftEngine
//
//  Created by dika on 2018/11/29.
//  Copyright © 2018 dika. All rights reserved.
//

#ifndef textload_h
#define textload_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

unsigned int* text_load(const char* text, int* len);

#endif /* textload_h */
