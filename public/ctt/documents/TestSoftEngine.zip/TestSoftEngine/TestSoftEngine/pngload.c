//
//  pngload.c
//  TestSoftEngine
//
//  Created by dika on 2018/11/29.
//  Copyright © 2018 dika. All rights reserved.
//

#include "pngload.h"

unsigned char* png_load(const char* filepath)
{
    unsigned int width = 512, height = 512;
    unsigned char* image_data = malloc(3*width*height);
    unsigned err = lodepng_decode24_file(&image_data, &width, &height, filepath);
    if (err) {
        printf("code: %d, text: %s\n", err, lodepng_error_text(err));
    }
    return image_data;
}
