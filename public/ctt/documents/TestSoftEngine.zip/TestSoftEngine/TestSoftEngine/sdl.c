//
//  sdl.c
//  TestSoftEngine
//
//  Created by dika on 2018/11/29.
//  Copyright © 2018 dika. All rights reserved.
//

#include "sdl.h"

void testLine(void)
{
    unsigned int* buf = sdlPixels();
    unsigned int* line = &buf[30*300+50];//30 row 50 col
    for (int i = 0; i < 100; ++i) {
        line[i] = 0xFFFFFFFF;
    }
}

struct timeval t1, t2;
struct display display;

// 初始化SDL2
void sdlInit(void)
{
    SDL_Init(SDL_INIT_VIDEO);
    display.window = SDL_CreateWindow("VGB", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 300, 300, SDL_WINDOW_OPENGL);
    display.surface = SDL_GetWindowSurface(display.window);
    display.frames = 0;
}

int sdlCycle(int timeStart)
{
    int end = 0;
    
    //测试画横线
    testLine();
    
    sdlUpdateFrame();
    if(sdlUpdateEvent()) end = 1;
    float deltaT = (float)1000 / (59.7) - (float)(SDL_GetTicks() - timeStart);
    if (deltaT > 0) SDL_Delay(deltaT);
    
    if (end) return 0; else return 1;
}

// 刷新SDL2界面
unsigned int* sdlPixels(void)
{
    return display.surface->pixels;
}

void sdlUpdateFrame(void)
{
    if (display.frames == 0) {
        gettimeofday(&t1, NULL);
    }
    display.frames++;
    if (display.frames % 1000 == 0) {
        gettimeofday(&t2, NULL);
        printf("FPS: %i\n", display.frames/((int)t2.tv_sec - (int)t1.tv_sec));
    }
    SDL_UpdateWindowSurface(display.window);
}

// 按键交互处理
int sdlUpdateEvent(void)
{
    SDL_Event event;
    
    while (SDL_PollEvent(&event)) {
        
        if(event.type == SDL_QUIT) return 1;
        
        switch (event.type) {
            case SDL_KEYDOWN:
                switch(event.key.keysym.sym) {
                    case SDLK_LEFT:
                        
                        break;
                    case SDLK_RIGHT:
                        
                        break;
                    case SDLK_UP:
                        
                        break;
                    case SDLK_DOWN:
                        
                        break;
                    case SDLK_z:
                        
                        break;
                    case SDLK_x:
                        
                        break;
                    case SDLK_a:
                        
                        break;
                    case SDLK_s:
                        
                        break;
                    default:
                        break;
                }
                break;
            case SDL_KEYUP:
                switch(event.key.keysym.sym) {
                    case SDLK_LEFT:
                        
                        break;
                    case SDLK_RIGHT:
                        
                        break;
                    case SDLK_UP:
                        
                        break;
                    case SDLK_DOWN:
                        
                        break;
                    case SDLK_z:
                        
                        break;
                    case SDLK_x:
                        
                        break;
                    case SDLK_a:
                        
                        break;
                    case SDLK_s:
                        
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
    }
    
    return 0;
}
