//
//  sdl.c
//  TestSoftEngine
//
//  Created by dika on 2018/11/29.
//  Copyright © 2018 dika. All rights reserved.
//

#include "sdl.h"

#include "pngload.h"
#include "jsonload.h"
#include "textload.h"

//测试代码
void text_print(int row, int col, unsigned int* pixel_char)
{
    unsigned int* buf = sdlPixels();
    unsigned int* line = &buf[row*512+col];//row col
    for (int i = 0; i < 8; ++i) {
        //
        for (int j = 0; j < 8; ++j) {
            //
            unsigned int pixel = pixel_char[i*8+j];
            if (pixel != 0x00000000) {
                line[i*512+j] = pixel;
            }
        }
    }
}

void testLoadFont(void)
{
    int length = 0;
    unsigned int* text_data = text_load("Hello, SoftRender!", &length);
    //
    for (int i = 0; i < length*64; i+=64) {
        text_print(10, 10+(i/8), text_data+i);
    }
}

void testLoadJson(void)
{
    cJSON* root = json_load("monkey.babylon");
    printf("%s\n\n", cJSON_Print(root));
}

void testLoadPng(void)
{
    unsigned int* buf = sdlPixels();
    unsigned int* line = &buf[0*512+0];//0 row 0 col
    //
    unsigned char* image = png_load("Suzanne.png");
    
    for (int row = 0; row < 512; ++row) {
        for (int col = 0; col < 512; ++col) {
            //
            unsigned char* rgb = &image[(row*512+col)*3];//RGB
            unsigned char red = rgb[0];
            unsigned char green = rgb[1];
            unsigned char blue = rgb[2];
            unsigned int pixel = (red<<16)|(green<<8)|(blue);
            //pixel |= 0xFF000000;
            line[(0+row)*512+(0+col)] = pixel;//ARGB
        }
    }
    
    free(image);
}

void testLine(void)
{
    unsigned int* buf = sdlPixels();
    unsigned int* line = &buf[30*512+50];//30 row 50 col
    for (int i = 0; i < 100; ++i) {
        line[i] = 0xFFFFFFFF;
    }
}

int isTestFlag = 0;

/////////////////////////////////////////////

struct timeval t1, t2;
struct display display;

// 初始化SDL2
void sdlInit(void)
{
    SDL_Init(SDL_INIT_VIDEO);
    display.window = SDL_CreateWindow("SoftRender", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 512, 512, SDL_WINDOW_OPENGL);
    display.surface = SDL_GetWindowSurface(display.window);
    display.frames = 0;
}

int sdlCycle(int timeStart)
{
    int end = 0;
    
    //测试
    if (!isTestFlag) {
        //测试画横线
        //testLine();
        //测试加载jpeg图片
        testLoadPng();
        //测试加载解析json
        //testLoadJson();
        //
        testLoadFont();
        //
        isTestFlag = 1;
    }
    
    sdlUpdateFrame();
    if(sdlUpdateEvent()) end = 1;
    float deltaT = (float)1000 / (59.7) - (float)(SDL_GetTicks() - timeStart);
    if (deltaT > 0) SDL_Delay(deltaT);
    
    if (end) return 0; else return 1;
}

// 刷新SDL2界面
unsigned int* sdlPixels(void)
{
    return display.surface->pixels;
}

void sdlUpdateFrame(void)
{
    if (display.frames == 0) {
        gettimeofday(&t1, NULL);
    }
    display.frames++;
    if (display.frames % 1000 == 0) {
        gettimeofday(&t2, NULL);
        printf("FPS: %i\n", display.frames/((int)t2.tv_sec - (int)t1.tv_sec));
    }
    SDL_UpdateWindowSurface(display.window);
}

// 按键交互处理
int sdlUpdateEvent(void)
{
    SDL_Event event;
    
    while (SDL_PollEvent(&event)) {
        
        if(event.type == SDL_QUIT) return 1;
        
        switch (event.type) {
            case SDL_KEYDOWN:
                switch(event.key.keysym.sym) {
                    case SDLK_LEFT:
                        
                        break;
                    case SDLK_RIGHT:
                        
                        break;
                    case SDLK_UP:
                        
                        break;
                    case SDLK_DOWN:
                        
                        break;
                    case SDLK_z:
                        
                        break;
                    case SDLK_x:
                        
                        break;
                    case SDLK_a:
                        
                        break;
                    case SDLK_s:
                        
                        break;
                    default:
                        break;
                }
                break;
            case SDL_KEYUP:
                switch(event.key.keysym.sym) {
                    case SDLK_LEFT:
                        
                        break;
                    case SDLK_RIGHT:
                        
                        break;
                    case SDLK_UP:
                        
                        break;
                    case SDLK_DOWN:
                        
                        break;
                    case SDLK_z:
                        
                        break;
                    case SDLK_x:
                        
                        break;
                    case SDLK_a:
                        
                        break;
                    case SDLK_s:
                        
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
    }
    
    return 0;
}
