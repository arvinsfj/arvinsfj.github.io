//
//  sdl.h
//  TestSoftEngine
//
//  Created by dika on 2018/11/29.
//  Copyright © 2018 dika. All rights reserved.
//

#ifndef sdl_h
#define sdl_h

#include <SDL2/SDL.h>
#include <sys/time.h>

struct display
{
    SDL_Window *window;
    SDL_Surface *surface;
    unsigned int frames;
};

void sdlInit(void);
int sdlCycle(int);
unsigned int* sdlPixels(void);
void sdlUpdateFrame(void);
int sdlUpdateEvent(void);

#endif /* sdl_h */
