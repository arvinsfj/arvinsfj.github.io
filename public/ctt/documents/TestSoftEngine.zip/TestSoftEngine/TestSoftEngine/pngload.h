//
//  pngload.h
//  TestSoftEngine
//
//  Created by dika on 2018/11/29.
//  Copyright © 2018 dika. All rights reserved.
//

#ifndef pngload_h
#define pngload_h

#include <stdio.h>
#include <stdlib.h>

#include "lodepng.h"

unsigned char* png_load(const char* filepath);

#endif /* pngload_h */
