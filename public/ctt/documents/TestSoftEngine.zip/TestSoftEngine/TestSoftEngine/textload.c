//
//  textprint.c
//  TestSoftEngine
//
//  Created by dika on 2018/11/29.
//  Copyright © 2018 dika. All rights reserved.
//

#include "textload.h"

#include "font5_7.h"

const static unsigned int white = 0xFF0000FF;//blue
const static unsigned int black = 0x00000000;

static unsigned char char_pixel[8];
static unsigned int pixel_char[64];

void char_load(char c)
{
    int index = (c - 0x20) * 8;
    for (int i = 0; i < 8; ++i) {
        char_pixel[i] = nAsciiDot[index+i];
    }
}

void pixel_load(char c)
{
    char_load(c);
    for (int i = 0; i < 8; ++i) {
        //
        unsigned char ca = char_pixel[i];
        for (int j = 0; j < 8; ++j) {
            //
            if (!!(ca&(1<<(7-j))) == 1) {
                //white
                pixel_char[i*8+j] = white;
            } else {
                //black
                pixel_char[i*8+j] = black;
            }
        }
    }
}

unsigned int* text_load(const char* text, int* len)
{
    unsigned int* pixel = malloc(sizeof(unsigned int)*strlen(text)*64);
    char c = ' ';
    int i = 0;
    while ((c = text[i]) != '\0') {
        pixel_load(c);
        //
        for (int k = 0; k < 64; ++k) {
            //
            pixel[i*64+k] = pixel_char[k];
        }
        i++;
    }
    
    *len = i;
    
    return pixel;
}
