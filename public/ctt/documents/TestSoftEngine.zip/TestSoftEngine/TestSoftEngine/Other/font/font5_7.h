//
//  font5_7.h
//  TestSoftEngine
//
//  Created by dika on 2018/11/29.
//  Copyright © 2018 dika. All rights reserved.
//

#ifndef font5_7_h
#define font5_7_h

extern unsigned char nAsciiDot[];

#endif /* font5_7_h */
