//
//  jsonload.h
//  TestSoftEngine
//
//  Created by dika on 2018/11/29.
//  Copyright © 2018 dika. All rights reserved.
//

#ifndef jsonload_h
#define jsonload_h

#include <stdio.h>
#include <stdlib.h>

#include "cJSON.h"

cJSON* json_load(const char* filepath);

#endif /* jsonload_h */
