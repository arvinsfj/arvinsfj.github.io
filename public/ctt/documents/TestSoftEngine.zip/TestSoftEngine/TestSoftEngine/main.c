//
//  main.c
//  TestSoftEngine
//
//  Created by dika on 2018/11/29.
//  Copyright © 2018 dika. All rights reserved.
//

#include <stdio.h>

#include "sdl.h"

int main(int argc, const char * argv[])
{
    sdlInit();
    
    while (1) {
        unsigned int timeStart = SDL_GetTicks();
        // 组件执行循环
        if (!sdlCycle(timeStart)) break;
    }
    
    // 组件退出清理
    SDL_Quit();
    
    return 0;
}
