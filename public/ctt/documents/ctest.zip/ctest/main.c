
#define NDEBUG
//#undef NDEBUG

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <float.h>
#include <limits.h>
#include <locale.h>
#include <math.h>
#include <setjmp.h>
#include <signal.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void test_assert(int argc);
void test_ctype(void);
void test_errno(void);
void test_float(void);
void test_limits(void);
void test_locale(void);
void test_math(void);
void test_setjmp(void);
void test_signal(void);
void test_stdarg(int num, ...);
void test_stddef(void);
void test_stdio(void);
void test_stdlib(void);
void test_string(void);
void test_time(void);

int main(int argc, char** argv)
{
    test_assert(argc);
    test_ctype();
    test_errno();
    test_float();
    test_limits();
    //test_locale();
    test_math();
    test_setjmp();
    //test_signal();
    test_stdarg(3,10,20,30);
    test_stdarg(4,10,20,30,40);
    test_stddef();
    test_stdio();
    test_stdlib();
    test_string();
    test_time();
    return 0;
}

void test_assert(int argc)
{
    assert(argc==1);
    assert(argc==2);
}

void test_ctype()
{
    //传入int，返回int
    
    //测试函数
    //isalnum函数、isalpha函数、iscntrl、isdigit、isgraph、islower、isprint、ispunct、isspace、isupper、isxdigit
    if (ispunct('?')) {
        printf("%s\n", "true");
    } else {
        printf("%s\n", "false");
    }
    
    //转换函数
    printf("%c:%c\n", toupper('a'), tolower('G'));
}

void test_errno()
{
    FILE* fp = fopen("file.txt", "rt");
    if (fp == NULL) {
        fprintf(stderr, "value of errno: %d\n", errno);
        fprintf(stderr, "error opening file: %s\n", strerror(errno));
    } else {
        fclose(fp);
    }
    //
    errno = 0;
    double val = sqrt(-10);
    if (errno == EDOM) {
        printf("Invalid argument\n");
    }
    
    errno = 0;
    val = log(2.000000);
    if (errno == ERANGE) {
        printf("Log(%f) is out of rang\n", 2.00000);
    }
}

void test_float()
{
    //floating-point = ( S ) p x be
    
    printf("The maximum value of float = %.10e\n", FLT_MAX);
    printf("The minimum value of float = %.10e\n", FLT_MIN);
    printf("The minimum value of float epsilon = %.10e\n", FLT_EPSILON);
    printf("%d:%d:%d:%d:%d:%d:%d:%d\n", FLT_ROUNDS, FLT_RADIX, FLT_MANT_DIG, FLT_DIG,FLT_MIN_EXP,FLT_MAX_EXP,FLT_MIN_10_EXP,FLT_MAX_10_EXP);
}

void test_limits()
{
    printf("The number of bits in a byte: %d\n", CHAR_BIT);
    
    printf("The maximum value of SIGNED CHAR = %d\n", SCHAR_MAX);
    printf("The maximum value of UNSIGNED CHAR = %d\n", UCHAR_MAX);
    
    printf("The minimum value of CHAR = %d\n", CHAR_MIN);
    printf("The maximum value of CHAR = %d\n", CHAR_MAX);
    
    printf("The minimum value of SHORT INT = %d\n", SHRT_MIN);
    printf("The maximum value of SHORT INT = %d\n", SHRT_MAX);
    
    printf("The minimum value of INT = %d\n", INT_MIN);
    printf("The maximum value of INT = %d\n", INT_MAX);
    
    printf("The minimum value of LONG = %ld\n", LONG_MIN);
    printf("The maximum value of LONG = %ld\n", LONG_MAX);
}

void test_locale()
{
    //LC_ALL、LC_COLLATE、LC_CTYPE、LC_MONETARY、LC_NUMERIC、LC_TIME
    //char *setlocale(int category, const char *locale)
    //struct lconv *localeconv(void)
    
    time_t currtime;
    struct tm* timer;
    char buffer[80];
    
    time( &currtime );
    timer = localtime( &currtime );
    
    printf("Locale is: %s\n", setlocale(LC_ALL, "en_GB"));
    strftime(buffer,80,"%c", timer );
    printf("Date is: %s\n", buffer);
    
    printf("Locale is: %s\n", setlocale(LC_ALL, "de_DE"));
    strftime(buffer,80,"%c", timer );
    printf("Date is: %s\n", buffer);
    
    struct lconv* lc;
    setlocale(LC_MONETARY, "en_US");
    lc = localeconv();
    printf("Local Currency Symbol: %s\n",lc->currency_symbol);
    printf("International Currency Symbol: %s\n",lc->int_curr_symbol);
    
    setlocale(LC_MONETARY, "it_IT");
    lc = localeconv();
    printf("Local Currency Symbol: %s\n",lc->currency_symbol);
    printf("International Currency Symbol: %s\n",lc->int_curr_symbol);
    
    //
    setlocale(LC_MONETARY, "en_US");
}

void test_math()
{
    //传入double类型参数，返回double类型返回值
    
    //HUGE_VAL宏，当函数的结果不可以表示为浮点数时。
    //如果是因为结果的幅度太大以致于无法表示，则函数会设置 errno 为 ERANGE 来表示范围错误，并返回一个由宏 HUGE_VAL 或者它的否定（- HUGE_VAL）命名的一个特定的很大的值。
    //如果结果的幅度太小，则会返回零值。在这种情况下，error 可能会被设置为 ERANGE，也有可能不会被设置为 ERANGE。
    
    //数学函数
    printf("sin(30) = %lf\n", sin(30.0/180*M_PI));
    printf("cos(60) = %lf\n", cos(60.0/180*M_PI));
    printf("tan(45) = %lf\n", tan(45.0/180*M_PI));
    //
    printf("exp(3) = %lf\n", exp(3));
    printf("log(3) = %lf\n", log(3));
    printf("pow(2,10) = %lf\n", pow(2,10));
    printf("sqrt(16) = %lf\n", sqrt(16));
}

static jmp_buf buf;

void second(void) {
    printf("second\n");         // 打印
    longjmp(buf,1);             // 跳回setjmp的调用处 - 使得setjmp返回值为1
}

void first(void) {
    second();
    printf("first\n");          // 不可能执行到此行
}

void test_setjmp()
{
    if ( !setjmp(buf) ) {
        first();                // 进入此行前，setjmp返回0
    } else {                    // 当longjmp跳转回，setjmp返回1，因此进入此行
        printf("main\n");       // 打印
    }
}

void sighandler(int signum) {
    printf("捕获信号 %d，跳出...\n", signum);
    exit(1);
}

void test_signal()
{
    //信号处理：SIG_DFL、SIG_ERR、SIG_IGN
    //信号码：SIGABRT、SIGFPE、SIGILL、SIGINT、SIGSEGV、SIGTERM
    //函数：void (*signal(int sig, void (*func)(int)))(int)
    //函数：int raise(int sig)

    signal(SIGINT, sighandler);
    while(1) {
        printf("开始休眠一秒钟...\n");
        sleep(1);
        //raise(SIGINT);
    }
}

void test_stdarg(int num, ...)
{
    //处理可变参数函数的参数获取，一个变量类型，三个处理宏
    int val = 0;
    va_list ap;
    va_start(ap, num);
    for(int i = 0; i < num; i++) {
        val += va_arg(ap, int);
    }
    va_end(ap);
    printf("%d\n", val);
}

void test_stddef()
{
    //定义了各种变量类型和宏。这些定义中的大部分也出现在其它头文件中。
    
    //变量类型：ptrdiff_t、size_t、wchar_t、NULL
    printf("%lu:%lu:%lu:%lu\n", sizeof(ptrdiff_t), sizeof(size_t), sizeof(wchar_t), sizeof(NULL));
    
    //偏移宏：offsetof(type, member-designator)
    struct off {
        int k;
        char c;
        short s;
    };
    printf("%lu\n", offsetof(struct off, s));
}

void test_stdio()
{
    //输入输出相关的函数库
    //库变量类型：size_t、FILE、fpos_t
    //库宏：NULL、BUFSIZ、EOF、SEEK_CUR、SEEK_END、SEEK_SET、stdin、stdout、stderr等
    //库函数：文件流等，有很多非常巧妙的使用方法，比如：sscanf函数，同时注意格式化字符串的使用
    //文件流、标准流、字符串
    
    char buffer[512];
    FILE* fp = fopen("ctest.md", "rt");
    
    fgets(buffer, 511, fp);
    fgets(buffer, 511, fp);
    
    printf("%s\n", buffer);
    
    fclose(fp);
}

void test_stdlib()
{
    //库变量类型：size_t、wchar_t、div_t、ldiv_t
    //库宏：NULL、EXIT_FAILURE、EXIT_SUCCESS、RAND_MAX、MB_CUR_MAX
    
    //库函数：字符串转数值、内存分配、重新分配和回收、程序终止相关、环境变量、system命令、绝对值、除法、数组查找和排序、随机数、字符串和字符数组转换
    
    printf("%d\n", atoi("123"));
    char* k = malloc(2);
    k[0] = 1;k[1]=2;
    int v = *((short*)k);
    printf("%d\n", v);
    free(k);
}

void test_string()
{
    //库变量类型：size_t
    //库宏:NULL
    //库函数：字符串操作函数、内存复制函数
    
    char buffer[512];
    char* src = "hello,world!";
    
    memcpy(buffer, src, 13);
    printf("%s\n", buffer);
    printf("%s\n", strncat(buffer, src, 5));
}

void test_time()
{
    //库变量类型：size_t、clock_t、time_t、struct tm
    //库宏：NULL、CLOCKS_PER_SEC（每秒的处理器时钟周期个数）
    
    //库函数：时间日历 处理函数
    struct tm t;
    t.tm_sec    = 10;
    t.tm_min    = 10;
    t.tm_hour   = 6;
    t.tm_mday   = 25;
    t.tm_mon    = 2;
    t.tm_year   = 89;
    t.tm_wday   = 6;
    puts(asctime(&t));
    
    time_t curtime;
    time(&curtime);
    printf("当前时间 = %s", ctime(&curtime));
    
    clock_t start_t;
    start_t = clock();
    printf("程序启动，start_t = %ld\n", start_t);
    
    time_t rawtime;
    struct tm *info;
    char buffer[80];
    time( &rawtime );
    info = localtime( &rawtime );
    strftime(buffer,80,"%x - %I:%M%p", info);
    printf("格式化的日期 & 时间 : |%s|\n", buffer );
    
    printf("%d\n", CLOCKS_PER_SEC);
}
