//
//  cpu.h
//  TestVGB
//
//  Created by vin on 2018/8/29.
//  Copyright © 2018年 vin. All rights reserved.
//

#ifndef cpu_h
#define cpu_h

#include <stdio.h>
#include <string.h>

struct registers
{
    unsigned char A;
    unsigned char F; // flags: Z N H C
    
    unsigned char B;
    unsigned char C;
    
    unsigned char D;
    unsigned char E;
    
    unsigned char H;
    unsigned char L;
    
    unsigned short SP;
    unsigned short PC;
    
    unsigned int cycles;//cpu总周期数
};

void cpuInit(void);
void cpuInterrupt(unsigned short address);
unsigned int getCpuCycles(void);
void cpuCycle(void);

#endif /* cpu_h */
