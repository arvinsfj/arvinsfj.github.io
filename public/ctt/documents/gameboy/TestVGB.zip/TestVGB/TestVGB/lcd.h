//
//  lcd.h
//  TestVGB
//
//  Created by vin on 2018/8/24.
//  Copyright © 2018年 vin. All rights reserved.
//

#ifndef lcd_h
#define lcd_h

#include "sdl.h"

int lcdCycle(int timeStart);

#endif /* lcd_h */
