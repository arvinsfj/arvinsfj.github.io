//
//  main.c
//  TestVGB
//
//  Created by vin on 2018/8/24.
//  Copyright © 2018年 vin. All rights reserved.
//

#include <stdio.h>

#include "lcd.h"

int main(int argc, const char * argv[])
{
    // 组件初始化
    sdlInit();
    
    while (1) {
        unsigned int timeStart = SDL_GetTicks();
        // 组件执行循环
        if (!lcdCycle(timeStart)) break;
    }
    
    // 组件退出清理
    SDL_Quit();
    
    return 0;
}
