//
//  lcd.c
//  TestVGB
//
//  Created by vin on 2018/8/24.
//  Copyright © 2018年 vin. All rights reserved.
//

#include "lcd.h"

int lcdCycle(int timeStart)
{
    int end = 0;
    
    unsigned int *buf = sdlPixels();
    for (int i = 0; i < 160*144; ++i) {
        buf[i] = ((0x01<<24) | (0xFF<<16) | (0x00<<8) | 0xFF);//ARGB
    }
    sdlUpdateFrame();
    if(sdlUpdateEvent()) end = 1;
    //
    float deltaT = (float)1000 / (59.7) - (float)(SDL_GetTicks() - timeStart);
    if (deltaT > 0) SDL_Delay(deltaT);
    
    return end?0:1;
}
