//
//  sdl.h
//  TestVGB
//
//  Created by vin on 2018/8/24.
//  Copyright © 2018年 vin. All rights reserved.
//

#ifndef sdl_h
#define sdl_h

#include <SDL2/SDL.h>
#include <sys/time.h>

struct buttons
{
    char start;
    char select;
    char a;
    char b;
    
    char up;
    char down;
    char left;
    char right;
};

struct display
{
    SDL_Window *window;
    SDL_Surface *surface;
    unsigned int frames;
};


void sdlInit(void);
unsigned int* sdlPixels(void);
void sdlUpdateFrame(void);
int sdlUpdateEvent(void);
unsigned int getButton(void);
unsigned int getDirection(void);

#endif /* sdl_h */
