//
//  timer.h
//  TestVGB
//
//  Created by vin on 2018/8/29.
//  Copyright © 2018年 vin. All rights reserved.
//

#ifndef timer_h
#define timer_h

#include <stdio.h>

struct timer
{
    unsigned int div;   // divider
    unsigned int tima;  // timer counter
    unsigned int tma;   // timer module
    unsigned char tac;  // timer controller
    
    unsigned int speed;
    unsigned int started;
    
    unsigned int tick;
};

extern struct timer timer;

void timerCycle(void);

#endif /* timer_h */
