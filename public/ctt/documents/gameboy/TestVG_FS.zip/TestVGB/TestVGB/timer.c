//
//  timer.c
//  TestVGB
//
//  Created by vin on 2018/8/29.
//  Copyright © 2018年 vin. All rights reserved.
//

#include "timer.h"

#include "interrupt.h"
#include "cpu.h"

struct timer timer;

void tick(void)
{
    timer.tick += 1;
    
    /* Divider updates at 16384Hz */
    if (timer.tick == 16) {
        timer.div += 1;
        timer.tick = 0;
    }
    
    if (!timer.started) return;
    
    if (timer.tick == timer.speed) {
        timer.tima += 1;
        timer.tick = 0;
    }
    
    // >0xFF value overflows
    if (timer.tima == 0x100) {
        interrupt.flags |= TIMER;
        timer.tima = timer.tma;
    }
}

void timerCycle(void)
{
    //使用局部静态变量
    static unsigned int change = 0;
    static unsigned int time = 0;
    static unsigned int delta = 0;
    
    delta = getCpuCycles() - time;//cpu前进的cycles
    time = getCpuCycles();
    
    change += delta;
    
    if (change >= 16) {
        tick();
        change -= 16;
    }
}

