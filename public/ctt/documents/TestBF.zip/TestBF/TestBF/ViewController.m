//
//  ViewController.m
//  TestBF
//
//  Created by arvin on 2017/12/23.
//  Copyright © 2017年 arvin. All rights reserved.
//

#import "ViewController.h"

#import "Interpreter.h"

#import <QuartzCore/QuartzCore.h>

@interface ViewController ()

@property (nonatomic,weak) IBOutlet UITextField *input;
@property (nonatomic,weak) IBOutlet UITextView *code;
@property (nonatomic,weak) IBOutlet UITextView *output;
@property (nonatomic,strong) Interpreter *interpreter;

@end

@implementation ViewController

@synthesize input;
@synthesize code;
@synthesize output;
@synthesize interpreter = _interpreter;

-(Interpreter*)interpreter
{
    if(!_interpreter) {
        _interpreter = [[Interpreter alloc] init];
    }
    
    return _interpreter;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    code.layer.borderWidth = 1.0f;
    code.layer.borderColor = [[UIColor grayColor] CGColor];
    
    [[output layer] setBorderWidth:1.0f];
    output.layer.borderColor = [[UIColor grayColor] CGColor];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)pressed:(UIButton*)sender
{
    self.interpreter.inputCode = self.code.text;
    self.interpreter.inputConsole = self.input.text;
    [self.interpreter process];
    self.output.text = self.interpreter.outputText;
}

/* close keyboard when focus is lost */
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    UITouch *touch = [[event allTouches] anyObject];
    if ([code isFirstResponder] && [touch view] != code) {
        [code resignFirstResponder];
    }
    
    if([input isFirstResponder] && [touch view] != input) {
        [input resignFirstResponder];
    }
    [super touchesBegan:touches withEvent:event];
}

@end
