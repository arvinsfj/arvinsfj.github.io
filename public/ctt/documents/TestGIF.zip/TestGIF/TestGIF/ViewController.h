//
//  ViewController.h
//  TestGIF
//
//  Created by arvin on 2017/10/18.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

