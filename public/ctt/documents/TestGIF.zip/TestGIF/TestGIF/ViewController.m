//
//  ViewController.m
//  TestGIF
//
//  Created by arvin on 2017/10/18.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import "ViewController.h"

#import <AVFoundation/AVFoundation.h>
#import <ImageIO/ImageIO.h>
#import <CoreGraphics/CoreGraphics.h>
#import <MobileCoreServices/MobileCoreServices.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self imagesFromGIF:[[NSBundle mainBundle] pathForResource:@"kouros_head" ofType:@"gif"]];//kouros_head
    [self gifFromImages:30];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)imagesFromGIF:(NSString*)path
{
    NSString *cachePath = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject;
    NSLog(@">>>>>>\n%@", cachePath);
    NSData* gifData = [NSData dataWithContentsOfFile:path];
    CGImageSourceRef source = CGImageSourceCreateWithData((__bridge CFDataRef)gifData, NULL);
    size_t count = CGImageSourceGetCount(source);
    for (size_t i = 0; i < count; i++) {
        CGImageRef image = CGImageSourceCreateImageAtIndex(source, i, NULL);
        if (image) {
            NSData *imageData=UIImagePNGRepresentation([UIImage imageWithCGImage:image]);
            NSString* savePath = [cachePath stringByAppendingPathComponent:[NSString stringWithFormat:@"%zu.jpg", i]];
            [imageData writeToFile:savePath atomically:YES];
            CGImageRelease(image);
        }
    }
    NSLog(@"%@", @"Finished!");
}

- (void)gifFromImages:(size_t)count
{
    NSString *cachePath = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject;
    NSLog(@">>>>>>\n%@", cachePath);
    NSURL *gifurl = [NSURL fileURLWithPath:[cachePath stringByAppendingPathComponent:@"test.gif"]];
    CGImageDestinationRef destination = CGImageDestinationCreateWithURL((__bridge CFURLRef)gifurl, kUTTypeGIF , count, NULL);
    CGImageDestinationSetProperties(destination, (CFDictionaryRef)@{(NSString *)kCGImagePropertyGIFDictionary:@{(NSString *)kCGImagePropertyGIFLoopCount: @(0)}});
    for (size_t i = 0; i < count; i++) {
        NSData* imageData = [NSData dataWithContentsOfFile:[cachePath stringByAppendingPathComponent:[NSString stringWithFormat:@"%zu.jpg", i]]];
        CGImageRef image = [UIImage imageWithData:imageData].CGImage;
        CGImageDestinationAddImage(destination, image, (CFDictionaryRef)@{(NSString *)kCGImagePropertyGIFDictionary:@{(NSString *)kCGImagePropertyGIFDelayTime: @(0.125)},
                                                                             (NSString *)kCGImagePropertyColorModel:(NSString *)kCGImagePropertyColorModelRGB});
        //CGImageRelease(image);
    }
    CGImageDestinationFinalize(destination);
    CFRelease(destination);
    NSLog(@"%@", @"Finished!");
}


@end
