//
//  main.m
//  TestDoomRender
//
//  Created by vin on 2018/2/28.
//  Copyright © 2018年 vin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
