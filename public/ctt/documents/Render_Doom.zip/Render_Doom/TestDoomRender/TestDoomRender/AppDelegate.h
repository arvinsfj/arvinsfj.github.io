//
//  AppDelegate.h
//  TestDoomRender
//
//  Created by vin on 2018/2/28.
//  Copyright © 2018年 vin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

