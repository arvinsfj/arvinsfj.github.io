//
//  ViewController.m
//  TestDoomRender
//
//  Created by vin on 2018/2/28.
//  Copyright © 2018年 vin. All rights reserved.
//

#import "ViewController.h"

extern void render_init(const char* path);
extern unsigned char* render_update(void);
extern void render_deinit(void);

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *renderImageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self renderSetup];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)renderSetup
{
    NSString* path = [[NSBundle mainBundle] pathForResource:@"map-clear" ofType:@"txt"];
    render_init([path cStringUsingEncoding:NSUTF8StringEncoding]);
    
    CADisplayLink* displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(onDisplayLink:)];
    [displayLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
}


- (void)onDisplayLink:(CADisplayLink *)displayLink
{
    unsigned char* imageBytes = render_update();
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(imageBytes,
                                                 608,
                                                 480,
                                                 8,
                                                 608 * 4,
                                                 colorSpace,
                                                 kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedFirst);
    CGImageRef imageRef = CGBitmapContextCreateImage(context);
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    
    _renderImageView.layer.contents = (__bridge id _Nullable)(imageRef);
}

- (void)dealloc
{
    render_deinit();
}

@end
