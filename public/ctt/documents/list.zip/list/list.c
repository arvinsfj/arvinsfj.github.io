
#include <stdio.h>
#include <stdlib.h>

#include "list.h"

//首先定义一个数据节点，并插入链表关系节点list_head
struct dataNode
{
    int index;
    struct list_head list;
    char* hello; 
};

static LIST_HEAD(hello_list);

int main(int argc, char** argv)
{
    //创建链表
    for (int i = 0; i < 10; ++i){
        struct dataNode *entry = malloc(sizeof(struct dataNode));
        list_init(&entry->list);
        entry->index = i;
        entry->hello = "hello, tom!";
        list_add_tail(&entry->list, &hello_list);
    }
    //遍历链表
    struct list_head *item;
    struct dataNode *data;
    list_for_each(item, &hello_list) {
        data = list_entry(item, struct dataNode, list);
        printf("%d: %s\n", data->index, data->hello);
    }
    //释放链表
    struct list_head *item_free, *tmp;
    struct dataNode *data_free;
    list_for_each_safe(item_free, tmp, &hello_list) {
        data_free = list_entry(item_free, struct dataNode, list);
        list_del(item_free);
        free(data_free);
    }
    //
    return 0;
}
