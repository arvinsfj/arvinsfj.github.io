//
//  LineShape.swift
//  TestTetris
//
//  Created by arvin on 2017/9/8.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

class LineShape: Shape {

    override var blockColumnRowPositions: [Orientation: Array<(columnDiff: Int, rowDiff: Int)>] {
        return [
            Orientation.zero:       [(0, 0), (0, 1), (0, 2), (0, 3)],
            Orientation.ninety:     [(-1,0), (0, 0), (1, 0), (2, 0)],
            Orientation.oneEighty:  [(0, 0), (0, 1), (0, 2), (0, 3)],
            Orientation.twoSeventy: [(-1,0), (0, 0), (1, 0), (2, 0)]
        ]
    }
    
    override var bottomBlocksForOrientations: [Orientation: Array<Block>] {
        return [
            Orientation.zero:       [blocks[3]],
            Orientation.ninety:     blocks,
            Orientation.oneEighty:  [blocks[3]],
            Orientation.twoSeventy: blocks
        ]
    }
}
