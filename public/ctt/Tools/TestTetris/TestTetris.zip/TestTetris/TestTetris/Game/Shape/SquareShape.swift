//
//  SquareShape.swift
//  TestTetris
//
//  Created by arvin on 2017/9/8.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

class SquareShape: Shape {
    // #2
    override var blockColumnRowPositions: [Orientation: Array<(columnDiff: Int, rowDiff: Int)>] {
        return [
            Orientation.zero: [(0, 0), (1, 0), (0, 1), (1, 1)],
            Orientation.oneEighty: [(0, 0), (1, 0), (0, 1), (1, 1)],
            Orientation.ninety: [(0, 0), (1, 0), (0, 1), (1, 1)],
            Orientation.twoSeventy: [(0, 0), (1, 0), (0, 1), (1, 1)]
        ]
    }
    
    // #3
    override var bottomBlocksForOrientations: [Orientation: Array<Block>] {
        return [
            Orientation.zero:       [blocks[2], blocks[3]],
            Orientation.oneEighty:  [blocks[2], blocks[3]],
            Orientation.ninety:     [blocks[2], blocks[3]],
            Orientation.twoSeventy: [blocks[2], blocks[3]]
        ]
    }
}
