//
//  SShape.swift
//  TestTetris
//
//  Created by arvin on 2017/9/8.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

class SShape: Shape {

    override var blockColumnRowPositions: [Orientation: Array<(columnDiff: Int, rowDiff: Int)>] {
        return [
            Orientation.zero:       [(0, 0), (0, 1), (1, 1), (1, 2)],
            Orientation.ninety:     [(2, 0), (1, 0), (1, 1), (0, 1)],
            Orientation.oneEighty:  [(0, 0), (0, 1), (1, 1), (1, 2)],
            Orientation.twoSeventy: [(2, 0), (1, 0), (1, 1), (0, 1)]
        ]
    }
    
    override var bottomBlocksForOrientations: [Orientation: Array<Block>] {
        return [
            Orientation.zero:       [blocks[1], blocks[3]],
            Orientation.ninety:     [blocks[0], blocks[2], blocks[3]],
            Orientation.oneEighty:  [blocks[1], blocks[3]],
            Orientation.twoSeventy: [blocks[0], blocks[2], blocks[3]]
        ]
    }
}
