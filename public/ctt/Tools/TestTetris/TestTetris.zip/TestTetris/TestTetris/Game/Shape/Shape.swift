//
//  Shape.swift
//  TestTetris
//
//  Created by arvin on 2017/9/8.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

import Foundation

enum Orientation: Int, CustomStringConvertible {
    
    case zero = 0, ninety, oneEighty, twoSeventy
    
    var description: String {
    
        switch self {
        case .zero:
            return "0"
        case .ninety:
            return "90"
        case .oneEighty:
            return "180"
        case .twoSeventy:
            return "270"
        }
    }
    
    static func random() -> Orientation {
    
        return Orientation(rawValue: Int(arc4random_uniform(4)))!
    }
    
    static func rotate(_ orientation: Orientation, clockwise: Bool) -> Orientation {
        
        var rotate = orientation.rawValue + (clockwise ? 1 : -1)
        if rotate > Orientation.twoSeventy.rawValue {
            rotate = Orientation.zero.rawValue
        } else if rotate < 0 {
            rotate = Orientation.twoSeventy.rawValue
        }
        return Orientation(rawValue: rotate)!
    }
}

class Shape: Hashable, CustomStringConvertible {

    let color: BlockColor;
    var orientation: Orientation;
    var blocks = Array<Block>();
    var column: Int;
    var row: Int;
    
    var blockColumnRowPositions: [Orientation: Array<(columnDiff: Int, rowDiff: Int)>] {
        return [:]
    }
    
    var bottomBlocksForOrientations: [Orientation: Array<Block>] {
        return [:];
    }
    
    var bottomBlocks: Array<Block> {
        if let bottomBlocks = bottomBlocksForOrientations[orientation] {
            return bottomBlocks
        }
        return []
    }
    
    var hashValue: Int {
        return blocks.reduce(0) { $0.hashValue ^ $1.hashValue }
    }
    
    var description: String {
        return "\(color) block facing \(orientation): \(blocks[0]), \(blocks[1]), \(blocks[2]), \(blocks[3])"
    }
    
    convenience init(column:Int, row:Int) {
        self.init(column:column, row:row, color:BlockColor.random(), orientation:Orientation.random())
    }
    
    init(column: Int, row: Int, color: BlockColor, orientation: Orientation) {
        self.color = color
        self.orientation = orientation
        self.column = column
        self.row = row
        
        initializeBlocks()
    }
    
    final func initializeBlocks() {
        if let blockRowColumnTranslations = blockColumnRowPositions[orientation] {
            for i in 0..<blockRowColumnTranslations.count {
                let blockRow = row + blockRowColumnTranslations[i].rowDiff
                let blockColumn = column + blockRowColumnTranslations[i].columnDiff
                let newBlock = Block(column: blockColumn, row: blockRow, color: color)
                blocks.append(newBlock)
            }
        }
    }
    
    final func rotateBlocks(_ orientation: Orientation) {
        if let blockRowColumnTranslation: Array<(columnDiff: Int, rowDiff: Int)> = blockColumnRowPositions[orientation] {
            
            for (idx, diff) in blockRowColumnTranslation.enumerated() {
                blocks[idx].column = column + diff.columnDiff
                blocks[idx].row = row + diff.rowDiff
            }
        }
    }
    
    final func rotateClockwise() {
        let newOrientation = Orientation.rotate(orientation, clockwise: true)
        rotateBlocks(newOrientation)
        orientation = newOrientation;
    }
    
    final func rotateCounterClockwise() {
        let newOrientation = Orientation.rotate(orientation, clockwise: false)
        rotateBlocks(newOrientation)
        orientation = newOrientation
    }
    
    final func shiftBy(_ columns: Int, rows: Int) {
        self.column += columns
        self.row += rows
        rotateBlocks(orientation)
    }
    
    final func raiseShapeByOneRow() {
        
        shiftBy(0, rows: -1)
    }
    
    final func lowerShapeByOneRow() {
        
        shiftBy(0, rows: 1)
    }
    
    final func shiftRightByOneColumn() {
        
        shiftBy(1, rows: 0)
    }
    
    final func shiftLeftByOneColumn() {
        
        shiftBy(-1, rows: 0)
    }
    
    final func moveTo(_ column: Int, row: Int) {
        self.column = column
        self.row = row
        rotateBlocks(orientation)
    }
    
    final class func random(_ startingColumn:Int, startingRow:Int) -> Shape {
        switch Int(arc4random_uniform(7)) {
        // #4
        case 0:
            return SquareShape(column:startingColumn, row:startingRow)
        case 1:
            return LineShape(column:startingColumn, row:startingRow)
        case 2:
            return TShape(column:startingColumn, row:startingRow)
        case 3:
            return LShape(column:startingColumn, row:startingRow)
        case 4:
            return JShape(column:startingColumn, row:startingRow)
        case 5:
            return SShape(column:startingColumn, row:startingRow)
        default:
            return ZShape(column:startingColumn, row:startingRow)
        }
    }
    
    static func ==(lhs: Shape, rhs: Shape) -> Bool {
        return lhs.row == rhs.row && lhs.column == rhs.column
    }
}
