//
//  JShape.swift
//  TestTetris
//
//  Created by arvin on 2017/9/8.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

class JShape: Shape {

    override var blockColumnRowPositions: [Orientation: Array<(columnDiff: Int, rowDiff: Int)>] {
        return [
            Orientation.zero:       [(1, 0), (1, 1),  (1, 2),  (0, 2)],
            Orientation.ninety:     [(2, 1), (1, 1),  (0, 1),  (0, 0)],
            Orientation.oneEighty:  [(0, 2), (0, 1),  (0, 0),  (1, 0)],
            Orientation.twoSeventy: [(0, 0), (1, 0),  (2, 0),  (2, 1)]
        ]
    }
    
    override var bottomBlocksForOrientations: [Orientation: Array<Block>] {
        return [
            Orientation.zero:       [blocks[2], blocks[3]],
            Orientation.ninety:     [blocks[0], blocks[1], blocks[2]],
            Orientation.oneEighty:  [blocks[0], blocks[3]],
            Orientation.twoSeventy: [blocks[0], blocks[1], blocks[3]]
        ]
    }
}
