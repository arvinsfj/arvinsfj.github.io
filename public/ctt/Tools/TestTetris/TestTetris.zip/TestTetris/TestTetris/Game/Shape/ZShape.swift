//
//  ZShape.swift
//  TestTetris
//
//  Created by arvin on 2017/9/8.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

class ZShape: Shape {

    override var blockColumnRowPositions: [Orientation: Array<(columnDiff: Int, rowDiff: Int)>] {
        return [
            Orientation.zero:       [(1, 0), (1, 1), (0, 1), (0, 2)],
            Orientation.ninety:     [(-1,0), (0, 0), (0, 1), (1, 1)],
            Orientation.oneEighty:  [(1, 0), (1, 1), (0, 1), (0, 2)],
            Orientation.twoSeventy: [(-1,0), (0, 0), (0, 1), (1, 1)]
        ]
    }
    
    override var bottomBlocksForOrientations: [Orientation: Array<Block>] {
        return [
            Orientation.zero:       [blocks[1], blocks[3]],
            Orientation.ninety:     [blocks[0], blocks[2], blocks[3]],
            Orientation.oneEighty:  [blocks[1], blocks[3]],
            Orientation.twoSeventy: [blocks[0], blocks[2], blocks[3]]
        ]
    }
}
