// rose cli text editor
// alex scarpantoni 2014
// github.com/ascarp/rose
// render.h

unsigned int render_buffer (buffer_t *buffer, char active, unsigned int top, unsigned int x,
	unsigned int y, int width, int height);

void render_screen();
void render_clear(unsigned int x, unsigned int y, int width, int height);