// rose cli text editor
// alex scarpantoni 2014
// github.com/ascarp/rose
// history.h

#define	CONFIG_HISTORY_SIZE	8

void history_checkpoint(buffer_t *buffer);
buffer_t *history_undo(buffer_t *buffer);
void history_redo(buffer_t *buffer);