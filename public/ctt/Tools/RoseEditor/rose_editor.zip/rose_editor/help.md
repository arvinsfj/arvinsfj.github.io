rose (pronounced rohs-ee)
by alex scarpantoni
http://github.com/ascarp/rose
version: pre-release

to view command breakdown, press H.

### abstract

rose is a minimalist, lightweight text editor.
it's based around a few simple concepts.

### modes

rose has two modes, control and edit.
every key you press in control mode can have an effect on your buffer.
a @ at the bottom represents control mode.
a > represents edit mode.
to switch to edit mode, press <return>.
to switch back to control mode, press <esc>.
you can type a number before any key in control mode to repeat the operation.

### movement

to move around the document, use i j k l.
to page up, page down, home, or end, use I J K L.
to jump to first line, press T.
to jump to a particular line, press T [line number] k.

### editing

to remove a character, use <backspace> or x. use X to store it on the clipboard.
to remove a line, use R. use r to copy it to the clipboard.

to search to the next occurence of contents on the clipboard, press f.

### selection

to turn on selection, press s.
to turn off selection, press s again.
to cut the selection, use x.
to delete the selection without cutting, use X.
to copy the selection, use c.
to paste, use v.

### buffers

everything you view or edit in rose is a buffer.
you can have multiple buffers open at a time.
this help file is currently running in a buffer.
all buffers are identified by a number.
the current buffer is shown in the status bar as { number }.

- to switch buffers, use the <tab> key.
- to create a new buffer, use the N key. (case sensitive)
- to jump to a specific buffer, type the number and then press B
- to close a buffer, press Q
- to list all the buffers you have open, press ?

buffers may associated with files. if a buffer is unsaved, there will be a *
icon next to its name. to save a buffer, you must first link it as a file.
you do this by creating a line in the buffer and writing the filename into it.

- to load the current line as the buffers filename, press E
- to save a buffer to disk, press +
- to read a buffer in from disk, press O

### panes
you can have more than one buffer on the screen at a time.
you do this by splitting the window into panes.
you can split either horizontally or vertically.

- to split the window horizontally, press % (more times, more panes)
- to split the window vertically, press $ (more times, more panes)
- to close the last pane, press #
- to switch between panes, press < or >