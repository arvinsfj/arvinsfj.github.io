// rose cli text editor
// alex scarpantoni 2014
// github.com/ascarp/rose
// buffer.c

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>

#include "buffer.h"
#include "strings.h"

void *buffer_new() {
	buffer_t *initial_buffer;
	line_t *initial_line;

	initial_buffer = malloc(sizeof(buffer_t));
	initial_buffer->line_count = 1;
	initial_buffer->saved = 0;
	initial_buffer->cl = 1;
	initial_buffer->cc = 1;
	initial_buffer->line = malloc(sizeof(line_t));
	initial_buffer->filename = 0;
	initial_buffer->prettyname = LANG_UNTITLED;
	initial_buffer->id = 0;
	initial_buffer->prev_state = 0;
	initial_buffer->next_state = 0;
	initial_buffer->select = 0;
	initial_buffer->sl = 1;
	initial_buffer->sc = 1;

	initial_line = initial_buffer->line;
	initial_line->prev = 0;
	initial_line->next = 0;
	initial_line->size = CONFIG_LINE_ALLOC;
	initial_line->len = 0;
	initial_line->c = malloc(sizeof(char) * CONFIG_LINE_ALLOC);

	initial_line->c[0] = 0;

	return initial_buffer;
}

void buffer_write(buffer_t *buffer) {
	if(buffer->filename == 0)
		return;

	FILE *fh;
	fh = fopen(buffer->filename, "w");
	if(fh == NULL) return;

	line_t *next_line = buffer->line;
	int ll, i;
	while(next_line != 0) {
		ll = next_line->len;
		i = 0;
		while(i < ll) {
			fputc(next_line->c[i] ,fh);
			i++;
		}
		if(next_line->next != 0)
			fputc('\n', fh);

		next_line = next_line->next;
	}

	fclose(fh);

	buffer->saved = 1;
}

void buffer_update_name(buffer_t *buffer) {
	// find last slash
	char namebuffer[CONFIG_NAME_BUFFER_SIZE];
	int j;
	j = strlen(buffer->filename) - 1;
	while( (j >= 0) && (buffer->filename[j] != '/') ) j--;
	strcpy(namebuffer, buffer->filename+j+1);

	buffer->prettyname = malloc(sizeof(char) * (strlen(namebuffer) + 1));
	strcpy(buffer->prettyname, namebuffer);
}

char buffer_read(buffer_t *buffer) {
	int i;

	if(buffer->filename == 0) {
		return 0;
		printf("quitting\n");
	}

	buffer_update_name(buffer);

	// deallocate all lines
	line_t *next_line = buffer->line;
	line_t *line;
	while(next_line != 0) {
		line = next_line->next;
		if(next_line->c != 0)
			free(next_line->c);
		free(next_line);
		next_line = line;
	}

	struct stat s;
	if(stat(buffer->filename, &s) == 0) {
		if(s.st_mode & S_IFDIR) {
			// it's a folder
			DIR *dir;
			struct dirent *ent;
			if((dir = opendir(buffer->filename)) != 0) {
				buffer->line = malloc(sizeof(line_t));
				line_t *lline = buffer->line;
				buffer->line_count = 1;
				lline->prev = 0;
				lline->next = 0;
				lline->size = CONFIG_LINE_ALLOC;
				lline->len = 0;
				lline->c = malloc(sizeof(char) * CONFIG_LINE_ALLOC);
				lline->c[0] = 0;

				while((ent = readdir(dir)) != 0) {
					buffer_insert_string(buffer, ent->d_name);
					buffer_newline(buffer);
				}

				buffer->saved = 2;
				return 1;
			} else {
				return 0;
			}
		}
	} else {
		return 0;
	}

	// load the file
	FILE *fh;
	fh = fopen(buffer->filename, "r");
	if(fh == NULL) return 0;
	
	char c;
	int bi = 0;
	char linebuffer[CONFIG_READ_BUFFER_SIZE];
	line_t *last_line = 0;
	buffer->line_count = 0;
	buffer->cl = 1;
	buffer->cc = 1;
	buffer->line = 0;

	while(!feof(fh)) {
		c = fgetc(fh);
		linebuffer[bi] = c;
		bi++;

		if(bi > CONFIG_READ_BUFFER_SIZE)
			bi = CONFIG_READ_BUFFER_SIZE;

		if((c == '\n') || feof(fh)) {
			//bi--; // strip newline
			bi--;
			linebuffer[bi] = 0; // tie off string
			line = malloc(sizeof(line_t));
			buffer->line_count++;

			if(buffer->line == 0) // if this is first line
				buffer->line = line;

			// allocate space for content - actual size plus alloc
			line->c = malloc(sizeof(char) *
				(bi + CONFIG_LINE_ALLOC));

			strcpy(line->c, linebuffer);
			line->prev = last_line;
			line->next = 0;
			line->size = sizeof(char) *
				(bi + CONFIG_LINE_ALLOC);
			line->len = bi;
			if(last_line != 0)
				last_line->next = line;

			last_line = line;
			bi = 0;
		}

	}
	fclose(fh);
	buffer->saved = 1;
	return 1;
}

void *buffer_find_line(buffer_t *buffer, unsigned int line_no) {
	line_t *line = buffer->line;
	int i;
	for(i = 0; (i < line_no-1) && (line != 0) ; i++) {
		line = line->next;
	}
	return line;
}

unsigned int buffer_line_number(buffer_t *buffer, line_t *line) {
	line_t *cline = buffer->line;
	unsigned int lno = 1;

	while(cline != line) {
		lno++;
		cline = cline->next;
	}

	return lno;
}

void buffer_close(buffer_t *buffer) {
	line_t *next_line = buffer->line;
	line_t *line;
	while(next_line != 0) {
		line = next_line->next;
		if(next_line->c != 0)
			free(next_line->c);
		free(next_line);
		next_line = line;
	}
	free(buffer);
}

void buffer_insert(buffer_t *buffer, char c) {
	line_t *line = buffer_find_line(buffer, buffer->cl);
	
	if(line->len+1 == line->size) {
		line->size += CONFIG_LINE_ALLOC;
		buffer_resize_line(line);
	}

	int i = line->len+1;
	int cc = buffer->cc - 1;
	while(i >= cc) {
		line->c[i+1] = line->c[i];
		i--;
	}

	line->c[buffer->cc-1] = c;
	line->len++;

	buffer->saved = 0;
}

void buffer_insert_string(buffer_t *buffer, char *c) {
	int x;
	int len = strlen(c);
	for(x = 0; x < len; x++) {
		if(c[x] == '\n') {
			buffer_newline(buffer);
			//buffer->cl++;
			buffer->cc = 1;
		} else {
			buffer_insert(buffer, c[x]);
			buffer_move_cursor(buffer, 1, 0);
		}
	}
}

void buffer_move_cursor(buffer_t *buffer, int dx, int dy) {
	buffer->cc += dx;
	int cl = buffer->cl;

	cl += dy;
	if(cl < 1)
		cl = 1;

	buffer->cl = cl;
	if(buffer->cl > buffer->line_count)
		buffer->cl = buffer->line_count;

	if(buffer->cc < 1)
		buffer->cc = 1;

	line_t *line = buffer_find_line(buffer, buffer->cl);
	if(line == 0) {
		buffer->cl -= dy;
		return;
	}

	if(buffer->cc > (line->len + 1) ) {
		if((line->next != 0) && (dy == 0)) {
			buffer->cc = 1;
			buffer->cl ++ ;
		} else {
			buffer->cc = line->len + 1;
		}
	}
}

void buffer_newline(buffer_t *buffer) {
	line_t *newline = malloc(sizeof(line_t));
	line_t *cline = buffer_find_line(buffer, buffer->cl);

	newline->prev = cline;
	newline->next = cline->next;
	cline->next = newline;

	newline->size = cline->size;
	newline->c = malloc(sizeof(char) * cline->size);
	buffer->line_count++;

	int i = buffer->cc-1;
	int j = 0;
	while(i < cline->len) {
		newline->c[j] = cline->c[i];
		cline->c[i] = 0;
		i++;
		j++;
	}

	cline->len -= j;

	newline->c[j] = 0;
	newline->len = j;
	buffer->cl++;
	buffer->cc = 1;

	buffer->saved = 0;
}

char buffer_delete(buffer_t *buffer) {
	line_t *cline = buffer_find_line(buffer, buffer->cl);
	char *c = cline->c;

	int i = buffer->cc;
	/*if ((i == 1) && (cline->len <= 1)) {
		c[0] = 0;
		cline->len = 0;
		return;
	}*/
	char tr = 0;
	char ch = c[i-1];
	while( i <= cline->len ) {
		tr = 1;
		c[i-1] = c[i];
		c[i] = 0;
		i++;
	}

	if(tr) {
		cline->len--;
		buffer->saved = 0;
	}


	if(buffer->cc > (cline->len))
		buffer->cc = cline->len + 1;

	return ch;
}

void buffer_backspace(buffer_t *buffer) {
	line_t *cline = buffer_find_line(buffer, buffer->cl);
	buffer->cc --;

	if(buffer->cc == 0) {
		if(buffer->cl == 1) {
			buffer->cc = 1;
			return;			
		}

		line_t *pline = cline->prev;

		unsigned int newpos = pline->len+1;
		buffer_join_line(buffer);
		buffer->cc = newpos;
		if(buffer->cc == 0)
			buffer->cc = 1;
		buffer->cl--;
	} else {
		buffer_delete(buffer);
	}
}

void buffer_join_line(buffer_t *buffer) {
	line_t *line2 = buffer_find_line(buffer, buffer->cl);
	line_t *line1 = line2->prev;

	unsigned int new_length = line1->len + line2->len;
	if(new_length > line1->size) {
		line1->size = new_length + CONFIG_LINE_ALLOC;
		buffer_resize_line(line1);
	}

	strncpy(line1->c + line1->len, line2->c, line2->len);
	line1->len = new_length;

	free(line2->c);
	line1->next = line2->next;
	if(line2->next != 0) {
		line_t *line3 = line2->next;
		line3->prev = line1;
	}
	free(line2);
	buffer->saved = 0;
	buffer->line_count--;
}

void buffer_resize_line(line_t *line) {
	char *new_line = malloc(sizeof(char) * (line->size));
	strcpy(new_line, line->c);
	free(line->c);
	line->c = new_line;
}

void buffer_delete_line(buffer_t *buffer) {
	char *c = buffer_cut_line(buffer);
	free(c);
}

char *buffer_cut_line(buffer_t *buffer) {
	char *content;

	line_t *line2 = buffer_find_line(buffer, buffer->cl);
	
	if(buffer->line_count == 1) {
		buffer->cc = 1;
		content = line2->c;
		line2->c = malloc(sizeof(char) * CONFIG_LINE_ALLOC);
		line2->c[0] = 0;
		line2->len = 0;
		line2->size = CONFIG_LINE_ALLOC;
		return content;
	}

	line_t *line1 = line2->prev;
	
	if(line1 == 0) {
		buffer->line = line2->next;
	} else {
		line1->next = line2->next;
	}

	if(line2->next != 0) {
		line_t *line3 = line2->next;
		line3->prev = line1;
	}

	content = line2->c;
	free(line2);

	buffer->line_count--;
	if(buffer->cl > buffer->line_count)
		buffer->cl = buffer->line_count;

	return content;
}

void buffer_toggle_selection(buffer_t *buffer) {
	if(buffer->select) {
		buffer->select = 0;
	} else {
		buffer->select = 1;
		buffer->sl = buffer->cl;
		buffer->sc = buffer->cc;
	}
}

void buffer_name_from_line(buffer_t *buffer) {
	line_t *line = buffer_find_line(buffer, buffer->cl);
	unsigned int llen = line->len;
	buffer->filename = malloc(sizeof(char) * llen);
	strcpy(buffer->filename, line->c);
	buffer_delete_line(buffer);
	buffer_update_name(buffer);
}

void buffer_seek(buffer_t *buffer, char *s) {
	line_t *cline = buffer_find_line(buffer, buffer->cl);
	int cc = buffer->cc-1;
	int sc = 0;
	int lc = 0;

	while(sc < strlen(s)) {
		char c = cline->c[cc];

		if(c == s[sc]) {
			sc++;
		} else {
			sc = 0;

		}

		cc ++;

		if(cc > cline->len) {
			if(cline->next == 0)
				return;
			else {
				cc = 0;
				cline = cline->next;
				lc++;
			}
		}

	}

	buffer->cl += lc;
	buffer->cc = cc;


}

unsigned int buffer_selection_size(buffer_t *buffer) {
	if (!( (buffer->select) && (buffer->sl <= buffer->cl) && 
		!( (buffer->sl == buffer->cl) && (buffer->sc > buffer->cc) ))) {

		return 0;
	}

	// count characters
	unsigned int count = 0;
	int cl = buffer->sl;
	int cc = buffer->sc-1;
	line_t *cline = buffer_find_line(buffer, buffer->sl);

	while( (cl < buffer->cl) || ( (cl == buffer->cl) && (cc < buffer->cc) )) {
		count++;
		cc++;

		if(cc >= cline->len) {
			if(cline->next == 0) break;
			cc = 0;
			cline = cline->next;
			count++;
			cl++;
		}
	}

	return count;
}

char *buffer_get_selection(buffer_t *buffer) {
	unsigned int size = buffer_selection_size(buffer);

	// allocate space, do copy
	char *selection = malloc(sizeof(char) * (size + 1));
	int cl = buffer->sl;
	int cc = buffer->sc - 1;
	line_t *cline = buffer_find_line(buffer, buffer->sl);
	int bc = 0;
	while( (cl < buffer->cl) || ( (cl == buffer->cl) && (cc < buffer->cc) )) {
		selection[bc] = cline->c[cc];
		cc++;
		bc++;

		if(cc >= cline->len) {
			cc = 0;
			cline = cline->next;
			selection[bc] = '\n';
			bc++;
			cl++;
		}
	}
	selection[bc] = 0;

	return selection;

}

void buffer_remove_selection(buffer_t *buffer) {
	unsigned int size = buffer_selection_size(buffer);
	int i;
	for(i = 0 ; i < size; i++) {
		buffer_backspace(buffer);
	}
}

void buffer_seek_back_word(buffer_t *buffer) {
	line_t *line = buffer_find_line(buffer, buffer->cl);
	int cc = buffer->cc;
	cc-=2;

	while(cc > 1) {
		cc--;
		if( (line->c[cc] == ' ') || (line->c[cc] == '\t') ) {
			buffer->cc = cc+1;
			break;
		}
	}
}

void buffer_seek_forward_word(buffer_t *buffer) {
	line_t *line = buffer_find_line(buffer, buffer->cl);
	int cc = buffer->cc;
	//cc-=2;

	while(cc <= (line->len)) {
		cc++;
		if( (line->c[cc] == ' ') ||
			(line->c[cc] == '\t') ||
			(cc == (line->len)) ) {
			buffer->cc = cc+1;
			break;
		}
	}
}
