## rose

minimal cli text editor

rose is designed to be simple, light, and quick to use once you get the hang of it.

![screenshot](screen.png)

- written in C
- allows editing of multiple buffers
- window can be split into multiple panes
- two editing modes: "control" and "insert"
- key bindings that even work well on touch keyboards

### current status
- loads files
- saves files
- can split screen into panes
- general editing (insert, delete, new lines etc)
- searching

### what's not done
- full command set not implemented
- no replace
- no undo