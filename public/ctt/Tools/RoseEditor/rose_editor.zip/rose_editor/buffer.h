// rose cli text editor
// alex scarpantoni 2014
// github.com/ascarp/rose
// buffer.h

#define CONFIG_LINE_ALLOC	32
#define CONFIG_READ_BUFFER_SIZE	64*1024
#define CONFIG_NAME_BUFFER_SIZE	64

typedef struct {
	void *prev;
	void *next;
	unsigned int size;
	unsigned int len;
	char *c;
} line_t;

typedef struct {
	unsigned int line_count;
	unsigned int cl;
	unsigned int cc;
	void *line;
	char *filename;
	char *prettyname;
	char saved;
	unsigned int id;
	unsigned int sl;
	unsigned int sc;
	char select;
	void *next_state;
	void *prev_state;
} buffer_t;

void *buffer_new();
char buffer_read(buffer_t *buffer);
void buffer_close(buffer_t *buffer);
void buffer_write(buffer_t *buffer);
void *buffer_find_line(buffer_t *buffer, unsigned int line_no);
void buffer_move_cursor(buffer_t *buffer, int dx, int dy);
void buffer_insert(buffer_t *buffer, char c);
void buffer_insert_string(buffer_t *buffer, char *c);
void buffer_newline(buffer_t *buffer);
unsigned int buffer_line_number(buffer_t *buffer, line_t *line);
char buffer_delete(buffer_t *buffer);
void buffer_backspace(buffer_t *buffer);
void buffer_blank(buffer_t *buffer);
void buffer_join_line(buffer_t *buffer);
void buffer_delete_line(buffer_t *buffer);
char *buffer_cut_line(buffer_t *buffer);
void buffer_resize_line(line_t *line);
void buffer_toggle_selection(buffer_t *buffer);
void buffer_name_from_line(buffer_t *buffer);
void buffer_update_name(buffer_t *buffer);
void buffer_move_cursor(buffer_t *buffer, int dx, int dy);
void buffer_seek(buffer_t *buffer, char *s);
void buffer_seek_back_word(buffer_t *buffer);
void buffer_seek_forward_word(buffer_t *buffer);
char *buffer_get_selection(buffer_t *buffer);
void buffer_remove_selection(buffer_t *buffer);
unsigned int buffer_selection_size(buffer_t *buffer);