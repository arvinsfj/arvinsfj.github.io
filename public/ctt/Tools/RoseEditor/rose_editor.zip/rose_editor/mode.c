// rose cli text editor
// alex scarpantoni 2014
// github.com/ascarp/rose
// mode.c

#include <ncurses.h>
#include <stdlib.h>
#include <string.h>

#include "buffer.h"
#include "render.h"
#include "mode.h"
#include "strings.h"
#include "rose.h"
#include "history.h"

unsigned int repeat_counter;

void mode_control_run () {
	char c;
	repeat_counter = 0;
	render_screen();
	while((mode == CONTROL) && (c = getch())) {
		// 48 is zero
		if( (c >= 48) && (c <= 58) ) {
			repeat_counter = (repeat_counter * 10) + (c-48);
			continue;
		}
		unsigned int input = repeat_counter;
		if(repeat_counter == 0)
			repeat_counter = 1;
		int i;
		if(c != 'u') history_checkpoint(buffers[panes[cpane]]);
		for(i=0; i < repeat_counter; i++) {

			if(c == 'Q') {
				mc_quit();
			} else if(c == 'k') {
				mc_move_cursor(0, 1);
			} else if(c == 'i') {
				mc_move_cursor(0, -1);
			} else if(c == 'l') {
				mc_move_cursor(1, 0);
			} else if(c == 'j') {
				mc_move_cursor(-1, 0);
			} else if(c == 'K') {
				mc_move_cursor(0, pane_lines[cpane]/2);
			} else if(c == 'I') {
				mc_move_cursor(0, 0-pane_lines[cpane]/2);
			} else if(c == 'L') {
				mc_end();
			} else if(c == 'J') {
				mc_home();
			} else if(c == 'T') {
				mc_top();
			} else if((c == 10) || (c == 'n')) {
				mode = INSERT;
				break;
			} else if(c == 'x') {
				buffer_t *buffer = buffers[panes[cpane]];
				if(buffer->select) {
					char *selection = buffer_get_selection(buffer);
					if(selection) {
						buffer_remove_selection(buffer);
						strcpy(clipboard, selection);
						free(selection);
						buffer->select = 0;
					}
				} else {
					buffer_delete(buffer);
				}
			} else if(c == 'X') {
				buffer_t *buffer = buffers[panes[cpane]];
				if(!buffer->select) {
					char deleted = buffer_delete(buffers[panes[cpane]]);
					clipboard[0] = deleted;
					clipboard[1] = 0;
				} else {
					buffer_remove_selection(buffer);
				}
			} else if(c == 8) {
				buffer_delete(buffers[panes[cpane]]);
			} else if(c == 127) {
				buffer_backspace(buffers[panes[cpane]]);
			} else if(c == 'W') {
				buffer_write(buffers[panes[cpane]]);
			} else if(c == 'R') {
				buffer_delete_line(buffers[panes[cpane]]);
			} else if(c == 's') {
				buffer_toggle_selection(buffers[panes[cpane]]);
			} else if(c == '%') {
				mc_split_h();
			} else if(c == '$') {
				mc_split_v();
			} else if(c == '#') {
				if(pane_count == 1) {
					layout = NONE;
				} else {
					pane_count --;
				}
			} else if(c == '<') {
				if(cpane > 0)
					cpane--;
			} else if(c == '>') {
				if(cpane < pane_count-1)
					cpane++;
			} else if(c == 'B') {
				if((repeat_counter < CONFIG_BUFFER_COUNT) &&
					(buffers[input] != 0)) {

					panes[cpane] = input;
				}
				repeat_counter = 0;
			} else if(c == 'N') {
				panes[cpane] = mc_new_buffer();
			} else if(c == 'O') {
				buffer_read(buffers[panes[cpane]]);
			} else if(c == 'E') {
				buffer_name_from_line(buffers[panes[cpane]]);
			} else if(c == '\t') {
				int ii;
				for(ii = panes[cpane]+1; ii <= CONFIG_BUFFER_COUNT; ii++) {
					if(ii == CONFIG_BUFFER_COUNT) ii = 0;

					if(buffers[ii] != 0) {
						panes[cpane] = ii;
						break;
					}
				}
			} else if(c == 'h') {
				int newbuf = mc_new_buffer();
				panes[cpane] = newbuf;
				buffer_t *bnewbuf = buffers[newbuf];
				bnewbuf->prettyname = LANG_HELP_TITLE;
				buffer_insert_string(bnewbuf, LANG_HELP);
				bnewbuf->saved = 2;
				mc_top();
			} else if(c == 'H') {
				int newbuf = mc_new_buffer();
				panes[cpane] = newbuf;
				buffer_t *bnewbuf = buffers[newbuf];
				bnewbuf->prettyname = LANG_COMMANDS_TITLE;
				buffer_insert_string(bnewbuf, LANG_COMMANDS);
				bnewbuf->saved = 2;
				mc_top();
			} else if(c == 'v') {
				buffer_insert_string(buffers[panes[cpane]], clipboard);
			} else if(c == 'r') {
				char *linec = buffer_cut_line(buffers[panes[cpane]]);
				if(linec != 0) {
					strcpy(clipboard, linec);
					free(linec);
				}
			} else if(c == 'C') {
				buffer_t *buffer = buffers[panes[cpane]];
				line_t *line = buffer_find_line(buffers[panes[cpane]], buffer->cl);
				char *linec = line->c;
				if(line != 0) {
					strcpy(clipboard, linec);
				}
			} else if(c == 'c') {
				buffer_t *buffer = buffers[panes[cpane]];
				line_t *line = buffer_find_line(buffers[panes[cpane]], buffer->cl);
				char *linec = line->c;
				if(buffer->select) {
					char *selection = buffer_get_selection(buffers[panes[cpane]]);
					strcpy(clipboard, selection);
					if(selection) free(selection);
					buffer->select = 0;
				} else {
					clipboard[0] = linec[buffer->cc-1];
					clipboard[1] = 0;
				}
			} else if(c == 'P') {
				mc_home();
				buffer_newline(buffers[panes[cpane]]);
				mc_move_cursor(0,-1);
			} else if(c == 'p') {
				mc_end();
				buffer_newline(buffers[panes[cpane]]);
				mc_home();
			} else if(c == '?') {
				mc_bufferlist();
			} else if(c == 'f') {
				buffer_seek(buffers[panes[cpane]], clipboard);
			} else if(c == 'u') {
				buffer_t *oldstate = history_undo(buffers[panes[cpane]]);
				buffers[panes[cpane]] = oldstate;
			} else if(c == 'r') {
				history_redo(buffers[panes[cpane]]);
			} else if(c == 'a') {
				buffer_seek_back_word(buffers[panes[cpane]]);
			} else if(c == 'd') {
				buffer_seek_forward_word(buffers[panes[cpane]]);
			}
		}

		if(buffers_count == 0) {
			mode = QUIT;
			return;
		}

		repeat_counter = 0;
		
		render_screen();
	
	}
}

unsigned int mc_new_buffer() {
	unsigned int ii;
	for(ii = 0; ii < CONFIG_BUFFER_COUNT; ii++) {
		if(buffers[ii] == 0) {
			buffers[ii] = buffer_new();
			buffers_count++;
			buffers[ii]->id = ii;
			return ii;
		}
	}
}

void mode_insert_run() {
	char c;
	render_screen();
	while((mode == INSERT) && (c = getch())) {
		if(c == 127) {
			buffer_backspace(buffers[panes[cpane]]);
		} else if(c == 27) {
			mode = CONTROL;
			continue;
		} else if(c == 10) {
			buffer_newline(buffers[panes[cpane]]);
		} else {
			buffer_insert(buffers[panes[cpane]], c);
			mc_move_cursor(1,0);
		}

		render_screen();
	}
}

void mc_move_cursor(int dx, int dy) {
	buffer_t *buffer = buffers[ panes[cpane] ];
	buffer_move_cursor(buffer, dx, dy);
}

void mc_home() {
	buffer_t *buffer = buffers[panes[cpane]];
	unsigned int oldpos = buffer->cc;
	buffer->cc = 1;

	line_t *line = buffer_find_line(buffer, buffer->cl);

	while( (line->c[buffer->cc-1] == '\t') || (line->c[buffer->cc-1] == ' ') ) {
		buffer->cc++;
		if(buffer->cc >= line->len)
			break;
	}

	if(oldpos == buffer->cc)
		buffer->cc = 1;
}

void mc_end() {
	buffer_t *buffer = buffers[panes[cpane]];
	line_t *line = buffer_find_line(buffer, buffer->cl);

	buffer->cc = line->len + 1;
}

void mc_top() {
	buffer_t *buffer = buffers[panes[cpane]];
	buffer->cl = 1;
	line_t *line = buffer_find_line(buffer, 1);
	if(buffer->cc > line->len)
		buffer->cc = line->len;
	if(buffer->cc == 0)
		buffer->cc = 1;
}

void mc_bufferlist() {
	int newbuf = mc_new_buffer();
	panes[cpane] = newbuf;
	buffer_t *bnewbuf = buffers[newbuf];
	bnewbuf->prettyname = LANG_BUFFER_LIST;
	buffer_t *cbuf;
	char bbuffer[BUFFER_LIST_BUFFER_SIZE];
	int ii;

	for(ii = 0; ii < CONFIG_BUFFER_COUNT; ii++) {
		if(buffers[ii] == 0) continue;
		if(ii == bnewbuf->id) continue;
		cbuf = buffers[ii];
		sprintf(bbuffer, "%d %s\n", cbuf->id, cbuf->prettyname);
		buffer_insert_string(bnewbuf, bbuffer);
	}

	bnewbuf->saved = 2;
	mc_top();
}

void mc_split_h() {
	if(((pane_count == 1) || (layout == HORIZONTAL)) && (pane_count < CONFIG_PANE_COUNT)) {
		panes[pane_count] = panes[pane_count-1];
		
		if(buffers[panes[pane_count-1] + 1] != 0)
			panes[pane_count] = panes[pane_count-1] + 1;

		pane_count++;
	}
	if(layout != HORIZONTAL) {
		layout = HORIZONTAL;
	}
}

void mc_split_v() {
	if(((pane_count == 1) || (layout == VERTICAL)) && (pane_count < CONFIG_PANE_COUNT)) {
		panes[pane_count] = panes[pane_count-1];
		
		if(buffers[panes[pane_count-1] + 1] != 0)
			panes[pane_count] = panes[pane_count-1] + 1;

		pane_count ++;
	}
	if(layout != VERTICAL) {
		layout = VERTICAL;
	}
}

void mc_quit() {
	buffer_close(buffers[panes[cpane]]);
	int ii = panes[cpane];
	buffers[panes[cpane]] = 0;

	buffers_count --;
	
	if(buffers_count == 0) return;

	while(1) {
		if(ii < 0) ii=CONFIG_BUFFER_COUNT-1;

		if(buffers[ii] != 0) {
			panes[cpane] = ii;
			return;
		}
		ii--;
	}
}