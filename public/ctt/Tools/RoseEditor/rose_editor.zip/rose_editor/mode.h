// rose cli text editor
// alex scarpantoni 2014
// github.com/ascarp/rose
// mode.h

#define BUFFER_LIST_BUFFER_SIZE	128

typedef enum {
	CONTROL,
	INSERT,
	QUIT
} emode_t;

void mode_control_run();
void mode_insert_run();

void mc_move_cursor(int dx, int dy);

void mc_home();
void mc_end();
void mc_top();
void mc_bufferlist();
void mc_split_h();
void mc_split_v();
void mc_quit();

unsigned int mc_new_buffer();
void mc_list_buffers();