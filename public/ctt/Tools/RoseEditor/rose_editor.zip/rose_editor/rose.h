// rose cli text editor
// alex scarpantoni 2014
// github.com/ascarp/rose
// rose.h

#define CONFIG_BUFFER_COUNT	32
#define CONFIG_PANE_COUNT	4
#define CONFIG_CLIPBOARD_SIZE	128*1024

typedef enum {
	HORIZONTAL,
	VERTICAL,
	NONE
} layout_t;

emode_t mode;
buffer_t *buffers[CONFIG_BUFFER_COUNT];
unsigned int panes[CONFIG_PANE_COUNT];
unsigned int pane_tops[CONFIG_PANE_COUNT];
unsigned int pane_lines[CONFIG_PANE_COUNT];
char clipboard[CONFIG_CLIPBOARD_SIZE];
layout_t layout;
unsigned int cpane;
unsigned int pane_count;
unsigned int cux;
unsigned int cuy;
unsigned int buffers_count;