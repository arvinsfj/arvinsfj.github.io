rose command breakdown

### modes

- <return> or n, enter insert mode
- <esc> enter control mode

### cursor

- i - cursor up
- k - cursor down
- j - cursor right
- l - cursor left
- d - next word
- a - previous word
- I - page up
- K - page down
- J - home
- L - end
- T - cursor to top line

### editing

- x - delete a char (or cut selection)
- X - cut a char (or delete selection)
- R - delete a line
- r - cut a line
- c - copy a character (or selection)
- C - copy the current line
- v - paste the clipboard
- s - toggle selection
- P - new line above
- p - new line below

### buffers

- ? - list buffers
- <tab> - next buffer
- (number) B - load buffer (number) into current pane
- E - cut the current line, use it as buffer filename
- W - save buffer to file
- N - create a new buffer
- O - load file into buffer
- Q - close buffer

### panes

- % - split horizontally (or add a pane)
- $ - split vertically (or add a pane)
- # - close a pane
- < - previous pane
- > - next pane

### navigation

- f - find from clipboard