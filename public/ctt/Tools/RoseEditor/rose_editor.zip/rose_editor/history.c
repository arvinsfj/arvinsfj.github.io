// rose cli text editor
// alex scarpantoni 2014
// github.com/ascarp/rose
// history.c

#include <string.h>
#include <stdlib.h>

#include "buffer.h"
#include "history.h"

void history_checkpoint(buffer_t *buffer) {
	// if an old state exists, get rid of it and the duped lines
	buffer_t *oldbuf = 0;
	if(buffer->prev_state != 0) {
		oldbuf = buffer->prev_state;
		buffer_close(oldbuf);
		buffer->next_state = 0;
	}

	buffer_t *newbuf = malloc(sizeof(buffer_t));
	buffer->prev_state = newbuf;
	memcpy(newbuf, buffer, sizeof(buffer_t));
	newbuf->line = 0;
	newbuf->prev_state = 0;

	line_t *line = buffer->line;
	line_t *lline = 0;
	line_t *nline = 0;

	while(line != 0) {
		nline = malloc(sizeof(line_t));
		memcpy(nline, line, sizeof(line_t));
		nline->c = malloc(sizeof(char) * (line->len + 1));
		strcpy(nline->c, line->c);

		nline->prev = lline;
		if(lline == 0)
			newbuf->line = nline;
		else
			lline->next = nline;

		lline = nline;
		line = line->next;
	}

}

buffer_t *history_undo(buffer_t *buffer) {
	if(buffer->prev_state == 0) return buffer;
	buffer_t *oldstate = buffer->prev_state;
	buffer_close(buffer);
	return oldstate;
}

void history_redo(buffer_t *buffer) {


}
