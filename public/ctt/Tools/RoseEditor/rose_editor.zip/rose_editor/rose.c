// rose cli text editor
// alex scarpantoni 2014
// github.com/ascarp/rose
// rose.c

#include <ncurses.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "strings.h"
#include "mode.h"
#include "buffer.h"
#include "render.h"
#include "rose.h"

int main (int argc, char** argv) {
	initscr();
	noecho();
	cbreak();
	//curs_set(0);

	cux = 0;
	cuy = 0;

	clipboard[0] = 0;

	int i;
	for(i = 0; i < CONFIG_BUFFER_COUNT; i++) {
		buffers[i] = 0;
	}

	for(i = 0; i < CONFIG_PANE_COUNT; i++) {
		panes[i] = 0;
		pane_tops[i] = 0;
		pane_lines[i] = 0;
	}
	
	if(argc > 1) {
		for(i = 1; i < argc; i++) {
			buffers[i-1] = buffer_new();
			buffers[i-1]->id = i-1;
			buffers[i-1]->filename = argv[i];
			buffer_read(buffers[i-1]);
			buffers_count++;
		}
	} else {
		buffers[0] = buffer_new();
		buffers[0]->id = 0;
		buffers_count = 1;
	}

	layout = NONE;
	mode = CONTROL;
	cpane = 0;
	pane_count = 1;

	while(mode != QUIT) {
		if(mode == CONTROL) {
			mode_control_run();
		} else if(mode == INSERT) {
			mode_insert_run();
		} else if(mode == QUIT) {
			break;
		}

	}

	curs_set(1); // show cursor
	endwin();

	return 0;
}	