// rose cli text editor
// alex scarpantoni 2014
// github.com/ascarp/rose
// render.c

#include <ncurses.h>

#include "buffer.h"
#include "render.h"
#include "mode.h"
#include "rose.h"

unsigned int render_buffer(buffer_t *buffer, char active, unsigned int top, unsigned int x,
	unsigned int y, int width, int height) {

	unsigned int cx = buffer->cc;
	unsigned int screen_size = width * height;
	unsigned int current_x = 0;
	unsigned int current_y = 0;
	unsigned int current_c = 0;
	unsigned int buffer_line = 0;
	char padchar = '~';
	char validselect = 0;
	int lines_to_render = height - 1;

	if( (buffer->select) && active && (buffer->sl <= buffer->cl) && 
		!( (buffer->sl == buffer->cl) && (buffer->sc > buffer->cc) )) {

			validselect = 1;

	}
	
	line_t *line = buffer_find_line(buffer, top);
	line_t *cline = line;

	while(current_y < height - 1) {
		// check if current line is too big
		if(cline->len > screen_size) {
			if(cline != line) {
				padchar = '%';
				break;
			}

			// else render from screenful
			int screenful = cx % screen_size;
			current_c = screenful * screen_size;
		}

		// render from current_c
		while(current_c <= cline->len) {
			if(validselect &&
				(buffer->sl == buffer_line + top) &&
				(buffer->sc-1 == current_c)) {
			
				attron(A_STANDOUT);
			}

			if (active &&
				(buffer->cl == buffer_line + top) &&
				(buffer->cc-1 == current_c)) {

				cux = x + current_x;
				cuy = y + current_y;
			}

			if(cline->c[current_c] == '\t') {
				current_x += 8;
			} else if(cline->c[current_c] != 0) {
				mvaddch(y + current_y, x + current_x,
					cline->c[current_c]);
				current_x++;
			}

			if(validselect &&
				(buffer->cl == buffer_line + top) &&
				(buffer->cc-1 == current_c)) {
			
				attroff(A_STANDOUT);
			}

			current_c++;
			if(current_x > width) {
				current_x = 0;
				current_y++;
				if(current_y > height)
					break;
			}
		}

		// advance line
		current_y++;
		cline = cline->next;
		buffer_line++;
		current_c = 0;
		current_x = 0;
		if(cline == 0)
			break;
	}
	
	while(current_y < height - 1) {
		mvaddch(y + current_y, x, padchar);
		current_y++;
	}

	char statuslinebuffer[width + 1];
	char savechar = 0;
	if(buffer->saved == 0)
		savechar = '*';
	else if(buffer->saved == 1)
		savechar = ' ';
	else if(buffer->saved == 2)
		savechar = '+';

	char modechar;

	if(mode == CONTROL)
		modechar = '@';
	else
		modechar = '>';
	

	snprintf(statuslinebuffer, width + 1, "%c %d:%d {%d} %c%s ", modechar,
		buffer->cl, buffer->cc, buffer->id, savechar, buffer->prettyname);

	attroff(A_STANDOUT);
	attron(A_STANDOUT);
	mvaddstr(y + height-1, x, statuslinebuffer);
	attroff(A_STANDOUT);

	return buffer_line-1;
}

void render_screen() {
	erase();

	int i, mx, my;
	getmaxyx(stdscr, my, mx);

	line_t *line;
	buffer_t *buffer;

	int render_width;
	int render_height;

	int h_mult = 0;
	int v_mult = 0;

	if(layout == HORIZONTAL) {
		render_width = mx / pane_count;
		render_height = my;
		h_mult = render_width;
	} else if(layout == VERTICAL) {
		render_height = my / pane_count;
		render_width = mx;
		v_mult = render_height;
	} else {
		render_height = my;
		render_width = mx;
	}

	for(i = 0; i < pane_count; i++) {
		buffer = buffers[panes[i]];

		if(buffer == 0) {
			int ii;
			for(ii = panes[i]+1; ii <= CONFIG_BUFFER_COUNT; ii++) {
				if(ii == CONFIG_BUFFER_COUNT) ii = 0;

				if(buffers[ii] != 0) {
					panes[i] = ii;
					break;
				}
			}
		}

		buffer = buffers[panes[i]];

		
		if(pane_tops[i] == 0)
			pane_tops[i] = 1;

		if(buffer->cl < pane_tops[i]) {
			pane_tops[i] = buffer->cl;
		}

		unsigned int lines_rendered = render_buffer(buffer, (cpane==i),
			pane_tops[i], h_mult*i, v_mult*i, render_width,
			render_height);

		pane_lines[i] = lines_rendered;

		while( buffer->cl > pane_tops[i] + lines_rendered ) {
			pane_tops[i]++;

			render_clear(h_mult*i, v_mult*i, render_width,
				render_height);

			lines_rendered = render_buffer(buffer,(cpane==i),
				pane_tops[i], h_mult*i, v_mult*i, render_width,
				render_height);

			pane_lines[i] = lines_rendered;
		}


	}
	
	move(cuy, cux);
	refresh();
}

void render_clear(unsigned int x, unsigned int y, int width, int height) {
	int xi,yi;

	for(yi=y; yi < y+height; yi++) {
		for(xi=x; xi < x+width; xi++) {
			mvaddch(yi,xi,' ');
		}
	}

}