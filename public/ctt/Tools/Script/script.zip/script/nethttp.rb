#!/usr/bin/ruby -w
# -*- coding: utf-8 -*-

require 'net/http'

#Net::HTTP.version_1_2   # 设定对象的运作方式
Net::HTTP.start 'www.baidu.com' do |http|
    resp = http.get '/'
    puts resp.body
end

