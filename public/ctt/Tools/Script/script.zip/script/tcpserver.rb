#!/usr/bin/ruby -w
# -*- coding: utf-8 -*-

require 'socket'

s = TCPServer.open 9999
loop {
	sock = s.accept
	Thread.start sock do |client|
		client.puts "Welcome!"
		client.puts Time.now.ctime
		client.close
	end
}
