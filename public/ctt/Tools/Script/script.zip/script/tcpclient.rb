#!/usr/bin/ruby -w
# -*- coding: utf-8 -*-

require 'socket'

s = TCPSocket.open "www.sina.com.cn", 80
s.puts "GET / HTTP/1.1\r\nHost: www.sina.com.cn\r\nConnection: close\r\n\r\n"
resp = s.read
s.close
header, body = resp.split "\r\n\r\n", 2
puts header
File.open "./sina.html", "wb" do |html|
    html.puts body
end


