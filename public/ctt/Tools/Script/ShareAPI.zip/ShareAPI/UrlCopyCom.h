//
//  RenrenCom.h
//  shareDemo
//
//  Created by WEICHANG CHEN on 17/2/8.
//  Copyright © 2017年 WEICHANG CHEN. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ShareComProto.h"

@interface UrlCopyCom : NSObject <ShareComProto>

@end
