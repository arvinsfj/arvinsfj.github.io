//
//  RenrenCom.m
//  shareDemo
//
//  Created by WEICHANG CHEN on 17/2/8.
//  Copyright © 2017年 WEICHANG CHEN. All rights reserved.
//

#import "UrlCopyCom.h"

@interface UrlCopyCom ()
{
    void (^loginBlock)(NSString *tokenKey, NSString *accessToken, NSString *uid, id<ShareComProto>shareCom, NSError *err);
}

@end

@implementation UrlCopyCom

//组件初始化
- (BOOL)isShareComShow
{
    return YES;
}
- (BOOL)shareSetup
{
    return YES;
}
- (BOOL)shareOpenURL:(NSURL *)url
{
    return NO;
}

//登录和绑定
- (BOOL)isComCanLogin
{
    return NO;
}
- (NSString *)getLoginType
{
    return LOGIN_URLCOPY;
}
- (void)shareLogin:(void (^)(NSString *, NSString *, NSString *, id<ShareComProto>, NSError *))block
{
    loginBlock = block;
    // 新浪微博登录
}

//分享
- (NSArray *)getShareType
{
    return @[SHARE_URLCOPY];
}
- (void)share:(NSString *)title andDesc:(NSString *)desc andImg:(NSData *)img andUrl:(NSString *)url andShareType:(NSString *)snsName
{
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = url;
    [AlertInfoUtil alertInfo:@"复制成功" andTime:AlertTime];
}

@end
