//
//  SinaCom.h
//  iFuWoiPhone
//
//  Created by arvin on 2017/2/6.
//  Copyright © 2017年 fuwo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ShareComProto.h"

@interface SinaCom : NSObject <ShareComProto>

@end
