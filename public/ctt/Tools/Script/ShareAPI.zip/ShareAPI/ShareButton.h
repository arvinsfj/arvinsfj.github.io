//
//  ShareButton.h
//  iFuWoiPhone
//
//  Created by arvin on 16/7/18.
//  Copyright © 2016年 fuwo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShareButton : UIButton

@end
