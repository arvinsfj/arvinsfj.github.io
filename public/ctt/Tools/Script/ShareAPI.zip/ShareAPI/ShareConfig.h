//
//  ShareConfig.h
//  iFuWoiPhone
//
//  Created by arvin on 2017/2/6.
//  Copyright © 2017年 fuwo. All rights reserved.
//

#ifndef ShareConfig_h
#define ShareConfig_h

#import <TencentOpenAPI/TencentOAuth.h>
#import <TencentOpenAPI/QQApiInterface.h>
#import <TencentOpenAPI/TencentApiInterface.h>
#import "WeiboSDK.h"
#import "WXApi.h"

#define WX_APPID            @"wx7d749f4cb3c54306"
#define WX_APPSECRET        @"0a8410944ae06a1a3cb91bb502c54080"
#define QQ_APPID            @"1105517064"
#define SINA_APPID          @"445104309"
#define SINA_REDIRECTURI    @"http://www.weibo.com"

#define LOGIN_SINA          @"1"
#define LOGIN_WECHAT        @"10"
#define LOGIN_QQ            @"5"//7

#define SHARE_SINA          @"sina"
#define SHARE_WECHAT_S      @"wechat_session"
#define SHARE_WECHAT_T      @"wechat_timeline"
#define SHARE_QQ            @"qq"//7

#define SHARECOMS           @[@"WechatCom", @"QQCom", @"SinaCom"]

#define LOGIN_VIEW          @{LOGIN_SINA:@[@"微博", @"sina_icon.png"], LOGIN_WECHAT:@[@"微信", @"wechat_icon.png"], LOGIN_QQ:@[@"QQ", @"qq_icon.png"]}
#define SHARE_VIEW          @{SHARE_SINA:@[@"微博", @"sina_icon.png"], SHARE_WECHAT_S:@[@"微信", @"wechat_icon.png"], SHARE_WECHAT_T:@[@"朋友圈", @"wechat_icon.png"], SHARE_QQ:@[@"QQ", @"qq_icon.png"]}
#define SHARE_LINE          @"icon_m"

#define LOGINVIEWKIT        @"ShareLoginViewKit"
#define SHAREVIEWKIT        @"ShareViewKit"

#endif /* ShareConfig_h */
