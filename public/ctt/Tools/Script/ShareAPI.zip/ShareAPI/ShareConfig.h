//
//  ShareConfig.h
//  iFuWoiPhone
//
//  Created by arvin on 2017/2/6.
//  Copyright © 2017年 fuwo. All rights reserved.
//

#ifndef ShareConfig_h
#define ShareConfig_h

#import <TencentOpenAPI/TencentOAuth.h>
#import <TencentOpenAPI/QQApiInterface.h>
#import <TencentOpenAPI/TencentApiInterface.h>
#import "WeiboSDK.h"
#import "WXApi.h"

#define WX_APPID            @""
#define WX_APPSECRET        @""
#define QQ_APPID            @""
#define SINA_APPID          @""
#define SINA_REDIRECTURI    @"http://www.weibo.com"

#define LOGIN_SINA          @"1"
#define LOGIN_WECHAT        @"10"
#define LOGIN_QQ            @"5"//7
#define LOGIN_URLCOPY       @"-100"//无效

#define SHARE_SINA          @"sina"
#define SHARE_WECHAT_S      @"wechat_session"
#define SHARE_WECHAT_T      @"wechat_timeline"
#define SHARE_QQ            @"qq"
#define SHARE_URLCOPY       @"urlcopy"//无效

#define SHARECOMS           @[@"WechatCom", @"QQCom", @"SinaCom", @"UrlCopyCom"]

#define LOGIN_VIEW          @{LOGIN_SINA:@[@"微博", @"icon_weibo.png"], LOGIN_WECHAT:@[@"微信", @"icon_weixin.png"], LOGIN_QQ:@[@"QQ", @"icon_qq.png"]}
#define SHARE_VIEW          @{SHARE_SINA:@[@"微博", @"icon_weibo.png"], SHARE_WECHAT_S:@[@"微信好友", @"icon_weixinghaoyou.png"], SHARE_WECHAT_T:@[@"朋友圈", @"icon_pengyouquan.png"], SHARE_QQ:@[@"QQ", @"icon_QQ.png"], SHARE_URLCOPY:@[@"复制链接", @"icon_fuzhilianjie.png"]}
#define SHARE_LINE          @"icon_m"

#define LOGINVIEWKIT        @"ShareLoginViewKit"
#define SHAREVIEWKIT        @"ShareViewKit"

#endif /* ShareConfig_h */
