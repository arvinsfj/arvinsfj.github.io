//
//  WechatCom.m
//  iFuWoiPhone
//
//  Created by arvin on 2017/2/6.
//  Copyright © 2017年 fuwo. All rights reserved.
//

#import "WechatCom.h"

@interface WechatCom () <WXApiDelegate>
{
    void (^loginBlock)(NSString *tokenKey, NSString *acessToken, NSString *uid, id<ShareComProto>shareCom, NSError *err);
}

@end

@implementation WechatCom

//组件初始化
- (BOOL)isShareComShow
{
    return [WXApi isWXAppInstalled];
}
- (BOOL)shareSetup
{
    return [WXApi registerApp:WX_APPID];
}
- (BOOL)shareOpenURL:(NSURL *)url
{
    NSString *absoluteUrlStr = [url absoluteString];
    if ([absoluteUrlStr rangeOfString:WX_APPID].location != NSNotFound)
    {
        return [WXApi handleOpenURL:url delegate:self];
    }
    return NO;
}

//登录和绑定
- (BOOL)isComCanLogin
{
    return YES;
}
- (NSString *)getLoginType
{
    return LOGIN_WECHAT;
}
- (void)shareLogin:(void (^)(NSString *, NSString *, NSString *, id<ShareComProto>, NSError *))block
{
    loginBlock = block;
    // 微信登录
    SendAuthReq *req = [SendAuthReq new];
    req.scope = @"snsapi_userinfo" ;
    req.state = @"ifw_wechat_login" ;
    //第三方向微信终端发送一个SendAuthReq消息结构
    [WXApi sendReq:req];
}

//分享
- (NSArray *)getShareType
{
    return @[SHARE_WECHAT_T, SHARE_WECHAT_S];
}
- (void)share:(NSString *)title andDesc:(NSString *)desc andImg:(NSData *)img andUrl:(NSString *)url andShareType:(NSString *)snsName
{
    if ([snsName isEqualToString:SHARE_WECHAT_T]) {
        unsigned long sumLen = desc.length;
        if (sumLen > 300) {
            desc = [desc substringToIndex:(300)];
        }
        
        WXMediaMessage *message = [WXMediaMessage message];
        message.title = title;
        message.description = desc;
        [message setThumbImage:[self thumbImage:[UIImage imageWithData:img]]];
        
        WXWebpageObject *webpageObjectr = [WXWebpageObject object];
        webpageObjectr.webpageUrl = url;
        message.mediaObject = webpageObjectr;
        
        SendMessageToWXReq* req = [[SendMessageToWXReq alloc] init];
        req.bText = NO;
        req.scene = WXSceneTimeline;
        req.message = message;
        [WXApi sendReq:req];
        
    }else if([snsName isEqualToString:SHARE_WECHAT_S]){
        unsigned long sumLen = desc.length;
        if (sumLen > 300) {
            desc = [desc substringToIndex:(300)];
        }
        
        WXMediaMessage *message = [WXMediaMessage message];
        message.title = title;
        message.description = desc;
        [message setThumbImage:[self thumbImage:[UIImage imageWithData:img]]];
        
        WXWebpageObject *webpageObjectr = [WXWebpageObject object];
        webpageObjectr.webpageUrl = url;
        message.mediaObject = webpageObjectr;
        
        SendMessageToWXReq* req = [[SendMessageToWXReq alloc] init];
        req.bText = NO;
        req.scene = WXSceneSession;
        req.message = message;
        [WXApi sendReq:req];
    }
}
- (UIImage *)thumbImage:(UIImage *)image
{
    UIGraphicsBeginImageContext(CGSizeMake(50, 50));
    [image drawInRect:CGRectMake(0, 0, 50, 50)];
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}

#pragma mark 回调

/*
 access_token	接口调用凭证
 expires_in	access_token接口调用凭证超时时间，单位（秒）
 refresh_token	用户刷新access_token
 openid	授权用户唯一标识
 scope	用户授权的作用域，使用逗号（,）分隔
 unionid	 当且仅当该移动应用已获得该用户的userinfo授权时，才会出现该字段
 */

- (void)onResp:(BaseResp *)resp
{
    if ([resp isKindOfClass:[SendAuthResp class]]) {
        if (resp.errCode != 0) {return;}
        
        SendAuthResp *temp = (SendAuthResp *)resp;
        
        HttpHelper *httpHelper = [HttpHelper shareClientOther];
        httpHelper.responseSerializer.acceptableContentTypes = [httpHelper.responseSerializer.acceptableContentTypes setByAddingObject:@"text/plain"];
        [httpHelper GET:@"https://api.weixin.qq.com/sns/oauth2/access_token"
             parameters:@{@"appid":WX_APPID, @"secret":WX_APPSECRET, @"code":temp.code, @"grant_type":@"authorization_code"} progress:nil success:^(NSURLSessionTask *operation, id responseObject) {
                 if (loginBlock) {
                     loginBlock(responseObject[@"access_token"], responseObject[@"access_token"], responseObject[@"openid"], self, nil);
                 }
             } failure:^(NSURLSessionTask *operation, NSError *error) {
                 NSLog(@"error: %@", error);
             }];
    }
}

@end
