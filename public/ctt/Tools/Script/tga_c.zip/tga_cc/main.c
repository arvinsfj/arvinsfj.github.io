#include "tga.h"

struct tga_color white = {{255, 255, 255}, RGB};
struct tga_color red   = {{0, 0, 255}, RGB};
struct tga_color blue   = {{255, 0, 0}, RGB};
struct tga_color green   = {{0, 255, 0}, RGB};

int abs(int x)
{
    if (x < 0) {
        return -x;
    }
    return x;
}

void swap(int* a, int* b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

void line(int x0, int y0, int x1, int y1, struct tga_image *image, struct tga_color* color) {
    bool steep = 0;
    if (abs(x0-x1)<abs(y0-y1)) {
        swap(&x0, &y0);
        swap(&x1, &y1);
        steep = 1;
    }
    if (x0>x1) {
        swap(&x0, &x1);
        swap(&y0, &y1);
    }
    int dx = x1-x0;
    int dy = y1-y0;
    int derror2 = abs(dy)*2;
    int error2 = 0;
    int y = y0;
    for (int x=x0; x<=x1; x++) {
        if (steep) {
            tga_set(y, x, color, image);
        } else {
            tga_set(x, y, color, image);
        }
        error2 += derror2;
        
        if (error2>dx) {
            y += (y1>y0?1:-1);
            error2 -= dx*2;
        }
    }
}

int main(int argc, char** argv)
{
    struct tga_image tga;
    tga_create(1024, 768, RGB, &tga);
    for (int i=0; i<1; i++) {
        line(13, 20, 1000, 700, &tga, &blue);
        line(20, 13, 880, 670, &tga, &red);
        line(80, 40, 1013, 450, &tga, &white);
        line(40, 30, 900, 350, &tga, &green);
    }
    tga_flip_v(&tga);
    tga_write("output.tga", 1, &tga);
	return 0;
}

