//gcc -o png png_read.c -L/usr/local/lib -lpng -I/usr/local/include


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <png.h>

#include "tga.h"


#define PNG_BYTES_TO_CHECK 4

/** 读取png文件 **/
int read_png(const char *filepath, char* png_mem)
{
    FILE *fp;
    png_structp png_ptr;
    png_infop info_ptr;
    png_bytep* row_pointers;
    char buf[PNG_BYTES_TO_CHECK];
    int w, h, x, y, temp, color_type;
    
    fp = fopen( filepath, "rb" );
    if( fp == NULL ) {
        return -1;/* 返回值 */;
    }
    
    png_ptr = png_create_read_struct( PNG_LIBPNG_VER_STRING, 0, 0, 0 );
    info_ptr = png_create_info_struct( png_ptr );
    
    setjmp( png_jmpbuf(png_ptr) );
    /* 读取PNG_BYTES_TO_CHECK个字节的数据 */
    temp = fread( buf, 1, PNG_BYTES_TO_CHECK, fp );
    /* 若读到的数据并没有PNG_BYTES_TO_CHECK个字节 */
    if( temp < PNG_BYTES_TO_CHECK ) {
        fclose(fp);
        png_destroy_read_struct( &png_ptr, &info_ptr, 0);
        return -1/* 返回值 */;
    }
    /* 检测数据是否为PNG的签名 */
    temp = png_sig_cmp( (png_bytep)buf, (png_size_t)0, PNG_BYTES_TO_CHECK );
    /* 如果不是PNG的签名，则说明该文件不是PNG文件 */
    if( temp != 0 ) {
        fclose(fp);
        png_destroy_read_struct( &png_ptr, &info_ptr, 0);
        return -1/* 返回值 */;
    }
    
    /* 复位文件指针 */
    rewind( fp );
    /* 开始读文件 */
    png_init_io( png_ptr, fp );
    /* 读取PNG图片信息和像素数据 */
    png_read_png( png_ptr, info_ptr, PNG_TRANSFORM_EXPAND, 0 );
    /* 获取图像的色彩类型 */
    color_type = png_get_color_type( png_ptr, info_ptr );
    /* 获取图像的宽高 */
    w = png_get_image_width( png_ptr, info_ptr );
    h = png_get_image_height( png_ptr, info_ptr );
    /* 获取图像的所有行像素数据，row_pointers里边就是rgba数据 */
    row_pointers = png_get_rows( png_ptr, info_ptr );
    /* 根据不同的色彩类型进行相应处理 */
    switch( color_type ) {
        case PNG_COLOR_TYPE_RGB_ALPHA:
        printf("rgba:%d * %d\n", w, h);
        for( y=0; y<h; ++y ) {
            for( x=0; x<w*4; ) {
                /* 以下是RGBA数据，需要自己补充代码，保存RGBA数据 */
                *png_mem++/* 目标内存 */ = row_pointers[y][x++]; // red
                *png_mem++/* 目标内存 */ = row_pointers[y][x++]; // green
                *png_mem++/* 目标内存 */ = row_pointers[y][x++]; // blue
                *png_mem++/* 目标内存 */ = row_pointers[y][x++]; // alpha
            }
        }
        break;
        
        case PNG_COLOR_TYPE_RGB:
        printf("rgb:%d * %d\n", w, h);
        for( y=0; y<h; ++y ) {
            for( x=0; x<w*3; ) {
                *png_mem++/* 目标内存 */ = row_pointers[y][x++]; // red
                *png_mem++/* 目标内存 */ = row_pointers[y][x++]; // green
                *png_mem++/* 目标内存 */ = row_pointers[y][x++]; // blue
            }
        }
        break;
        /* 其它色彩类型的图像就不读了 */
        default:
        fclose(fp);
        png_destroy_read_struct( &png_ptr, &info_ptr, 0);
        return -1;/* 返回值 */;
    }
    png_destroy_read_struct( &png_ptr, &info_ptr, 0);
    return 0;
}

/* 写入 png 文件 */
int write_png(char *file_name, char* png_mem, int w, int h, int bpp)
{
    FILE *fp;
    png_structp png_ptr;
    png_infop info_ptr;
    png_colorp palette;
    
    /* 打开需要写入的文件 */
    fp = fopen(file_name, "wb");
    if (fp == NULL)
    return -1;

    png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    
    if (png_ptr == NULL)
    {
        fclose(fp);
        return -1;
    }
    
    /* 分配内存并初始化图像信息数据。（必要）*/
    info_ptr = png_create_info_struct(png_ptr);
    if (info_ptr == NULL)
    {
        fclose(fp);
        png_destroy_write_struct(&png_ptr,  NULL);
        return -1;
    }
    
    /* 设置错误处理。如果你在调用 png_create_write_struct() 时没
     * 有设置错误处理函数，那么这段代码是必须写的。*/
    if (setjmp(png_jmpbuf(png_ptr)))
    {
        /* 如果程序跑到这里了，那么写入文件时出现了问题 */
        fclose(fp);
        png_destroy_write_struct(&png_ptr, &info_ptr);
        return -1;
    }
    
    /* 设置输出控制，如果你使用的是 C 的标准 I/O 流 */
    png_init_io(png_ptr, fp);
    
    /* 这是一种复杂的做法 */
    
    /* （必需）在这里设置图像的信息，宽度、高度的上限是 2^31。
     * bit_depth 取值必需是 1、2、4、8 或者 16, 但是可用的值也依赖于 color_type。
     * color_type 可选值有： PNG_COLOR_TYPE_GRAY、PNG_COLOR_TYPE_GRAY_ALPHA、
     * PNG_COLOR_TYPE_PALETTE、PNG_COLOR_TYPE_RGB、PNG_COLOR_TYPE_RGB_ALPHA。
     * interlace 可以是 PNG_INTERLACE_NONE 或 PNG_INTERLACE_ADAM7,
     * 而 compression_type 和 filter_type 目前必需是 PNG_COMPRESSION_TYPE_BASE
     * 和 and PNG_FILTER_TYPE_BASE。
     */
    if (bpp == 3) {
        png_set_IHDR(png_ptr, info_ptr, w, h, 8, PNG_COLOR_TYPE_RGB,
                     PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);
    }else if (bpp == 4) {
        png_set_IHDR(png_ptr, info_ptr, w, h, 8, PNG_COLOR_TYPE_RGB_ALPHA,
                     PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);
    }
    
    
    
    /* 写入文件头部信息（必需） */
    png_write_info(png_ptr, info_ptr);
    
    png_uint_32 k, height = h, width = w, bytes_per_pixel = bpp;
    
    /* 在这个示例代码中，"image" 是一个一维的字节数组（每个元素占一个字节空间） */
    png_byte image[height*width*bytes_per_pixel];
    memcpy(image, png_mem, height*width*bytes_per_pixel);
    
    png_bytep row_pointers[height];
    
    if (height > PNG_UINT_32_MAX/(sizeof (png_bytep)))
    png_error (png_ptr, "Image is too tall to process in memory");
    
    /* 将这些像素行指针指向你的 "image" 字节数组中对应的位置，即：指向每行像素的起始处 */
    for (k = 0; k < height; k++)
    row_pointers[k] = image + k*width*bytes_per_pixel;
    
    /* 一次调用就将整个图像写进文件 */
    png_write_image(png_ptr, row_pointers);
    /* 必需调用这个函数完成写入文件其余部分 */
    png_write_end(png_ptr, info_ptr);
    /* 写完后清理并释放已分配的内存 */
    png_destroy_write_struct(&png_ptr, &info_ptr);
    /* 关闭文件 */  
    fclose(fp);  
    
    /* That's it */  
    return 0;
}

void image_gray(char* png_mem, int w, int h, int bpp)
{
    char *img_mem = png_mem;
    float gray = 0;
    for (long i = 0; i < w*h*bpp; i+=bpp) {
        gray = (png_mem[i+0]+png_mem[i+1]+png_mem[i+2])/3.0f;
        img_mem[i+0] = gray;
        img_mem[i+1] = gray;
        img_mem[i+2] = gray;
    }
}

int main(int argc, char** argv)
{
    int w=750,h=462,bpp=3;
    char* png_mem = malloc(w*h*bpp);
    read_png("3.png", png_mem);
    
    //image_gray(png_mem, w, h, bpp);
    
    write_png("5.png", png_mem, w, h, bpp);
    struct tga_image tga;
    tga_create(w, h, RGB, &tga);
    memcpy(tga_buffer(&tga), png_mem, w*h*bpp);
    tga_write("output.tga", 1, &tga);
    
    free(png_mem);
    
    return 0;
}


