#!/usr/bin/env python
# -*- coding: utf-8 -*-

import socket
import threading
import time

client = {};

def tcplink(sock, addr):
    print 'from %s:%s...' % addr
    while True:
        data = sock.recv(1024)
        time.sleep(0.1)
        if data == 'exit' or not data:
            sock.send(data)
            client.pop('%s:%s' % addr)
            sock.close()
            break
        for k in client:
            if client[k] != sock:
                client[k].send('##%s' % data)
    print 'from %s:%s closed.' % addr

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('127.0.0.1', 9999))
s.listen(1000)
print 'Waiting for connection...'
while True:
    sock, addr = s.accept()
    client['%s:%s' % addr] = sock
    t = threading.Thread(target=tcplink, args=(sock,addr))
    t.start()


	
