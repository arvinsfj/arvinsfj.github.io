#!/usr/bin/env python
# -*- coding: utf-8 -*-

import socket
import threading
import time

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('127.0.0.1', 9999))

def tcplink():
    while True:
        data = s.recv(1024)
        if data == 'exit':
            s.close()
            break
        time.sleep(0.1)
        print data

t = threading.Thread(target=tcplink)
t.start()

while True:
    txt = raw_input()
    s.send(txt)
    if txt == 'exit':
        break

