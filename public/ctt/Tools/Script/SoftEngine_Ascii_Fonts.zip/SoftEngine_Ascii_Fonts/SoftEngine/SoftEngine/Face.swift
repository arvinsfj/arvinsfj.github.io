//
//  Face.swift
//  SoftEngine
//
//  Created by cz on 12/18/15.
//  Copyright © 2015 cz. All rights reserved.
//

import Foundation

class Face {
    var A:Int = 0;
    var B:Int = 0;
    var C:Int = 0;
    var Normal:SE3DMath.Vector3 = SE3DMath.Vector3.Zero();
}
