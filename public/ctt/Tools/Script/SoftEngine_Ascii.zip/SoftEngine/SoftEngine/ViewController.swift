//
//  ViewController.swift
//  SoftEngine
//
//  Created by cz on 12/16/15.
//  Copyright © 2015 cz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var preDate = Date();
    var fpsValues = [Int]();
    var fpsLabel = UILabel(frame:CGRect(x: 5,y: 20,width: 300,height: 20));
    var canvas = UIImageView();
    var canvasAscii = UITextView();
    let bitmapInfo = CGBitmapInfo(rawValue: CGBitmapInfo().rawValue | CGImageAlphaInfo.premultipliedLast.rawValue);
    var device = SEDevice();
    
    var rx:Float = 0.0;
    var ry:Float = 0.0;
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(colorLiteralRed: 2/255.0, green: 88/255.0, blue: 44/255.0, alpha: 1);
        self.view.addSubview(fpsLabel);
        // Do any additional setup after loading the view, typically from a nib.
        canvas.frame=CGRect(x: (self.view.frame.size.width-330)/2, y: (self.view.frame.size.height-384)/2, width: 330, height: 330);
        self.view.addSubview(canvas);
        canvasAscii.frame=CGRect(x: (self.view.frame.size.width-330)/2, y: (self.view.frame.size.height-397)/2, width: 335, height: 397);
        canvasAscii.isScrollEnabled = false;
        canvasAscii.isEditable = false;
        canvasAscii.isSelectable = false;
        canvasAscii.font = UIFont.systemFont(ofSize: 1);
        canvasAscii.textContainerInset = UIEdgeInsetsMake(0,0,0,0);
        canvasAscii.backgroundColor = UIColor.white;
        self.view.addSubview(canvasAscii);
        
        self.device = SEDevice(modelFileName: "monkey.babylon");
        self.setupDisplayLink();
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setupDisplayLink() -> Void
    {
        let displayLink = CADisplayLink(target: self, selector: #selector(self.renderLoop));
        displayLink.add(to: .current, forMode: .defaultRunLoopMode)
    }
    
    func renderLoop() -> Void
    {
        let nowDate = Date();
        let curFPS = Int(1/nowDate.timeIntervalSince(preDate));
        self.preDate = nowDate;
        if (self.fpsValues.count<60){
            self.fpsValues.append(curFPS);
        }else{
            self.fpsValues.removeFirst();
            self.fpsValues.append(curFPS);
            var total = 0;
            for value in self.fpsValues {
                total += value;
            }
            if self.fpsValues.count >= 1 {
                let averageFPS = total/self.fpsValues.count;
                self.fpsLabel.text = "APS: \(averageFPS)   FPS: \(curFPS)";
            }
        }
        
        device.clear();
        device.update(){ meshes in
            for i in 0 ..< meshes.count {
                meshes[i].rotation.x += -ry;
                meshes[i].rotation.y += -rx;
            }
            rx = 0.08;
            //rx = 0;
            ry = 0;
        };
        device.show(){ data in
            /*
            let ctx = CGContext(data: UnsafeMutableRawPointer(mutating: data), width: 330, height: 330, bitsPerComponent: 8, bytesPerRow: 330*4, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: self.bitmapInfo.rawValue);
            let imageRef = ctx?.makeImage();
            self.canvas.layer.contents = imageRef;*/
            //let backBuffer = [UInt8](repeating: 0x70, count: 330*330*4);
            self.canvasAscii.text = self.renderAscii(image: data);//渲染字符画面;
        };
    }
    
    func getChar(val:Float) -> String
    {
        let chars  = ["@","# ","$ ","= ","* ","!  ",";  ",":  ","~ ","- ",",  ",".  ","   ","   "];
        let charLen = chars.count - 1;
        return chars[(Int)(val*(Float)(charLen))];
    }
    
    func renderAscii(image:[UInt8]) -> String
    {
        var str: String = "";
        let len: Int = 330*330;
        var i: Int = 0;
        while i < len {
            if i%(330) == 0 {
                str = str  + "\n";
            }
            let r = image[i*4+2];
            str = str + getChar(val: Float(r)/255.0);
            
            i+=1;
        }
        
        return str;
    }
    
    var startPoint:CGPoint = CGPointFromString("0");
    var endPoint:CGPoint = CGPointFromString("0");
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //
        let start = touches.first;
        startPoint = start!.location(in: self.view);
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        //
        let end = touches.first;
        endPoint = end!.location(in: self.view);
        
        let ddx = endPoint.x - startPoint.x;
        let ddy = endPoint.y - startPoint.y;
        
        rx = Float(ddx) / Float(self.view.frame.size.width);
        ry = Float(ddy) / Float(self.view.frame.size.height);

    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        //
        rx = 0;
        ry = 0;
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        //
        rx = 0;
        ry = 0;
    }
}

