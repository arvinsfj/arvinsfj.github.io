Nomad3D is a platform independent 3D Engine, it is simple and reduced, can use for several platform such as Win32, Linux, Nintendo DS, Sony PSP, Apple iPhone, cell phone and other mobile devices. It's main coded language is C/C++.


////////////////////////////////////////////////
//History
////////////////////////////////////////////////
(3).-------------July 21, 2013-------------------Ver 0.0.0.5
1.Add Spot Light support
2.Add TextureGouraudShading function(rasterization as texture with gouraud shading)
3.Add GouraudShading function(rasterization as gouraud shading)
4.Add Fixed Point support for both above rasterization functions
5.Add Separate Specular Light with Texture in rasterization
6.Fix several bugs

(2).-------------June 22, 2011-------------------Ver 0.0.0.2
Added Simple Text output support, Now, it's only
support 8*8 pixel ASCII characters, you can find
these data in Nomad3D/font/5_7font.h,
Nomad3D/src/font.h and font8.h

(1).-------------March 07, 2011------------------Ver 0.0.0.1
Now,the version of Nomad3D has not complete yet, 
but for some reasons, I release the code on SVN 
of sf.netthis version of Nomad3D just have 
little functions and can run the demo on Windows
 OS only, but it is a software rendering 3D 
Engine, but by now, this version may not call 
Engine:), it just have a complete 3D pipe-line 
and a software lighting plus a MS3D skeleton 
animation support.

The earlier future work, I'll add texture and 
gouraud support,and some other functions that 
a normal 3D engine has. Not so far!

=======HOW TO BUILD THIS VERSION OF DEMO=======
Go into the directory "Nomad3DTest_Win32" and 
open the Noamd3DTest.dsw with Visual C++ 6.0(the 
Windows version of Nomad3D, I'll move this 
project to VC2008 or above later),and compile 
it and run!

===============Acknowledgement=================
1. In this version, I used the MS3D model file 
which is from the book "Focus on 3D Model"'s 
source code, thanks the author!


===================Contact=====================
Vincent Gao(c_gao)
dr.c.gao@gmail.com or c_gao@163.net