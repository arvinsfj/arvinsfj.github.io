// testpicture.h: interface for the CTestPicture class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TESTPICTURE_H__0F9D39A9_71DA_4D40_8C00_63DBE45D8386__INCLUDED_)
#define AFX_TESTPICTURE_H__0F9D39A9_71DA_4D40_8C00_63DBE45D8386__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../src/picture.h"
#include "../src/renderlist.h"
#include "../src/render.h"
#include <list>

using namespace Nomad3D;

class CTestPicture : public CPicture  
{
public:
	CTestPicture();
	virtual ~CTestPicture();
	void Draw(int n=0);
	//////////////////////////////////////////////////////////////////////////
	inline void AddObject(CObject* pObject)
	{
		if(pObject)
		{
			m_ObjectList.push_back(pObject);
		}
	}
private:
	std::list<CObject*>	m_ObjectList;
};

#endif // !defined(AFX_TESTPICTURE_H__0F9D39A9_71DA_4D40_8C00_63DBE45D8386__INCLUDED_)
