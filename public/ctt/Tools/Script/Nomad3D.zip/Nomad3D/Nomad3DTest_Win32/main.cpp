#include "windowsx.h"
#include "windows.h"
#include "../platform/win32/DIB.h"
#include "../platform/win32/ClockManager.h"

#include "../src/ms3dobject.h"
#include "../src/matrix4.h"
#include "../src/camera.h"
#include "../src/renderlist.h"
#include "../src/rgb.h"
#include "../src/constant.h"
#include "../src/scene.h"
#include "../src/picture.h"
#include "../src/player.h"
#include "../src/light.h"
#include "../src/vector4.h"

#include "testpicture.h"


using namespace Nomad3D;

#define WINDOW_WIDTH	NM3D_WINDOW_WIDTH
#define WINDOW_HEIGHT	NM3D_WINDOW_HEIGHT

#define DRAW_GDI	0

#define WINDOWED_APP      TRUE
const COLORREF	BACKGROUND_COLOR=RGB(0,0,0);

#define RGB555(r,g,b)	(r<<10|g<<5|b)
unsigned short clr=RGB555(31,31,31)/*32767*/;

//////////////////////////////////////////////////////////////////////////
int min_clip_y = 0;
int min_clip_x = 0;
int max_clip_y = WINDOW_HEIGHT-1;
int max_clip_x = (WINDOW_WIDTH-1);
//////////////////////////////////////////////////////////////////////////


TCHAR* szTitle="Nomad3D Test Demo";
TCHAR* szWindowClass="Nomad3DWindowClass";
HINSTANCE hInst=NULL;
HWND main_window_handle=NULL;
HDC g_hdc=NULL;
CDIB	g_dib;

CMS3DObject obj;
CMS3DObject obj2;
CMS3DObject obj22;
CMS3DObject obj3;
CMS3DObject obj31;
CMS3DObject obj4;
CPoint3 eye(0,0,45);
CPoint3 eye1(0,0,0);
CPoint3 eye2(0,0,0);
CPoint3 look(0,0,-1000);
CVector3 up(0,1,0);
CCamera cam;
CCamera cam2;
CCamera cam3;
CScene scene1;
CScene scene2;
CScene scene3;
CScene scene31;
CTestPicture picture1;
//CPicture picture1;
CPicture picture2;
CPicture picture3;
CPicture picture31;
CPlayer player1;

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
inline void SetPixel(unsigned char* buff,int x, int y, unsigned short color);
void DrawLine(unsigned char* buff,int x1,int y1,int x2,int y2);
int Cohen_ClipLine(int &x1,int &y1,int &x2, int &y2);
void DrawTri16(unsigned short* buff,int p[3][2],unsigned short clr);
void Draw_Triangle_2D3_16(float poly[3][2],   // ptr to face
						  UCHAR *_dest_buffer, // pointer to video buffer
						  int mem_pitch);       // bytes per line, 320, 640 etc.



void GameInit()
{
	//bool b=obj.ReadObjectFile("butterfly.ms3d");
	//bool b=obj.ReadObjectFile("ABC.ms3d");
	//bool b=obj.ReadObjectFile("Desklamp.ms3d");
	bool b=obj.ReadObjectFile("jump_specular.ms3d");//("ninja.ms3d");//("sphere12.ms3d");//("Desklamp.ms3d");//("butterfly.ms3d");//("tube.ms3d");//
	//bool b=obj.ReadObjectFile("sphere.ms3d");
	assert(b);
	b = obj2.ReadObjectFile("crow.ms3d");//("plane15.ms3d");//
//	b = obj22.ReadObjectFile("ABC.ms3d");
	assert(b);
	b=obj3.ReadObjectFile("butterfly.ms3d");//("ABC.ms3d");//
	assert(b);
//	b=obj4.ReadObjectFile("Desklamp.ms3d");
/*	b=obj31.ReadObjectFile("jump.ms3d");
	assert(b);
*/
	cam.LookAt(eye,look,up);
	cam.SetPerspective(90, float(WINDOW_WIDTH*1.0/WINDOW_HEIGHT), .1f, 250);
	cam2.LookAt(eye,look,up);
	cam2.SetPerspective(90, float(200*1.0/200), 1.1f, 150);
	cam2.LookAt(eye,look,up);
	cam2.SetPerspective(90, float(200*1.0/100), 1.1f, 150);

	render.SetDC(g_hdc);

	scene1.AddObject(&obj);
	scene1.AddObject(&obj2);
	//scene1.AddObject(&obj4);
	//scene1.AddObject(&obj3);
	//scene1.AddObject(&obj4);
	scene1.SetCamera(cam);

	scene2.AddObject(&obj22);
	scene2.SetCamera(cam2);

	scene3.AddObject(&obj3);
	scene3.SetCamera(cam2);
/*
	scene31.AddObject(&obj31);
	scene31.SetCamera(cam);
*/
	picture1.AddObject(&obj);
	picture1.SetScene(&scene1);
	picture1.SetViewInfo(CViewInfo(0,0,WINDOW_WIDTH,WINDOW_HEIGHT,CRGBA(0,0,0,1)));

	picture2.SetScene(&scene2);
	picture2.SetViewInfo(CViewInfo(WINDOW_WIDTH-200,0,200,200,CRGBA(100,0,0,1)));

//	picture3.AddObject(&obj3);
	picture3.SetScene(&scene3);
	picture3.SetViewInfo(CViewInfo(WINDOW_WIDTH-200,WINDOW_HEIGHT-100,200,100,CRGBA(10,100,10,1)));
/*	
	picture31.SetScene(&scene31);
	picture31.SetViewInfo(CViewInfo(WINDOW_WIDTH/16*7+4,WINDOW_HEIGHT/8*6+3,WINDOW_WIDTH/16,WINDOW_HEIGHT/8,CRGBA(100,100,10,1)));
*/
	player1.AddPicture(&picture1);
//	player1.AddPicture(&picture2);
	player1.AddPicture(&picture3);
//	player1.AddPicture(&picture31);

	//CPoint4 pos(0,40,15);
	//CVector3 dir(10,10,20);
	CPoint4 pos(0,0,0);
	CVector3 dir(1,0.7f,0);//��Դ����Ϊdir-ԭ��������ķ���
	light.SetGlobalAmbient(CRGBA(50,50,50));
	light.CreateLight(CLight::NM3D_LIGHT_STATE_ON,CLight::NM3D_LIGHT_TYPE_DIRECTION,CRGBA(20,20,20),CRGBA(100,100,100),CRGBA(255,255,255),
		&pos,&dir,0,0,0,0,0);
	light.CreateLight(CLight::NM3D_LIGHT_STATE_ON,CLight::NM3D_LIGHT_TYPE_POINT,CRGBA(20,20,20),CRGBA(200,200,200),CRGBA(255,255,255),
		&pos,&dir,0,0.004f,0,0,0);
	light.CreateLight(CLight::NM3D_LIGHT_STATE_ON,CLight::NM3D_LIGHT_TYPE_SPOT,CRGBA(20,20,20),CRGBA(250,250,250),CRGBA(255,255,255),
		&pos,&dir,0,0.002f,0,15,2.0);
}

void GameLoop()
{
	Start_Clock();
	//render.ClearVBuffer();
	player1.ShowPicture(-1);
	render.Flip();
	Wait_Clock(FPS_60);
}

void GameShutdown()
{
	
}


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	MSG msg;
	//HACCEL hAccelTable;

	// Initialize global strings
	//LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	//LoadString(hInstance, IDC_DENGINE, szWindowClass, MAX_LOADSTRING);
	
	//////////////////////////////////////////////////////////////////////////
	//Register Class
	HBRUSH hbkbrush=CreateSolidBrush(BACKGROUND_COLOR);
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= NULL;//LoadIcon(hInstance, (LPCTSTR)IDI_DENGINE);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= hbkbrush;//(HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;//(LPCTSTR)IDC_DENGINE;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= NULL;//LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	RegisterClassEx(&wcex);

	//////////////////////////////////////////////////////////////////////////
	//Create Window

	HWND hWnd;

	hInst = hInstance; // Store instance handle in our global variable

	hWnd = CreateWindow(szWindowClass, szTitle, (WINDOWED_APP ? (WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION) : (WS_POPUP | WS_VISIBLE)),//WS_OVERLAPPEDWINDOW,
		0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, NULL, NULL, hInstance, NULL);


	if (!hWnd)
	{
		return FALSE;
	}

	main_window_handle=hWnd;
	g_hdc=GetDC(main_window_handle);

	if (WINDOWED_APP)
	{
		RECT window_rect = {0,0,WINDOW_WIDTH-1,WINDOW_HEIGHT-1};
		HWND main_window_handle = hWnd;

		AdjustWindowRectEx(&window_rect,
			GetWindowStyle(main_window_handle),
			GetMenu(main_window_handle) != NULL,
			GetWindowExStyle(main_window_handle));

		::SetWindowPos(main_window_handle,HWND_NOTOPMOST,100,100,window_rect.right - window_rect.left+1,window_rect.bottom - window_rect.top+1,SWP_NOOWNERZORDER);

	} 

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	//hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_DENGINE);


	//////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////
	//SystemParametersInfo(SPI_SCREENSAVERRUNNING, TRUE, NULL, 0);
	GameInit();
	while(1)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) 
		{ 
			if (msg.message == WM_QUIT) 
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		GameLoop();
	}
	GameShutdown();
	//SystemParametersInfo(SPI_SCREENSAVERRUNNING, FALSE, NULL, 0);
	return (int) msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId,wmEvent;
	
	switch (message) 
	{
	case WM_CREATE:
		break;
	case WM_SIZE:
		{
			RECT rt1;
			GetWindowRect(hWnd,&rt1);
			//rt1.right=rt1.left+SCREEN_WIDTH;
			//rt1.bottom=rt1.top+SCREEN_HEIGHT;
			//SetWindowPos(hWnd,HWND_TOP,rt1.left,rt1.top,SCREEN_WIDTH,SCREEN_HEIGHT,SWP_SHOWWINDOW);
		}
		break;
	case WM_COMMAND:
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam); 
		// Parse the menu selections:
		switch (wmId)
		{
// 		case IDM_ABOUT:
// 			DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
// 			break;
// 		case IDM_EXIT:
// 			DestroyWindow(hWnd);
// 			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
		case WM_KEYDOWN:
			{
				static int x=1;
				static int y=1;
				static int z=1;

				CCamera* pCamera = scene1.GetCamera();
				float fUnits = 1.0f;
				switch(wParam)
				{
				case VK_UP:
					pCamera->Walk(-fUnits);
					break;
				case VK_DOWN:
					pCamera->Walk(fUnits);
					break;
				case VK_LEFT:
					pCamera->Strafe(-fUnits);
					break;
				case VK_RIGHT:
					pCamera->Strafe(fUnits);
					break;
				case 'A':
				case 'a':
					pCamera->Yaw(-1);
					break;
				case 'D':
				case 'd':
					pCamera->Yaw(1);
					break;
				case 'L':
				case 'l':
					render.SetRenderType(CRender::NM3D_RENDER_TYPE_LINE);
					break;
				case 'F':
				case 'f':
					render.SetRenderType(CRender::NM3D_RENDER_TYPE_FLAT);
					break;
				case 'G':
				case 'g':
					render.SetRenderType(CRender::NM3D_RENDER_TYPE_GOURAUD);
					break;
				case 'H':
				case 'h':
					render.SetRenderType(CRender::NM3D_RENDER_TYPE_GOURAUD_LaMoth);
					break;
				case 'T':
				case 't':
					render.SetRenderType(CRender::NM3D_RENDER_TYPE_GOURAUD_TEXTURE);
					break;
				case 'Y':
				case 'y':
					render.SetRenderType(CRender::NM3D_RENDER_TYPE_GOURAUD_TEXTURE_LaMoth);
					break;
				case 'S':
				case 's':
					render.SetRenderType(CRender::NM3D_RENDER_TYPE_GOURAUD_TEXTURE_SS);
					break;
				case 'B':
				case 'b':
					render.SetRenderType(CRender::NM3D_RENDER_TYPE_LINE_NO_BACK);
					break;
				case 'Z':
				case 'z':
					render.SetZBufferState(!render.GetZBufferState());
					break;
				case 'X':
				case 'x':
					if(light.GetLightState(0) == CLight::NM3D_LIGHT_STATE_OFF)
						light.SetLightState(0, CLight::NM3D_LIGHT_STATE_ON);
					else
						light.SetLightState(0, CLight::NM3D_LIGHT_STATE_OFF);
					break;
				case 'C':
				case 'c':
					if(light.GetLightState(1) == CLight::NM3D_LIGHT_STATE_OFF)
						light.SetLightState(1, CLight::NM3D_LIGHT_STATE_ON);
					else
						light.SetLightState(1, CLight::NM3D_LIGHT_STATE_OFF);
					break;
				case 'V':
				case 'v':
					if(light.GetLightState(2) == CLight::NM3D_LIGHT_STATE_OFF)
						light.SetLightState(2, CLight::NM3D_LIGHT_STATE_ON);
					else
						light.SetLightState(2, CLight::NM3D_LIGHT_STATE_OFF);
					break;
				case VK_SPACE:
					eye.Assign(0,0,z++);
					break;
				case VK_RETURN:
					eye.Assign(0,0,z--);
					break;
				}
			}
			break;
		case WM_PAINT:
			//render.Flip();
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}
#if (0)
inline void SetPixel(unsigned char* buff, int y, int x, unsigned short color)
{
	//*((unsigned short*)(buff+(y*WINDOW_WIDTH+x)*2))=color;
	*((unsigned short*)buff+y*WINDOW_WIDTH+x) = color;
}

void DrawLine(unsigned char* buff,int x1,int y1,int x2,int y2)
{
	clr;
	if(!Cohen_ClipLine(x1,y1,x2,y2))
		return;

	int  x, y;
	int  dx, dy;
	int  incx, incy;
	int  balance;
	int i=0;
	if (x2 >= x1)
	{
		dx = x2 - x1;
		incx = 1;
	}
	else
	{
		dx = x1 - x2;
		incx = -1;
	}
	
	if (y2 >= y1)
	{
		dy = y2 - y1;
		incy = 1;
	}
	else
	{
		dy = y1 - y2;
		incy = -1;
	}
	
	x = x1;
	y = y1;
	
	if (dx >= dy)
	{
		dy <<= 1;
		balance = dy - dx;
		dx <<= 1;
		
		while (x != x2)
		{
			SetPixel(buff,y,x,clr);
			if (balance >= 0)
			{
				y += incy;
				balance -= dx;
			}
			balance += dy;
			x += incx;
			i ++;
		}
		SetPixel(buff,y,x,clr);
	}
	else
	{
		dx <<= 1;
		balance = dx - dy;
		dy <<= 1;

		while (y != y2)
		{
			SetPixel(buff,y,x,clr);
			if (balance >= 0)
			{
				x += incx;
				balance -= dy;
			}
			balance += dx;
			y += incy;
			i ++;
		}
		SetPixel(buff,y,x,clr);
	}
}

//////////////////////////////////////////////////////////////////////////

int Cohen_ClipLine(int &x1,int &y1,int &x2, int &y2)
{
	// this function clips the sent line using the globally defined clipping
	// region
	
	// internal clipping codes
#define CLIP_CODE_C  0x0000
#define CLIP_CODE_N  0x0008
#define CLIP_CODE_S  0x0004
#define CLIP_CODE_E  0x0002
#define CLIP_CODE_W  0x0001
	
#define CLIP_CODE_NE 0x000a
#define CLIP_CODE_SE 0x0006
#define CLIP_CODE_NW 0x0009 
#define CLIP_CODE_SW 0x0005
	
	int xc1=x1, 
		yc1=y1, 
		xc2=x2, 
		yc2=y2;
	
	int p1_code=0, 
		p2_code=0;
	
	// determine codes for p1 and p2
	if (y1 < min_clip_y)
		p1_code|=CLIP_CODE_N;
	else if (y1 > max_clip_y)
		p1_code|=CLIP_CODE_S;
	
	if (x1 < min_clip_x)
		p1_code|=CLIP_CODE_W;
	else if (x1 > max_clip_x)
		p1_code|=CLIP_CODE_E;
	
	if (y2 < min_clip_y)
		p2_code|=CLIP_CODE_N;
	else if (y2 > max_clip_y)
		p2_code|=CLIP_CODE_S;
				
	if (x2 < min_clip_x)
		p2_code|=CLIP_CODE_W;
	else if (x2 > max_clip_x)
		p2_code|=CLIP_CODE_E;
				
	// try and trivially reject
	if ((p1_code & p2_code)) 
		return(0);
				
	// test for totally visible, if so leave points untouched
	if (p1_code==0 && p2_code==0)
		return(1);
	
	// determine end clip point for p1
	switch(p1_code)
	{
	case CLIP_CODE_C: break;
		
	case CLIP_CODE_N:
		{
			yc1 = min_clip_y;
			xc1 = x1 + 0.5+(min_clip_y-y1)*(x2-x1)/(y2-y1);
		} break;
	case CLIP_CODE_S:
		{
			yc1 = max_clip_y;
			xc1 = x1 + 0.5+(max_clip_y-y1)*(x2-x1)/(y2-y1);
		} break;
		
	case CLIP_CODE_W:
		{
			xc1 = min_clip_x;
			yc1 = y1 + 0.5+(min_clip_x-x1)*(y2-y1)/(x2-x1);
		} break;
		
	case CLIP_CODE_E:
		{
			xc1 = max_clip_x;
			yc1 = y1 + 0.5+(max_clip_x-x1)*(y2-y1)/(x2-x1);
		} break;
		
		// these cases are more complex, must compute 2 intersections
	case CLIP_CODE_NE:
		{
			// north hline intersection
			yc1 = min_clip_y;
			xc1 = x1 + 0.5+(min_clip_y-y1)*(x2-x1)/(y2-y1);
			
			// test if intersection is valid, of so then done, else compute next
			if (xc1 < min_clip_x || xc1 > max_clip_x)
			{
				// east vline intersection
				xc1 = max_clip_x;
				yc1 = y1 + 0.5+(max_clip_x-x1)*(y2-y1)/(x2-x1);
			} // end if
			
		} break;
		
	case CLIP_CODE_SE:
		{
			// south hline intersection
			yc1 = max_clip_y;
			xc1 = x1 + 0.5+(max_clip_y-y1)*(x2-x1)/(y2-y1);	
			
			// test if intersection is valid, of so then done, else compute next
			if (xc1 < min_clip_x || xc1 > max_clip_x)
			{
				// east vline intersection
				xc1 = max_clip_x;
				yc1 = y1 + 0.5+(max_clip_x-x1)*(y2-y1)/(x2-x1);
			} // end if
			
		} break;
		
	case CLIP_CODE_NW: 
		{
			// north hline intersection
			yc1 = min_clip_y;
			xc1 = x1 + 0.5+(min_clip_y-y1)*(x2-x1)/(y2-y1);
			
			// test if intersection is valid, of so then done, else compute next
			if (xc1 < min_clip_x || xc1 > max_clip_x)
			{
				xc1 = min_clip_x;
				yc1 = y1 + 0.5+(min_clip_x-x1)*(y2-y1)/(x2-x1);	
			} // end if
			
		} break;
		
	case CLIP_CODE_SW:
		{
			// south hline intersection
			yc1 = max_clip_y;
			xc1 = x1 + 0.5+(max_clip_y-y1)*(x2-x1)/(y2-y1);	
			
			// test if intersection is valid, of so then done, else compute next
			if (xc1 < min_clip_x || xc1 > max_clip_x)
			{
				xc1 = min_clip_x;
				yc1 = y1 + 0.5+(min_clip_x-x1)*(y2-y1)/(x2-x1);	
			} // end if
			
		} break;
		
	default:break;
		
	} // end switch
	
	// determine clip point for p2
	switch(p2_code)
	{
	case CLIP_CODE_C: break;
		
	case CLIP_CODE_N:
		{
			yc2 = min_clip_y;
			xc2 = x2 + (min_clip_y-y2)*(x1-x2)/(y1-y2);
		} break;
		
	case CLIP_CODE_S:
		{
			yc2 = max_clip_y;
			xc2 = x2 + (max_clip_y-y2)*(x1-x2)/(y1-y2);
		} break;
		
	case CLIP_CODE_W:
		{
			xc2 = min_clip_x;
			yc2 = y2 + (min_clip_x-x2)*(y1-y2)/(x1-x2);
		} break;
		
	case CLIP_CODE_E:
		{
			xc2 = max_clip_x;
			yc2 = y2 + (max_clip_x-x2)*(y1-y2)/(x1-x2);
		} break;
		
		// these cases are more complex, must compute 2 intersections
	case CLIP_CODE_NE:
		{
			// north hline intersection
			yc2 = min_clip_y;
			xc2 = x2 + 0.5+(min_clip_y-y2)*(x1-x2)/(y1-y2);
			
			// test if intersection is valid, of so then done, else compute next
			if (xc2 < min_clip_x || xc2 > max_clip_x)
			{
				// east vline intersection
				xc2 = max_clip_x;
				yc2 = y2 + 0.5+(max_clip_x-x2)*(y1-y2)/(x1-x2);
			} // end if
			
		} break;
		
	case CLIP_CODE_SE:
		{
			// south hline intersection
			yc2 = max_clip_y;
			xc2 = x2 + 0.5+(max_clip_y-y2)*(x1-x2)/(y1-y2);	
			
			// test if intersection is valid, of so then done, else compute next
			if (xc2 < min_clip_x || xc2 > max_clip_x)
			{
				// east vline intersection
				xc2 = max_clip_x;
				yc2 = y2 + 0.5+(max_clip_x-x2)*(y1-y2)/(x1-x2);
			} // end if
			
		} break;
		
	case CLIP_CODE_NW: 
		{
			// north hline intersection
			yc2 = min_clip_y;
			xc2 = x2 + 0.5+(min_clip_y-y2)*(x1-x2)/(y1-y2);
			
			// test if intersection is valid, of so then done, else compute next
			if (xc2 < min_clip_x || xc2 > max_clip_x)
			{
				xc2 = min_clip_x;
				yc2 = y2 + 0.5+(min_clip_x-x2)*(y1-y2)/(x1-x2);	
			} // end if
			
		} break;
		
	case CLIP_CODE_SW:
		{
			// south hline intersection
			yc2 = max_clip_y;
			xc2 = x2 + 0.5+(max_clip_y-y2)*(x1-x2)/(y1-y2);	
			
			// test if intersection is valid, of so then done, else compute next
			if (xc2 < min_clip_x || xc2 > max_clip_x)
			{
				xc2 = min_clip_x;
				yc2 = y2 + 0.5+(min_clip_x-x2)*(y1-y2)/(x1-x2);	
			} // end if
			
		} break;
		
	default:break;
		
	} // end switch
	
	// do bounds check
	if ((xc1 < min_clip_x) || (xc1 > max_clip_x) ||
		(yc1 < min_clip_y) || (yc1 > max_clip_y) ||
		(xc2 < min_clip_x) || (xc2 > max_clip_x) ||
		(yc2 < min_clip_y) || (yc2 > max_clip_y) )
	{
		return(0);
	} // end if
	
	// store vars back
	x1 = xc1;
	y1 = yc1;
	x2 = xc2;
	y2 = yc2;
	
	return(1);
					
} // end Clip_Line

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
#define MAX(a,b)	(a)>(b)?(a):(b)
#define MIN(a,b)	(a)>(b)?(b):(a)
#define SWAP(a,b)	{a=a+b; b=a-b; a=a-b;}
#define FCMP(a,b) ( (fabs(a-b) < NM3D_EPSILON_E3) ? 1 : 0)
#define ABS_MINUS(a,b)	((a)>(b)?(a)-(b):(b)-(a))

#define NM3D_TRIANGLE_TYPE_FLAT_TOP		1
#define NM3D_TRIANGLE_TYPE_FLAT_BOTTOM	2
#define NM3D_TRIANGLE_TYPE_GENERAL	3

void DrawTri16(unsigned short* buff,int p[3][2],unsigned short clr)
{
// 	for(int j=0; j<3; j++)
// 	{
// 		p[j][0] = (int)(p[j][0]+0.5);
// 		p[j][1] = (int)(p[j][1]+0.5);
// 	}

	int tri_type;
	int v0=0,v1=1,v2=2;
	//�ü�
	
	//////////////////////////////////////////////////////////////////////////
	if (p[v1][1] < p[v0][1])
		SWAP(v0,v1);
	
	if (p[v2][1] < p[v0][1]) 
		SWAP(v0,v2);
	
	if (p[v2][1] < p[v1][1]) 
		SWAP(v1,v2);

	// now test for trivial flat sided cases
	if (FCMP(p[v0][1], p[v1][1]) )
	{ 
		tri_type = NM3D_TRIANGLE_TYPE_FLAT_TOP;
		
		// sort vertices left to right
		if (p[v1][0] < p[v0][0]) 
			SWAP(v0,v1)
			
	} 
	else
	{
		// now test for trivial flat sided cases
		if (FCMP(p[v1][1], p[v2][1]) )
		{ 
			tri_type = NM3D_TRIANGLE_TYPE_FLAT_BOTTOM;
			
			// sort vertices left to right
			if (p[v2][0] < p[v1][0]) 
				SWAP(v1,v2)
				
		} 
		else
		{
			// must be a general triangle
			tri_type = NM3D_TRIANGLE_TYPE_GENERAL;
			
		} 
	}

	//����yֵ��С�����˳����p[v0]<p[v1]<p[v2]

// 	int x0=(int)(p[v0][0]+0.5);
// 	int x1=(int)(p[v1][0]+0.5);
// 	int x2=(int)(p[v1][0]+0.5);
// 
// 	int y0=(int)(p[v0][1]+0.5);
// 	int y1=(int)(p[v1][1]+0.5);
// 	int y2=(int)(p[v1][1]+0.5);
// 
// 	if ( ((x0 == x1) && (x1 == x2)) || ((y0 ==  y1) && (y1 == y2)))
// 			return;

	if( (p[v0][0]== p[v1][0] && p[v1][0] == p[v2][0]) || (p[v0][1]== p[v1][1] && p[v1][1] == p[v2][1]) )
		return;

	double ms;
	double me;

	int start_y;
	int restart_y;

	int y=0;
	int start_x,end_x;
	double am1,am2;

	if(tri_type == NM3D_TRIANGLE_TYPE_FLAT_TOP)
	{
		//return;
		ms = 1.0*(p[v2][0]-p[v0][0])/(p[v2][1]-p[v0][1]);
		me = 1.0*(p[v2][0]-p[v1][0])/(p[v2][1]-p[v1][1]);

		start_y = p[v0][1];
		restart_y = p[v2][1];

		for(am1=0,am2=0,y=start_y; y<=restart_y; y++,am1+=ms,am2+=me)
		{
			start_x = (int)(1.0*p[v0][0] + am1 - 1 - NM3D_EPSILON_E6);
			end_x = (int)(1.0*p[v1][0] + am2 /*- NM3D_EPSILON_E6*/);

			if(start_x > end_x && y!=restart_y)
			{
				/*break;*/
				int aa=3;
				aa++;
			}
			int s=MIN(start_x,end_x);
			MemSet16((void*)(buff + y*WINDOW_WIDTH + s), clr, ABS_MINUS(end_x,start_x)+1);
		}
	}
	else if(tri_type == NM3D_TRIANGLE_TYPE_FLAT_BOTTOM)
	{
		//return ;
		ms = 1.0*(p[v1][0]-p[v0][0])/(p[v1][1]-p[v0][1]);
		me = 1.0*(p[v2][0]-p[v0][0])/(p[v2][1]-p[v0][1]);

		start_y = p[v0][1];
		restart_y = p[v1][1];

		for(am1=0,am2=0,y=start_y; y<=restart_y; y++,am1+=ms,am2+=me)
		{
			start_x = (int)(1.0*p[v0][0] + am1 -1 - NM3D_EPSILON_E6);
			end_x = (int)(1.0*p[v0][0] + am2/*- NM3D_EPSILON_E6*/);
			

			if(start_x > end_x && y!=restart_y)
			{
				/*break;*/
				int aa=3;
				aa++;
			}
			int s=MIN(start_x,end_x);
			MemSet16((void*)(buff + y*WINDOW_WIDTH + s), clr, ABS_MINUS(end_x,start_x)+1);
		}
	}
	else //NM3D_TRIANGLE_TYPE_GENERAL
	{
		//return ;
		double m3 = (1.0*p[v2][0]-p[v1][0])/(p[v2][1]-p[v1][1]);

		if(m3 < 0)
		{
			start_y = (int)(p[v0][1]);
			restart_y = (int)(p[v1][1]);

			if(p[v0][0] < p[v1][0])
			{
				ms = 1.0*(p[v2][0]-p[v0][0])/(p[v2][1]-p[v0][1]);
				me = 1.0*(p[v1][0]-p[v0][0])/(p[v1][1]-p[v0][1]);
				
				for(am1=0,am2=0,y=start_y; y<=restart_y; y++,am1+=ms,am2+=me)
				{
					start_x = (int)(1.0*p[v0][0] + am1 -1.0 - NM3D_EPSILON_E6);
					end_x = (int)(1.0*p[v0][0] + am2/*- NM3D_EPSILON_E6*/);
					if(start_x > end_x && y!=restart_y)
					{
						/*break;*/
						int aaa=0;
						aaa++;
					}
					int s=MIN(start_x,end_x);
					MemSet16((void*)(buff + y*WINDOW_WIDTH + s), clr, ABS_MINUS(end_x,start_x)+1);
				}

				restart_y = (int)(p[v2][1]);

				for(am2=0; y<=restart_y; y++,am1+=ms,am2+=m3)
				{
					start_x = (int)(p[v0][0] + am1 -1.0 - NM3D_EPSILON_E6);
					end_x = (int)(p[v1][0] + am2/*- NM3D_EPSILON_E6*/);
					if(start_x > end_x && y!=restart_y)
					{
						/*break;*/
						int aaa=0;
						aaa++;
					}
					int s=MIN(start_x,end_x);
					MemSet16((void*)(buff + y*WINDOW_WIDTH + s), clr, ABS_MINUS(end_x,start_x)+1);
				}

			}
			else // p[v0][0] < p[v1][0]
			{
				ms = 1.0*(p[v1][0]-p[v0][0])/(p[v1][1]-p[v0][1]);
				me = 1.0*(p[v2][0]-p[v0][0])/(p[v2][1]-p[v0][1]);
				
				for(am1=0,am2=0,y=start_y; y<=restart_y; y++,am1+=ms,am2+=me)
				{
					start_x = (int)(1.0*p[v0][0] + am1 -1.0 - NM3D_EPSILON_E6);
					end_x = (int)(1.0*p[v0][0] + am2/*- NM3D_EPSILON_E6*/);
					if(start_x > end_x && y!=restart_y)
					{
						/*break;*/
						int aaa=0;
						aaa++;
					}
					int s=MIN(start_x,end_x);
					MemSet16((void*)(buff + y*WINDOW_WIDTH + s), clr, ABS_MINUS(end_x,start_x)+1);
				}

				restart_y = (int)(p[v2][1]);

				for(am1=0; y<=restart_y; y++,am1+=m3,am2+=me)
				{
					start_x = (int)(p[v1][0] + am1 -1.0 - NM3D_EPSILON_E6);
					end_x = (int)(p[v0][0] + am2/*- NM3D_EPSILON_E6*/);
					if(start_x > end_x && y!=restart_y)
					{
						/*break;*/
						int aaa=0;
						aaa++;
					}
					int s=MIN(start_x,end_x);
					MemSet16((void*)(buff + y*WINDOW_WIDTH + s), clr, ABS_MINUS(end_x,start_x)+1);
				}
			}
		}
		else // m3 > 0
		{
			start_y = (int)(p[v0][1]);
			restart_y = (int)(p[v1][1]);

			if(p[v0][0] < p[v1][0])
			{
				ms = 1.0*(p[v2][0]-p[v0][0])/(p[v2][1]-p[v0][1]);
				me = 1.0*(p[v1][0]-p[v0][0])/(p[v1][1]-p[v0][1]);
				
				for(am1=0,am2=0,y=start_y; y<=restart_y; y++,am1+=ms,am2+=me)
				{
					start_x = (int)(1.0*p[v0][0] + am1 -1.0 - NM3D_EPSILON_E6);
					end_x = (int)(1.0*p[v0][0] + am2/*- NM3D_EPSILON_E6*/);
					if(start_x > end_x && y!=restart_y)
					{
						/*break;*/
						int aaa=0;
						aaa++;
					}
					int s=MIN(start_x,end_x);
					MemSet16((void*)(buff + y*WINDOW_WIDTH + s), clr, ABS_MINUS(end_x,start_x)+1);
				}

				restart_y = (int)(p[v2][1]);
				
				for(am2=0; y<=restart_y; y++,am1+=ms,am2+=m3)
				{
					start_x = (int)(p[v0][0] + am1 -1.0 - NM3D_EPSILON_E6);
					end_x = (int)(p[v1][0] + am2/*- NM3D_EPSILON_E6*/);
					if(start_x > end_x && y!=restart_y)
					{
						/*break;*/
						int aaa=0;
						aaa++;
					}
					int s=MIN(start_x,end_x);
					MemSet16((void*)(buff + y*WINDOW_WIDTH + s), clr, ABS_MINUS(end_x,start_x)+1);
				}

			}
			else // p[v0][0] < p[v1][0]
			{
				ms = 1.0*(p[v1][0]-p[v0][0])/(p[v1][1]-p[v0][1]);
				me = 1.0*(p[v2][0]-p[v0][0])/(p[v2][1]-p[v0][1]);
				
				for(am1=0,am2=0,y=start_y; y<=restart_y; y++,am1+=ms,am2+=me)
				{
					start_x = (int)(1.0*p[v0][0] + am1 -1.0 - NM3D_EPSILON_E6);
					end_x = (int)(1.0*p[v0][0] + am2/*- NM3D_EPSILON_E6*/);
					if(start_x > end_x && y!=restart_y)
					{
						/*break;*/
						int aaa=0;
						aaa++;
					}
					int s=MIN(start_x,end_x);
					MemSet16((void*)(buff + y*WINDOW_WIDTH + s), clr, ABS_MINUS(end_x,start_x)+1);
				}
				
				restart_y = (int)(p[v2][1]);
				
				for(am1=0; y<=restart_y; y++,am1+=m3,am2+=me)
				{
					start_x = (int)(p[v1][0] + am1 -1.0 - NM3D_EPSILON_E6);
					end_x = (int)(p[v0][0] + am2/*- NM3D_EPSILON_E6*/);
					if(start_x > end_x && y!=restart_y)
					{
						/*break;*/
						int aaa=0;
						aaa++;
					}
					int s=MIN(start_x,end_x);
					MemSet16((void*)(buff + y*WINDOW_WIDTH + s), clr, ABS_MINUS(end_x,start_x)+1);
				}
			}
		}

	}

}

#endif