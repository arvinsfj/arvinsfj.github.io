#ifndef LUT_H_34886567_EFC4_4e6b_B4F8_8B027712B585
#define LUT_H_34886567_EFC4_4e6b_B4F8_8B027712B585

namespace Nomad3D
{
	extern float LUT_Sin[360];
	extern float LUT_Cos[360];
	extern unsigned char LUT_LogBase2[513];
}

#endif //LUT_H_34886567_EFC4_4e6b_B4F8_8B027712B585
