// timer.h: interface for the CTimer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TIMER_H__DAA71C44_ECE5_415A_8850_13C0783927B8__INCLUDED_)
#define AFX_TIMER_H__DAA71C44_ECE5_415A_8850_13C0783927B8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nomad3d.h"

namespace Nomad3D
{
#ifdef NM3D_PLATFORM_WIN32
#include "../platform/win32/timer.h"
#endif
}

#endif // !defined(AFX_TIMER_H__DAA71C44_ECE5_415A_8850_13C0783927B8__INCLUDED_)
