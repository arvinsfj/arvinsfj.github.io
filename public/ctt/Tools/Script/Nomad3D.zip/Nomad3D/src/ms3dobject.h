// ms3dobject.h: interface for the CMS3DObject class.
//
//////////////////////////////////////////////////////////////////////

#ifndef MS3DOBJECT_H_B48CED90_DC0E_4CC9_8CCE_A39137653320
#define MS3DOBJECT_H_B48CED90_DC0E_4CC9_8CCE_A39137653320

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nomad3d.h"
#include "object.h"
//#include "bonevector.h"
//#include "polygon.h"
#include "mesh.h"
#include "material.h"
#include "quaternion.h"
#include "timer.h"

namespace Nomad3D
{
	class CMS3DObject : public CObject  
	{
	public:
		CMS3DObject();
		virtual ~CMS3DObject();
	public:
		bool ReadObjectFile(const char* szFilename);
		bool SetupSkeleton();
		void CalcLocalMatrix(const float* fRotation, const float* fPosition, CMatrix4& mat);
		void SetPolygonMaterialAndVertList();
	};
}

#endif //MS3DOBJECT_H_B48CED90_DC0E_4CC9_8CCE_A39137653320
