// mesh.h: interface for the CMesh class.
//
//////////////////////////////////////////////////////////////////////

#ifndef MESH_H_F2468E5D_8F32_44E8_ACE4_5A9F725B6D88
#define MESH_H_F2468E5D_8F32_44E8_ACE4_5A9F725B6D88

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "nomad3d.h"

namespace Nomad3D
{
#pragma pack(push, packing)
#pragma pack(1)

	class CLight;

	class CMesh  
	{ 
		friend class CLight;
	public:
		CMesh()
		{
			m_pusIndices = NULL;
		}

		CMesh(unsigned short usNumPolys, unsigned char* pusIndices, char cMaterial)
		{
			Assign(usNumPolys, pusIndices, cMaterial);
		}

		~CMesh()
		{
			if(m_pusIndices)
			{
				delete [] m_pusIndices;
				m_pusIndices = NULL;
			}
		}

		void Assign(unsigned short usNumPolys, unsigned char* pusIndices, char cMaterial)
		{
			m_usNumPolys = usNumPolys;
			m_cMaterial = cMaterial;
			m_pusIndices = new unsigned short[usNumPolys];
			memcpy(m_pusIndices, pusIndices, sizeof(unsigned short)*usNumPolys);
		}

		inline void SetMaterial(char cIndex)
		{
			m_cMaterial  = cIndex;
		}
	public: 
		unsigned short  m_usNumPolys;	//�����ڰ����Ķ��������
		unsigned short* m_pusIndices;	//���������
		char			m_cMaterial;	//��������, -1��ʾû�в���
	};
#pragma pack(pop, packing)
}


#endif //MESH_H_F2468E5D_8F32_44E8_ACE4_5A9F725B6D88
