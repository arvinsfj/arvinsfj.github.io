// Font.h: interface for the CFont class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FONT_H__9DA912C9_F93E_4ED9_BD51_672A30C1BDE6__INCLUDED_)
#define AFX_FONT_H__9DA912C9_F93E_4ED9_BD51_672A30C1BDE6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "rgb.h"

#define FONT8_ASC_COUNT			95	//���ַ���
#define FONT8_ASC_START			32	//��ʼ�ַ�
#define FONT8_ASC_WIDTH			8	//ÿ���ַ��Ŀ���(����)
#define FONT8_ASC_HEIGHT		8	//ÿ���ַ��ĸ߶�(����)

#define ROW_SPACE			1	//�м��(����)
#define COL_SPACE			1	//�м��(����)
#define TAB_SPACE_NUM		4	//ÿ��TABת���ɼ����ո����

namespace Nomad3D
{
	enum EFontType
	{
		enFont8
	};

	struct STextPos
	{
		int row;
		int col;
	} ;

	class CFont
	{
	public:
		CFont(unsigned char* pBuff)
		{
			m_enCurFontType = enFont8;
			m_CurTextPos.row = m_CurTextPos.col = 0;
			m_pBuff = pBuff;
			m_rgbText = CRGBA(255,255,255,255);
		};
		virtual ~CFont(){};
		//////////////////////////////////////////////////////////////////////////
		virtual inline DrawChar(int nRow, int nCol, int nIndex, CRGBA color,  unsigned short* buffer)=0;
		virtual STextPos DrawString(int row,int col,const char* p, NM3D_BUFFER buffer)=0;
		inline ResetPos()
		{
			m_CurTextPos.row = m_CurTextPos.col = 0;
		}
		inline ResetPos(int row, int col)
		{
			m_CurTextPos.row = row;
			m_CurTextPos.col = col;
		}
		inline SetCurFont(EFontType enFT=enFont8)
		{
			m_enCurFontType = enFT;
		}
		EFontType GetCurFont()
		{
			return m_enCurFontType;
		}
		CRGBA SetTextColor(CRGBA rgba)
		{
			CRGBA t = m_rgbText;
			m_rgbText = rgba;
			return t;
		}
	protected:
		EFontType	m_enCurFontType;
		STextPos	m_CurTextPos;
		unsigned char*	m_pBuff;
		CRGBA		m_rgbText;
	};
}
#endif // !defined(AFX_FONT_H__9DA912C9_F93E_4ED9_BD51_672A30C1BDE6__INCLUDED_)
