#ifndef NOMAD3D_H_9676F8D5_52E6_4a3a_B090_BB5F8C0149AA
#define NOMAD3D_H_9676F8D5_52E6_4a3a_B090_BB5F8C0149AA

#include "config.h"
#include "../platform/platform.h"
#include "log.h"
#include "constant.h"

namespace Nomad3D
{
	// #pragma pack(push, packing)
	// #pragma pack(1)
	
#ifndef NULL
#	define NULL	0
#endif
	
#if NM3D_DEBUG_ON
#include <assert.h>
#endif
}


#endif //NOMAD3D_H_9676F8D5_52E6_4a3a_B090_BB5F8C0149AA