#include "tga.h"

#include "5_7font.h"

struct tga_color white = {{255, 255, 255}, RGB};
struct tga_color black = {{0, 0, 0}, RGB};
struct tga_color red   = {{0, 0, 255}, RGB};
struct tga_color blue   = {{255, 0, 0}, RGB};
struct tga_color green   = {{0, 255, 0}, RGB};

static void draw_char(int x, int y, unsigned char ch, struct tga_image* tga)
{
    if (ch < 128 && ch > 31){
        unsigned char *ch_rep = nAsciiDot+(ch-32)*8;
        int x0 = x;
        for (int i = 0; i < 8; i++, y++, ch_rep++){
            x = x0;
            for (int j = 0; j < 8; j++, x++){
                tga_set(x, y, ((*ch_rep >> (7-j)) & 1) ? &white : &black, tga);
            }
        }
    }
}

int main(int argc, char** argv)
{
    struct tga_image tga;
    tga_create(1024, 768, RGB, &tga);
    
    char *str = "Hello! My name is Cheng Ze. You can call me Arvin. I was born in 1980s. I live in Shanghai, China with my soulmate. I work at aifuwo as an Project Manager (or Senior Software Engineer) on the iOS Development team. I love programing and am usually busy with side projects or software hacking. My favorite languages are Go and Python, but I have broad experience with many languages and technologies. Much of my computing interest is geared toward graphics, 3d render, emulator, os, hacking. In spare time, I like reading, gardening, 80's game, hacking and all kinds of music.";
    for (int i = 0; i < strlen(str); i++) {
        draw_char(8*(i%126)+8, 10*(i/126)+8, (unsigned char)str[i], &tga);
    }
    
    //tga_flip_v(&tga);
    tga_write("output.tga", 1, &tga);
	return 0;
}

