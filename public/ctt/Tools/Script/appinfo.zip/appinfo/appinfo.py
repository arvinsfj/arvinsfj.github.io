#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import json
import httplib,urllib,urllib2

def appInfo(appleid):
    url = "http://itunes.apple.com/lookup"
    parameters = { "id": appleid }
    data_encode = urllib.urlencode(parameters)
    url += "?"+data_encode
    response = urllib2.urlopen(url)
    res = response.read()
    return str(res)
	

if len(sys.argv) < 2:
	print ""
	print "Error: Please enter an apple id."
	print "Usage: ./appinfo.py <appleid> or python ./appinfo.py <appleid>"
	print ""
	quit()
	
appleid = sys.argv[1];
jsonStr = appInfo(appleid)
jsonData = json.loads(jsonStr)
data = jsonData["results"][0]

print ""
print "=============================App Basic Info============================"
print ""
print data["trackName"]
print "date: %s" % data["releaseDate"]
print " aid: %s  bid: %s  minos: %s" % (data["trackId"], data["bundleId"], data["minimumOsVersion"])
print data["artistName"]
print data["sellerName"]
print ""
print "=============================Current Version Info============================"
print ""
print "version: %s" % data["version"]
print "   date: %s" % data["currentVersionReleaseDate"]
print "   size: %.2fM" % (float(data["fileSizeBytes"])/1024/1024)
if 'releaseNotes' in data:
	print "  notes: "
	print data["releaseNotes"]
print ""
print "=============================App Other Info============================"
print ""
print data["trackViewUrl"]
print ""
print data["artworkUrl512"]
for url in data["screenshotUrls"]:
	print ""
	print url
#print data["description"]
print ""



