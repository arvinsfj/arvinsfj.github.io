make
make clean

cat test.txt | ./asciimage -ft1 text.tga
