make
make clean

cat test.txt | ./asciimage -ft2 text.tga
