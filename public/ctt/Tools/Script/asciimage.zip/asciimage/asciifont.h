

#ifndef ASCIIFONT_H
#define ASCIIFONT_H

void draw_txt(char* str, int len, int type, char* filename);

#endif
