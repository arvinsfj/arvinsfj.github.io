#include <stdio.h>

#include "cpu.h"

struct CPU* initCPU(struct Console* console)
{
    CPU cpu = {console,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,{
        brk,  ora,  kil,  slo,  nop,  ora,  asl,  slo,
        php,  ora,  asl,  anc,  nop,  ora,  asl,  slo,
        bpl,  ora,  kil,  slo,  nop,  ora,  asl,  slo,
        clc,  ora,  nop,  slo,  nop,  ora,  asl,  slo,
        jsr,  and,  kil,  rla,  bit,  and,  rol,  rla,
        plp,  and,  rol,  anc,  bit,  and,  rol,  rla,
        bmi,  and,  kil,  rla,  nop,  and,  rol,  rla,
        sec,  and,  nop,  rla,  nop,  and,  rol,  rla,
        rti,  eor,  kil,  sre,  nop,  eor,  lsr,  sre,
        pha,  eor,  lsr,  alr,  jmp,  eor,  lsr,  sre,
        bvc,  eor,  kil,  sre,  nop,  eor,  lsr,  sre,
        cli,  eor,  nop,  sre,  nop,  eor,  lsr,  sre,
        rts,  adc,  kil,  rra,  nop,  adc,  ror,  rra,
        pla,  adc,  ror,  arr,  jmp,  adc,  ror,  rra,
        bvs,  adc,  kil,  rra,  nop,  adc,  ror,  rra,
        sei,  adc,  nop,  rra,  nop,  adc,  ror,  rra,
        nop,  sta,  nop,  sax,  sty,  sta,  stx,  sax,
        dey,  nop,  txa,  xaa,  sty,  sta,  stx,  sax,
        bcc,  sta,  kil,  ahx,  sty,  sta,  stx,  sax,
        tya,  sta,  txs,  tas,  shy,  sta,  shx,  ahx,
        ldy,  lda,  ldx,  lax,  ldy,  lda,  ldx,  lax,
        tay,  lda,  tax,  lax,  ldy,  lda,  ldx,  lax,
        bcs,  lda,  kil,  lax,  ldy,  lda,  ldx,  lax,
        clv,  lda,  tsx,  las,  ldy,  lda,  ldx,  lax,
        cpy,  cmp,  nop,  dcp,  cpy,  cmp,  dec,  dcp,
        iny,  cmp,  dex,  axs,  cpy,  cmp,  dec,  dcp,
        bne,  cmp,  kil,  dcp,  nop,  cmp,  dec,  dcp,
        cld,  cmp,  nop,  dcp,  nop,  cmp,  dec,  dcp,
        cpx,  sbc,  nop,  isc,  cpx,  sbc,  inc,  isc,
        inx,  sbc,  nop,  sbc,  cpx,  sbc,  inc,  isc,
        beq,  sbc,  kil,  isc,  nop,  sbc,  inc,  isc,
        sed,  sbc,  nop,  isc,  nop,  sbc,  inc,  isc,
    }};
    reset(&cpu);
    return &cpu;
}

void reset(struct CPU* cpu)
{
    cpu->PC = read16(0xFFFC, cpu);
    cpu->SP = 0xFD;
    set_flags(0x24, cpu);
}

void printInstruction(struct CPU* cpu)
{
    char opcode = read(cpu->PC, cpu);
    char bytes = instructionSizes[opcode];
    char* name = instructionNames[opcode];
    char* w0 = sprintf("%02X", read(cpu->PC+0, cpu))
    char* w1 = sprintf("%02X", read(cpu->PC+1, cpu))
    char* w2 = sprintf("%02X", read(cpu->PC+2, cpu))
    if (bytes < 2) {
        w1 = "  ";
    }
    if (bytes < 3) {
        w2 = "  ";
    }
    printf("%4X  %s %s %s  %s %28s A:%02X X:%02X Y:%02X P:%02X SP:%02X CYC:%3d\n", cpu->PC, w0, w1, w2, name, "", cpu->A, cpu->X, cpu->Y, flags(cpu), cpu->SP, (cpu->Cycles*3)%341);
}

void write(short address, char value, struct CPU* cpu)
{
    if (address < 0x2000) {
        cpu->console->RAM[address%0x0800] = value;
    }
    if (address < 0x4000) {
        cpu->console->PPU->writeRegister(0x2000 + address%8, value);
    }
    if (address < 0x4014) {
        return cpu->console->APU->writeRegister(address, value);
    }
    if (address == 0x4014) {
        return cpu->console->PPU->writeRegister(address, value);
    }
    if (address == 0x4015) {
        return cpu->console->APU->writeRegister(address, value);
    }
    if (address == 0x4016) {
        return cpu->console->js1->write(value);
        return cpu->console->js2->write(value);
    }
    if (address == 0x4017) {
        return cpu->console->APU->writeRegister(address, value);
    }
    if (address < 0x6000) {
        // TODO: I/O registers
    }
    if (address >= 0x6000) {
        return cpu->console->mapper->write(address, value);
    }
    printf("unhandled cpu memory write at address: 0x%04X", address);
}
char read(short address, struct CPU* cpu)
{
    if (address < 0x2000) {
        return cpu->console->RAM[address%0x0800];
    }
    if (address < 0x4000) {
        return cpu->console->PPU->readRegister(0x2000 + address%8);
    }
    if (address == 0x4014) {
        return cpu->console->PPU->readRegister(address);
    }
    if (address == 0x4015) {
        return cpu->console->APU->readRegister(address);
    }
    if (address == 0x4016) {
        return cpu->console->js1->read();
    }
    if (address == 0x4017) {
        return cpu->console->js2->read();
    }
    if (address < 0x6000) {
        // TODO: I/O registers
    }
    if (address >= 0x6000) {
        return cpu->console->mapper->read(address);
    }
    printf("unhandled cpu memory read at address: 0x%04X", address);
    return 0;
}

char pagesDiffer(short a, short b)
{
    return (a&0xFF00 != b&0xFF00);
}

void addBranchCycles(struct stepInfo* info, struct CPU* cpu)
{
    cpu->Cycles++;//分支操作本身需要1个时钟周期
    if (pagesDiffer(info->pc, info->address)) {
        cpu->Cycles++;//分支指令跨页操作需要1个时钟周期
    }
}

void compare(char a, char b, struct CPU* cpu)
{
    set_ZN(a - b, cpu);
    if (a >= b) {
        cpu->C = 1;
    } else {
        cpu->C = 0;
    }
}

short read16(short address, struct CPU* cpu)
{
    short lo = (short)(read(address, cpu));
    short hi = (short)(read(address + 1, cpu));
    return (short)(hi<<8 | lo);
}
short read16bug(short address, struct CPU* cpu)
{
    short a = address;
    short b = (a & 0xFF00) | (short)((char)(a)+1);
    short lo = read(a, cpu);
    short hi = read(b, cpu);
    return (short)((short)(hi)<<8 | (short)(lo));
}

void push(char value, struct CPU* cpu)
{
    write(0x0100|(short)(cpu->SP), value);
    cpu->SP--;
}
char pull(struct CPU* cpu)
{
    cpu->SP++;
    return read(0x100 | (short)(cpu->SP), cpu);
}
void push16(short value, struct CPU* cpu)
{
    char hi = (char)(value >> 8);
    char lo = (char)(value & 0x00FF);
    push(hi, cpu);
    push(lo, cpu);
}
short pull16(struct CPU* cpu)
{
    short lo = (short)(pull(cpu));
    short hi = (short)(pull(cpu));
    return (short)(hi<<8 | lo);
}

char flags(struct CPU* cpu)
{
    char flags = 0;
    flags |= cpu->C << 0;//进位标志
    flags |= cpu->Z << 1;//零数标志
    flags |= cpu->I << 2;//中断标志:0,开启中断 1,关闭中断
    flags |= cpu->D << 3;//十进制模式标志
    flags |= cpu->B << 4;//break标志
    flags |= cpu->U << 5;//保留未使用，1
    flags |= cpu->V << 6;//溢出标志
    flags |= cpu->N << 7;//负数标志
    return flags;
}
void set_flags(char flag, struct CPU* cpu)
{
    cpu->C = (flags >> 0) & 1;
    cpu->Z = (flags >> 1) & 1;
    cpu->I = (flags >> 2) & 1;
    cpu->D = (flags >> 3) & 1;
    cpu->B = (flags >> 4) & 1;
    cpu->U = (flags >> 5) & 1;
    cpu->V = (flags >> 6) & 1;
    cpu->N = (flags >> 7) & 1;
}

void set_Z(char value, struct CPU* cpu)
{
    if (value == 0) {
        cpu->Z = 1;
    }else{
        cpu->Z = 0;
    }
}
void set_N(char value, struct CPU* cpu)
{
    if (value&0x80 != 0) {
        cpu->N = 1;
    } else {
        cpu->N = 0;
    }
}
void set_ZN(char value, struct CPU* cpu)
{
    set_Z(value, cpu);
    set_N(value, cpu);
}

void triggerNMI(struct CPU* cpu)
{
    cpu->interrupt = interruptNMI;//不可屏蔽中断
}
void triggerIRQ(struct CPU* cpu)
{
    if cpu->I == 0 {//中断开启状态
        cpu->interrupt = interruptIRQ;//中断请求
    }
}

//对外驱动接口
int step(struct CPU* cpu)
{
    if (cpu->stall > 0) {//cpu停止运行，直到stall<=0;
        cpu->stall--;
        return 1;
    }
    
    long cycles = cpu->Cycles;//cpu运行指令之前的时钟周期总数
    
    switch (cpu->interrupt) {//中断优先级高于普通指令
        case interruptNMI:
            nmi(cpu);//处理不能屏蔽中断，保存pc、flags并设置新的pc、关闭中断和增加时钟周期
            break;
            
        case interruptIRQ:
            irq(cpu);//处理普通中断请求
            break;
            
        default:
            break;
    }
    cpu->interrupt = interruptNone;//设置无中断，告诉cpu没有中断
    
    char opcode = read(cpu->PC, cpu);//根据pc地址读取操作码（取指令操作码）
    char mode = instructionModes[opcode];//获取指令的寻址模式
    
    short address = 0;
    char pageCrossed = 0;
    
    //指令结构：[操作码] [操作码 操作数] [操作码 操作数地址]
    switch (mode) {//根据寻址模式，计算指令的操作数地址（或者数据），并判断是否跨页,若跨页时钟周期+1
        case modeAbsolute://【操作码 操作数地址】
            address = read16(cpu->PC+1, cpu);
            break;
        case modeAbsoluteX://【操作码 操作数部分地址】+ X
            address = read16(cpu->PC+1, cpu) + (short)(cpu->X);
            pageCrossed = pagesDiffer(address - (short)(cpu->X), address);
            break;
        case modeAccumulator://【操作码】A
            address = 0;
            break;
        case modeImmediate://【操作码 操作数】
            address = cpu->PC + 1;
            break;
        case modeImplied://【操作码】隐含操作数，如：CLC RTS等
            address = 0;
            break;
        case modeIndexedIndirect://【操作码 操作数地址表索引】+ X ，地址表结构寻址
            address = read16bug((short)(read(cpu->PC+1, cpu) + cpu->X), cpu);
            break;
        case modeIndirect://【操作码 操作数地址表地址】，直接通过操作数地址表地址获取操作数地址
            address = read16bug(read16(cpu->PC + 1, cpu), cpu);
            break;
        case modeIndirectIndexed://【操作码 操作数地址表索引地址】+ Y
            address = read16bug((short)(read(cpu->PC+1, cpu)), cpu) + (short)(cpu->Y);
            pageCrossed = pagesDiffer(address-(short)(cpu->Y), address);
            break;
        case modeRelative://【操作码 相对偏移量】
            short offset = (short)(read(cpu->PC + 1, cpu));
            if (offset < 0x80) {
                address = cpu->PC + 2 + offset;
            } else {
                address = cpu->PC + 2 + offset - 0x100;
            }
            break;
        case modeZeroPage://【操作码 操作数零页地址】
            address = (short)(read(cpu->PC + 1, cpu));
            break;
        case modeZeroPageX://【操作码 操作数零页部分地址】+ X
            address = (short)(read(cpu->PC + 1, cpu) + cpu->X);
            break;
        case modeZeroPageY://【操作码 操作数零页部分地址】+ Y
            address = (short)(read(cpu->PC + 1, cpu) + cpu->Y);
            break;
            
        default:
            break;
    }
    
    //指令大小，即指令占用的字节总数(操作码和操作数或操作数地址)
    cpu->PC += (short)(instructionSizes[opcode]);//跳转到下一指令
    cpu->Cycles += (long)(instructionCycles[opcode]);//cpu时钟周期总数增加指令所消耗的时钟周期
    if (pageCrossed) {//如果指令寻址操作跨页，则需要增加额外的时钟周期
        cpu->Cycles += (long)(instructionPageCycles[opcode]);
    }
    struct stepInfo info = {address, cpu->PC, mode};//封装运行时信息：操作数地址、pc、寻址方式
    cpu->table[opcode](&info, cpu);//执行某条指令
    
    //返回中断设置（如果有）、寻址和执行某条指令所需的周期总数
    //即，cpu执行一步所耗费的总时间，单位是时钟周期
    return (int)(cpu->Cycles - cycles);
}

// NMI - Non-Maskable Interrupt
void nmi(struct CPU* cpu)
{
    push16(cpu->PC, cpu);//保存pc
    php(NULL, cpu);//保存flags
    cpu->PC = read16(0xFFFA, cpu);//从地址向量0xFFFA读取中断程序入口地址到pc中
    cpu->I = 1;//关闭IRQ中断
    cpu->Cycles += 7;//cpu时钟周期总数增加7个周期，即NMI设置耗费7个时钟周期(不包含中断处理周期)
}

// IRQ - IRQ Interrupt
void irq(struct CPU* cpu)
{
    push16(cpu->PC, cpu);
    php(NULL, cpu);
    cpu->PC = read16(0xFFFE, cpu);
    cpu->I = 1;
    cpu->Cycles += 7;
}

//下面是指令实现函数

// ADC - Add with Carry
void adc(struct stepInfo* info, struct CPU* cpu)
{
    char a = cpu->A;
    char b = read(info->address, cpu);
    char c = cpu->C;
    cpu->A = a + b + c;
    set_ZN(cpu->A, cpu);
    if ((int)(a)+(int)(b)+(int)(c) > 0xFF) {
        cpu->C = 1;
    } else {
        cpu->C = 0;
    }
    if ((a^b)&0x80 == 0 && (a^cpu->A)&0x80 != 0) {
        cpu->V = 1;
    } else {
        cpu->V = 0;
    }
}

// AND - Logical AND
void and(struct stepInfo* info, struct CPU* cpu)
{
    cpu->A = cpu->A & read(info->address, cpu);
    set_ZN(cpu->A, cpu);
}

// ASL - Arithmetic Shift Left
void asl(struct stepInfo* info, struct CPU* cpu)
{
    if (info->mode == modeAccumulator) {
        cpu->C = (cpu->A >> 7) & 1;
        cpu->A <<= 1;
        set_ZN(cpu->A, cpu);
    } else {
        char value = read(info->address, cpu);
        cpu->C = (value >> 7) & 1;
        value <<= 1;
        write(info->address, value, cpu);
        set_ZN(value,cpu);
    }
}

// BCC - Branch if Carry Clear
void bcc(struct stepInfo* info, struct CPU* cpu)
{
    if (cpu->C == 0) {
        cpu->PC = info->address;
        addBranchCycles(info, cpu);
    }
}

// BCS - Branch if Carry Set
void bcs(struct stepInfo* info, struct CPU* cpu)
{
    if (cpu->C != 0) {
        cpu->PC = info->address;
        addBranchCycles(info, cpu);
    }
}

// BEQ - Branch if Equal
void beq(struct stepInfo* info, struct CPU* cpu)
{
    if (cpu->Z != 0) {
        cpu->PC = info->address;
        addBranchCycles(info, cpu);
    }
}

// BIT - Bit Test
void bit(struct stepInfo* info, struct CPU* cpu)
{
    char value = read(info->address, cpu);
    cpu->V = (value >> 6) & 1;
    set_Z(value & cpu->A, cpu);
    set_N(value, cpu);
}

// BMI - Branch if Minus
void bmi(struct stepInfo* info, struct CPU* cpu)
{
    if (cpu->N != 0) {
        cpu->PC = info->address;
        addBranchCycles(info, cpu);
    }
}

// BNE - Branch if Not Equal
void bne(struct stepInfo* info, struct CPU* cpu)
{
    if (cpu->Z == 0) {
        cpu->PC = info->address;
        addBranchCycles(info, cpu);
    }
}

// BPL - Branch if Positive
void bpl(struct stepInfo* info, struct CPU* cpu)
{
    if (cpu->N == 0) {
        cpu->PC = info->address;
        addBranchCycles(info, cpu);
    }
}

// BRK - Force Interrupt
void brk(struct stepInfo* info, struct CPU* cpu)
{
    push16(cpu->PC, cpu);
    php(info, cpu);
    sei(info, cpu);
    cpu->PC = read16(0xFFFE, cpu);
}

// BVC - Branch if Overflow Clear
void bvc(struct stepInfo* info, struct CPU* cpu)
{
    if (cpu->V == 0) {
        cpu->PC = info->address;
        addBranchCycles(info, cpu);
    }
}

// BVS - Branch if Overflow Set
void bvs(struct stepInfo* info, struct CPU* cpu)
{
    if (cpu->V != 0) {
        cpu->PC = info->address;
        addBranchCycles(info, cpu);
    }
}

// CLC - Clear Carry Flag
void clc(struct stepInfo* info, struct CPU* cpu)
{
    cpu->C = 0;
}

// CLD - Clear Decimal Mode
void cld(struct stepInfo* info, struct CPU* cpu)
{
    cpu->D = 0;
}

// CLI - Clear Interrupt Disable
void cli(struct stepInfo* info, struct CPU* cpu)
{
    cpu->I = 0;
}

// CLV - Clear Overflow Flag
void clv(struct stepInfo* info, struct CPU* cpu)
{
    cpu->V = 0;
}

// CMP - Compare
void cmp(struct stepInfo* info, struct CPU* cpu)
{
    char value = read(info->address, cpu);
    compare(cpu->A, value, cpu);
}

// CPX - Compare X Register
void cpx(struct stepInfo* info, struct CPU* cpu)
{
    char value = read(info->address, cpu);
    compare(cpu->X, value, cpu);
}

// CPY - Compare Y Register
void cpy(struct stepInfo* info, struct CPU* cpu)
{
    char value = read(info->address, cpu);
    compare(cpu->Y, value, cpu);
}

// DEC - Decrement Memory
void dec(struct stepInfo* info, struct CPU* cpu)
{
    char value = read(info->address, cpu) - 1;
    write(info->address, value, cpu);
    set_ZN(value, cpu);
}

// DEX - Decrement X Register
void dex(struct stepInfo* info, struct CPU* cpu)
{
    cpu->X--;
    set_ZN(cpu->X, cpu);
}

// DEY - Decrement Y Register
void dey(struct stepInfo* info, struct CPU* cpu)
{
    cpu->Y--;
    set_ZN(cpu->Y, cpu);
}

// EOR - Exclusive OR 按位异或
void eor(struct stepInfo* info, struct CPU* cpu)
{
    cpu->A = cpu->A ^ read(info->address, cpu);
    set_ZN(cpu->A, cpu);
}

// INC - Increment Memory
void inc(struct stepInfo* info, struct CPU* cpu)
{
    char value = read(info->address, cpu) + 1;
    write(info->address, value, cpu);
    set_ZN(value, cpu);
}

// INX - Increment X Register
void inx(struct stepInfo* info, struct CPU* cpu)
{
    cpu->X++;
    set_ZN(cpu->X, cpu);
}

// INY - Increment Y Register
void iny(struct stepInfo* info, struct CPU* cpu)
{
    cpu->Y++;
    set_ZN(cpu->Y, cpu);
}

// JMP - Jump
void jmp(struct stepInfo* info, struct CPU* cpu)
{
    cpu->PC = info->address;
}

// JSR - Jump to Subroutine
void jsr(struct stepInfo* info, struct CPU* cpu)
{
    push16(cpu->PC - 1, cpu);//保存pc-1地址，该指令执行后pc会加1
    cpu->PC = info->address;//跳转子程序入口地址
}

// LDA - Load Accumulator
void lda(struct stepInfo* info, struct CPU* cpu)
{
    cpu->A = read(info->address, cpu);
    set_ZN(cpu->A, cpu);
}

// LDX - Load X Register
void ldx(struct stepInfo* info, struct CPU* cpu)
{
    cpu->X = read(info->address, cpu);
    set_ZN(cpu->X, cpu);
}

// LDY - Load Y Register
void ldy(struct stepInfo* info, struct CPU* cpu)
{
    cpu->Y = read(info->address, cpu);
    set_ZN(cpu->Y, cpu);
}

// LSR - Logical Shift Right
void lsr(struct stepInfo* info, struct CPU* cpu)
{
    if (info->mode == modeAccumulator) {
        cpu->C = cpu->A & 1;
        cpu->A >>= 1;
        set_ZN(cpu->A, cpu);
    } else {
        char value = read(info->address, cpu);
        cpu->C = value & 1;
        value >>= 1;
        write(info->address, value, cpu);
        set_ZN(value, cpu);
    }
}

// NOP - No Operation
void nop(struct stepInfo* info, struct CPU* cpu)
{}

// ORA - Logical Inclusive OR 按位或
void ora(struct stepInfo* info, struct CPU* cpu)
{
    cpu->A = cpu->A | read(info->address, cpu);
    set_ZN(cpu->A, cpu);
}

// PHA - Push Accumulator
void pha(struct stepInfo* info, struct CPU* cpu)
{
    push(cpu->A, cpu);
}

// PHP - Push Processor Status
void php(struct stepInfo* info, struct CPU* cpu)
{
    push(flags(cpu) | 0x10);//设置break位为1，并保存flags
}

// PLA - Pull Accumulator
void pla(struct stepInfo* info, struct CPU* cpu)
{
    cpu->A = pull(cpu);
    set_ZN(cpu->A, cpu);
}

// PLP - Pull Processor Status
void plp(struct stepInfo* info, struct CPU* cpu)
{
    set_flags(pull(cpu)&0xEF | 0x20, cpu);
}

// ROL - Rotate Left 循环左移
void rol(struct stepInfo* info, struct CPU* cpu)
{
    if (info->mode == modeAccumulator) {
        char c = cpu->C;
        cpu->C = (cpu->A >> 7) & 1;
        cpu->A = (cpu->A << 1) | c;
        set_ZN(cpu->A, cpu);
    } else {
        char c = cpu->C;
        char value = read(info->address, cpu);
        cpu->C = (value >> 7) & 1;
        value = (value << 1) | c;
        write(info->address, value, cpu);
        set_ZN(value, cpu);
    }
}

// ROR - Rotate Right
void ror(struct stepInfo* info, struct CPU* cpu)
{
    if (info->mode == modeAccumulator) {
        char c = cpu->C;
        cpu->C = cpu->A  & 1;
        cpu->A = (cpu->A >> 1) | (c << 7);
        set_ZN(cpu->A, cpu);
    } else {
        char c = cpu->C;
        char value = read(info->address, cpu);
        cpu->C = value & 1;
        value = (value >> 1) | (c << 7);
        write(info->address, value, cpu);
        set_ZN(value, cpu);
    }
}

// RTI - Return from Interrupt
void rti(struct stepInfo* info, struct CPU* cpu)
{
    set_flags(pull(cpu)&0xEF | 0x20, cpu);//清空break标志，设置保留位1，最后设置恢复cpu状态标志
    cpu->PC = pull16(cpu);//恢复pc
}

// RTS - Return from Subroutine
void rts(struct stepInfo* info, struct CPU* cpu)
{
    cpu->PC = pull16(cpu) + 1;//恢复pc+1，执行下一条指令
}

// SBC - Subtract with Carry
void sbc(struct stepInfo* info, struct CPU* cpu)
{
    char a = cpu->A;
    char b = read(info->address, cpu);
    char c = cpu->C;
    cpu->A = a - b - (1 - c);
    set_ZN(cpu->A, cpu);
    if ((int)(a)-(int)(b)-(int)(1-c) >= 0) {
        cpu->C = 1;
    } else {
        cpu->C = 0;
    }
    if ((a^b)&0x80 != 0 && (a^cpu.A)&0x80 != 0) {
        cpu->V = 1;
    } else {
        cpu->V = 0;
    }
}

// SEC - Set Carry Flag
void sec(struct stepInfo* info, struct CPU* cpu)
{
    cpu->C = 1;
}

// SED - Set Decimal Flag
void sed(struct stepInfo* info, struct CPU* cpu)
{
    cpu->D = 1;
}

// SEI - Set Interrupt Disable
void sei(struct stepInfo* info, struct CPU* cpu)
{
    cpu->I = 1;
}

// STA - Store Accumulator
void sta(struct stepInfo* info, struct CPU* cpu)
{
    write(info->address, cpu->A, cpu);
}

// STX - Store X Register
void stx(struct stepInfo* info, struct CPU* cpu)
{
    write(info->address, cpu->X, cpu);
}

// STY - Store Y Register
void sty(struct stepInfo* info, struct CPU* cpu)
{
    write(info->address, cpu->Y, cpu);
}

// TAX - Transfer Accumulator to X
void tax(struct stepInfo* info, struct CPU* cpu)
{
    cpu->X = cpu->A;
    set_ZN(cpu->X, cpu);
}

// TAY - Transfer Accumulator to Y
void tay(struct stepInfo* info, struct CPU* cpu)
{
    cpu->Y = cpu->A;
    set_ZN(cpu->Y, cpu);
}

// TSX - Transfer Stack Pointer to X
void tsx(struct stepInfo* info, struct CPU* cpu)
{
    cpu->X = cpu->SP;
    set_ZN(cpu->X, cpu);
}

// TXA - Transfer X to Accumulator
void txa(struct stepInfo* info, struct CPU* cpu)
{
    cpu->A = cpu->X;
    set_ZN(cpu->A, cpu);
}

// TXS - Transfer X to Stack Pointer
void txs(struct stepInfo* info, struct CPU* cpu)
{
    cpu->SP = cpu->X;
}

// TYA - Transfer Y to Accumulator
void tya(struct stepInfo* info, struct CPU* cpu)
{
    cpu->A = cpu->Y;
    set_ZN(cpu->A, cpu);
}

// illegal opcodes below
void ahx(struct stepInfo* info, struct CPU* cpu){}
void alr(struct stepInfo* info, struct CPU* cpu){}
void anc(struct stepInfo* info, struct CPU* cpu){}
void arr(struct stepInfo* info, struct CPU* cpu){}
void axs(struct stepInfo* info, struct CPU* cpu){}
void dcp(struct stepInfo* info, struct CPU* cpu){}
void isc(struct stepInfo* info, struct CPU* cpu){}
void kil(struct stepInfo* info, struct CPU* cpu){}
void las(struct stepInfo* info, struct CPU* cpu){}
void lax(struct stepInfo* info, struct CPU* cpu){}
void rla(struct stepInfo* info, struct CPU* cpu){}
void rra(struct stepInfo* info, struct CPU* cpu){}
void sax(struct stepInfo* info, struct CPU* cpu){}
void shx(struct stepInfo* info, struct CPU* cpu){}
void shy(struct stepInfo* info, struct CPU* cpu){}
void slo(struct stepInfo* info, struct CPU* cpu){}
void sre(struct stepInfo* info, struct CPU* cpu){}
void tas(struct stepInfo* info, struct CPU* cpu){}
void xaa(struct stepInfo* info, struct CPU* cpu){}
