#include <stdio.h>
#include <string.h>

#include "console-internal.h"

#ifndef CONSOLE_H
#define CONSOLE_H

struct Console* init(char* path);
void reset(struct Console* console);

int step(struct Console* console);
int step_frame(struct Console* console);
void setp_seconds(double seconds,struct Console* console);

void set_js1(char* js1,struct Console* console);
void set_js2(char* js2,struct Console* console);

void set_audio_channel(double channel,struct Console* console);
void set_audio_sample_rate(double rate,struct Console* console);

char* img_buffer(struct Console* console);
char* bg_color(struct Console* console);

double audio_sample(struct Console* console);


#endif
