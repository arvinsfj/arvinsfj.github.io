#include <stdio.h>

#ifndef CONSOLE_INTERNAL_H
#define CONSOLE_INTERNAL_H

struct Console {
    //struct CPU* cpu;
    //struct APU* apu;
    //struct PPU* ppu;
    //struct Cart* cart;
    //struct Joystick* js1;
    //struct Joystick* js2;
    //struct MMC* mapper;
    //struct RAM* ram;
};

#endif
