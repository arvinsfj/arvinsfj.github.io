#include <stdio.h>

#include "console.h"

#ifndef CPU_H
#define CPU_H

const long CPUFrequency = 1789773;

enum interruptType {
    interruptNone = 1,
    interruptNMI,
    interruptIRQ
};

enum addressMode {
    modeAbsolute = 1,
    modeAbsoluteX,
    modeAbsoluteY,
    modeAccumulator,
    modeImmediate,
    modeImplied,
    modeIndexedIndirect,
    modeIndirect,
    modeIndirectIndexed,
    modeRelative,
    modeZeroPage,
    modeZeroPageX,
    modeZeroPageY
};

// instructionModes indicates the addressing mode for each instruction
char instructionModes[256] = {
    6, 7, 6, 7, 11, 11, 11, 11, 6, 5, 4, 5, 1, 1, 1, 1,
    10, 9, 6, 9, 12, 12, 12, 12, 6, 3, 6, 3, 2, 2, 2, 2,
    1, 7, 6, 7, 11, 11, 11, 11, 6, 5, 4, 5, 1, 1, 1, 1,
    10, 9, 6, 9, 12, 12, 12, 12, 6, 3, 6, 3, 2, 2, 2, 2,
    6, 7, 6, 7, 11, 11, 11, 11, 6, 5, 4, 5, 1, 1, 1, 1,
    10, 9, 6, 9, 12, 12, 12, 12, 6, 3, 6, 3, 2, 2, 2, 2,
    6, 7, 6, 7, 11, 11, 11, 11, 6, 5, 4, 5, 8, 1, 1, 1,
    10, 9, 6, 9, 12, 12, 12, 12, 6, 3, 6, 3, 2, 2, 2, 2,
    5, 7, 5, 7, 11, 11, 11, 11, 6, 5, 6, 5, 1, 1, 1, 1,
    10, 9, 6, 9, 12, 12, 13, 13, 6, 3, 6, 3, 2, 2, 3, 3,
    5, 7, 5, 7, 11, 11, 11, 11, 6, 5, 6, 5, 1, 1, 1, 1,
    10, 9, 6, 9, 12, 12, 13, 13, 6, 3, 6, 3, 2, 2, 3, 3,
    5, 7, 5, 7, 11, 11, 11, 11, 6, 5, 6, 5, 1, 1, 1, 1,
    10, 9, 6, 9, 12, 12, 12, 12, 6, 3, 6, 3, 2, 2, 2, 2,
    5, 7, 5, 7, 11, 11, 11, 11, 6, 5, 6, 5, 1, 1, 1, 1,
    10, 9, 6, 9, 12, 12, 12, 12, 6, 3, 6, 3, 2, 2, 2, 2,
};

// instructionSizes indicates the size of each instruction in bytes
char instructionSizes[256] = {
    1, 2, 0, 0, 2, 2, 2, 0, 1, 2, 1, 0, 3, 3, 3, 0,
    2, 2, 0, 0, 2, 2, 2, 0, 1, 3, 1, 0, 3, 3, 3, 0,
    3, 2, 0, 0, 2, 2, 2, 0, 1, 2, 1, 0, 3, 3, 3, 0,
    2, 2, 0, 0, 2, 2, 2, 0, 1, 3, 1, 0, 3, 3, 3, 0,
    1, 2, 0, 0, 2, 2, 2, 0, 1, 2, 1, 0, 3, 3, 3, 0,
    2, 2, 0, 0, 2, 2, 2, 0, 1, 3, 1, 0, 3, 3, 3, 0,
    1, 2, 0, 0, 2, 2, 2, 0, 1, 2, 1, 0, 3, 3, 3, 0,
    2, 2, 0, 0, 2, 2, 2, 0, 1, 3, 1, 0, 3, 3, 3, 0,
    2, 2, 0, 0, 2, 2, 2, 0, 1, 0, 1, 0, 3, 3, 3, 0,
    2, 2, 0, 0, 2, 2, 2, 0, 1, 3, 1, 0, 0, 3, 0, 0,
    2, 2, 2, 0, 2, 2, 2, 0, 1, 2, 1, 0, 3, 3, 3, 0,
    2, 2, 0, 0, 2, 2, 2, 0, 1, 3, 1, 0, 3, 3, 3, 0,
    2, 2, 0, 0, 2, 2, 2, 0, 1, 2, 1, 0, 3, 3, 3, 0,
    2, 2, 0, 0, 2, 2, 2, 0, 1, 3, 1, 0, 3, 3, 3, 0,
    2, 2, 0, 0, 2, 2, 2, 0, 1, 2, 1, 0, 3, 3, 3, 0,
    2, 2, 0, 0, 2, 2, 2, 0, 1, 3, 1, 0, 3, 3, 3, 0,
};

// instructionCycles indicates the number of cycles used by each instruction,
// not including conditional cycles
char instructionCycles[256] = {
    7, 6, 2, 8, 3, 3, 5, 5, 3, 2, 2, 2, 4, 4, 6, 6,
    2, 5, 2, 8, 4, 4, 6, 6, 2, 4, 2, 7, 4, 4, 7, 7,
    6, 6, 2, 8, 3, 3, 5, 5, 4, 2, 2, 2, 4, 4, 6, 6,
    2, 5, 2, 8, 4, 4, 6, 6, 2, 4, 2, 7, 4, 4, 7, 7,
    6, 6, 2, 8, 3, 3, 5, 5, 3, 2, 2, 2, 3, 4, 6, 6,
    2, 5, 2, 8, 4, 4, 6, 6, 2, 4, 2, 7, 4, 4, 7, 7,
    6, 6, 2, 8, 3, 3, 5, 5, 4, 2, 2, 2, 5, 4, 6, 6,
    2, 5, 2, 8, 4, 4, 6, 6, 2, 4, 2, 7, 4, 4, 7, 7,
    2, 6, 2, 6, 3, 3, 3, 3, 2, 2, 2, 2, 4, 4, 4, 4,
    2, 6, 2, 6, 4, 4, 4, 4, 2, 5, 2, 5, 5, 5, 5, 5,
    2, 6, 2, 6, 3, 3, 3, 3, 2, 2, 2, 2, 4, 4, 4, 4,
    2, 5, 2, 5, 4, 4, 4, 4, 2, 4, 2, 4, 4, 4, 4, 4,
    2, 6, 2, 8, 3, 3, 5, 5, 2, 2, 2, 2, 4, 4, 6, 6,
    2, 5, 2, 8, 4, 4, 6, 6, 2, 4, 2, 7, 4, 4, 7, 7,
    2, 6, 2, 8, 3, 3, 5, 5, 2, 2, 2, 2, 4, 4, 6, 6,
    2, 5, 2, 8, 4, 4, 6, 6, 2, 4, 2, 7, 4, 4, 7, 7,
};

// instructionPageCycles indicates the number of cycles used by each
// instruction when a page is crossed
char instructionPageCycles[256] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0,
};

// instructionNames indicates the name of each instruction
char* instructionNames[256] = {
    "BRK", "ORA", "KIL", "SLO", "NOP", "ORA", "ASL", "SLO",
    "PHP", "ORA", "ASL", "ANC", "NOP", "ORA", "ASL", "SLO",
    "BPL", "ORA", "KIL", "SLO", "NOP", "ORA", "ASL", "SLO",
    "CLC", "ORA", "NOP", "SLO", "NOP", "ORA", "ASL", "SLO",
    "JSR", "AND", "KIL", "RLA", "BIT", "AND", "ROL", "RLA",
    "PLP", "AND", "ROL", "ANC", "BIT", "AND", "ROL", "RLA",
    "BMI", "AND", "KIL", "RLA", "NOP", "AND", "ROL", "RLA",
    "SEC", "AND", "NOP", "RLA", "NOP", "AND", "ROL", "RLA",
    "RTI", "EOR", "KIL", "SRE", "NOP", "EOR", "LSR", "SRE",
    "PHA", "EOR", "LSR", "ALR", "JMP", "EOR", "LSR", "SRE",
    "BVC", "EOR", "KIL", "SRE", "NOP", "EOR", "LSR", "SRE",
    "CLI", "EOR", "NOP", "SRE", "NOP", "EOR", "LSR", "SRE",
    "RTS", "ADC", "KIL", "RRA", "NOP", "ADC", "ROR", "RRA",
    "PLA", "ADC", "ROR", "ARR", "JMP", "ADC", "ROR", "RRA",
    "BVS", "ADC", "KIL", "RRA", "NOP", "ADC", "ROR", "RRA",
    "SEI", "ADC", "NOP", "RRA", "NOP", "ADC", "ROR", "RRA",
    "NOP", "STA", "NOP", "SAX", "STY", "STA", "STX", "SAX",
    "DEY", "NOP", "TXA", "XAA", "STY", "STA", "STX", "SAX",
    "BCC", "STA", "KIL", "AHX", "STY", "STA", "STX", "SAX",
    "TYA", "STA", "TXS", "TAS", "SHY", "STA", "SHX", "AHX",
    "LDY", "LDA", "LDX", "LAX", "LDY", "LDA", "LDX", "LAX",
    "TAY", "LDA", "TAX", "LAX", "LDY", "LDA", "LDX", "LAX",
    "BCS", "LDA", "KIL", "LAX", "LDY", "LDA", "LDX", "LAX",
    "CLV", "LDA", "TSX", "LAS", "LDY", "LDA", "LDX", "LAX",
    "CPY", "CMP", "NOP", "DCP", "CPY", "CMP", "DEC", "DCP",
    "INY", "CMP", "DEX", "AXS", "CPY", "CMP", "DEC", "DCP",
    "BNE", "CMP", "KIL", "DCP", "NOP", "CMP", "DEC", "DCP",
    "CLD", "CMP", "NOP", "DCP", "NOP", "CMP", "DEC", "DCP",
    "CPX", "SBC", "NOP", "ISC", "CPX", "SBC", "INC", "ISC",
    "INX", "SBC", "NOP", "SBC", "CPX", "SBC", "INC", "ISC",
    "BEQ", "SBC", "KIL", "ISC", "NOP", "SBC", "INC", "ISC",
    "SED", "SBC", "NOP", "ISC", "NOP", "SBC", "INC", "ISC",
};

struct stepInfo {
    short address,
    short pc,
    char mode
};

struct CPU {
    //Memory           // memory interface
    struct Console* console,
    long Cycles,         // number of cycles
    short PC,         // program counter
    char SP,           // stack pointer
    char A,            // accumulator
    char X,            // x register
    char Y,            // y register
    char C,            // carry flag
    char Z,            // zero flag
    char I,            // interrupt disable flag
    char D,            // decimal mode flag
    char B,            // break command flag
    char U,            // unused flag
    char V,            // overflow flag
    char N,           // negative flag
    char interrupt,    // interrupt type to perform
    int stall,         // number of cycles to stall
    void (*table[256])(struct stepInfo* info, struct CPU* cpu);
}

//

struct CPU* initCPU(struct Console* console);
void createTable(struct CPU* cpu);
void reset(struct CPU* cpu);

void printInstruction(struct CPU* cpu);

char pagesDiffer(short a, short b);
void write(short address, char value, struct CPU* cpu);
char read(short address, struct CPU* cpu);
void addBranchCycles(struct stepInfo* info, struct CPU* cpu);
void compare(char a, char b, struct CPU* cpu);
short read16(short address, struct CPU* cpu);
short read16bug(short address, struct CPU* cpu);
void push(char value, struct CPU* cpu);
char pull(struct CPU* cpu);
void push16(short value, struct CPU* cpu);
short pull16(struct CPU* cpu);
char flags(struct CPU* cpu);
void set_flags(char flag, struct CPU* cpu);
void set_Z(char value, struct CPU* cpu);
void set_N(char value, struct CPU* cpu);
void set_ZN(char value, struct CPU* cpu);
void triggerNMI(struct CPU* cpu);
void triggerIRQ(struct CPU* cpu);

//对外驱动接口
int step(struct CPU* cpu);

//下面是指令实现函数
// NMI - Non-Maskable Interrupt
void nmi(struct CPU* cpu);
    
// IRQ - IRQ Interrupt
void irq(struct CPU* cpu);
    
// ADC - Add with Carry
void adc(struct stepInfo* info, struct CPU* cpu);
    
// AND - Logical AND
void and(struct stepInfo* info, struct CPU* cpu);

// ASL - Arithmetic Shift Left
void asl(struct stepInfo* info, struct CPU* cpu);
    
// BCC - Branch if Carry Clear
void bcc(struct stepInfo* info, struct CPU* cpu);
    
// BCS - Branch if Carry Set
void bcs(struct stepInfo* info, struct CPU* cpu);
    
// BEQ - Branch if Equal
void beq(struct stepInfo* info, struct CPU* cpu);
    
// BIT - Bit Test
void bit(struct stepInfo* info, struct CPU* cpu);
    
// BMI - Branch if Minus
void bmi(struct stepInfo* info, struct CPU* cpu);
    
// BNE - Branch if Not Equal
void bne(struct stepInfo* info, struct CPU* cpu);
    
// BPL - Branch if Positive
void bpl(struct stepInfo* info, struct CPU* cpu);
    
// BRK - Force Interrupt
void brk(struct stepInfo* info, struct CPU* cpu);
    
// BVC - Branch if Overflow Clear
void bvc(struct stepInfo* info, struct CPU* cpu);
    
// BVS - Branch if Overflow Set
void bvs(struct stepInfo* info, struct CPU* cpu);
    
// CLC - Clear Carry Flag
void clc(struct stepInfo* info, struct CPU* cpu);
    
// CLD - Clear Decimal Mode
void cld(struct stepInfo* info, struct CPU* cpu);
    
// CLI - Clear Interrupt Disable
void cli(struct stepInfo* info, struct CPU* cpu);
    
// CLV - Clear Overflow Flag
void clv(struct stepInfo* info, struct CPU* cpu);
    
// CMP - Compare
void cmp(struct stepInfo* info, struct CPU* cpu);
    
// CPX - Compare X Register
void cpx(struct stepInfo* info, struct CPU* cpu);
    
// CPY - Compare Y Register
void cpy(struct stepInfo* info, struct CPU* cpu);
    
// DEC - Decrement Memory
void dec(struct stepInfo* info, struct CPU* cpu);
    
// DEX - Decrement X Register
void dex(struct stepInfo* info, struct CPU* cpu);
    
// DEY - Decrement Y Register
void dey(struct stepInfo* info, struct CPU* cpu);
    
// EOR - Exclusive OR
void eor(struct stepInfo* info, struct CPU* cpu);
    
// INC - Increment Memory
void inc(struct stepInfo* info, struct CPU* cpu);
    
// INX - Increment X Register
void inx(struct stepInfo* info, struct CPU* cpu);
    
// INY - Increment Y Register
void iny(struct stepInfo* info, struct CPU* cpu);
    
// JMP - Jump
void jmp(struct stepInfo* info, struct CPU* cpu);
    
// JSR - Jump to Subroutine
void jsr(struct stepInfo* info, struct CPU* cpu);
    
// LDA - Load Accumulator
void lda(struct stepInfo* info, struct CPU* cpu);
    
// LDX - Load X Register
void ldx(struct stepInfo* info, struct CPU* cpu);
    
// LDY - Load Y Register
void ldy(struct stepInfo* info, struct CPU* cpu);
    
// LSR - Logical Shift Right
void lsr(struct stepInfo* info, struct CPU* cpu);
    
// NOP - No Operation
void nop(struct stepInfo* info, struct CPU* cpu);
    
// ORA - Logical Inclusive OR
void ora(struct stepInfo* info, struct CPU* cpu);
    
// PHA - Push Accumulator
void pha(struct stepInfo* info, struct CPU* cpu);
    
// PHP - Push Processor Status
void php(struct stepInfo* info, struct CPU* cpu);
    
// PLA - Pull Accumulator
void pla(struct stepInfo* info, struct CPU* cpu);
    
// PLP - Pull Processor Status
void plp(struct stepInfo* info, struct CPU* cpu);
    
// ROL - Rotate Left
void rol(struct stepInfo* info, struct CPU* cpu);
    
// ROR - Rotate Right
void ror(struct stepInfo* info, struct CPU* cpu);
    
// RTI - Return from Interrupt
void rti(struct stepInfo* info, struct CPU* cpu);
    
// RTS - Return from Subroutine
void rts(struct stepInfo* info, struct CPU* cpu);
    
// SBC - Subtract with Carry
void sbc(struct stepInfo* info, struct CPU* cpu);
    
// SEC - Set Carry Flag
void sec(struct stepInfo* info, struct CPU* cpu);
    
// SED - Set Decimal Flag
void sed(struct stepInfo* info, struct CPU* cpu);
    
// SEI - Set Interrupt Disable
void sei(struct stepInfo* info, struct CPU* cpu);
    
// STA - Store Accumulator
void sta(struct stepInfo* info, struct CPU* cpu);
    
// STX - Store X Register
void stx(struct stepInfo* info, struct CPU* cpu);
    
// STY - Store Y Register
void sty(struct stepInfo* info, struct CPU* cpu);
    
// TAX - Transfer Accumulator to X
void tax(struct stepInfo* info, struct CPU* cpu);
    
// TAY - Transfer Accumulator to Y
void tay(struct stepInfo* info, struct CPU* cpu);
    
// TSX - Transfer Stack Pointer to X
void tsx(struct stepInfo* info, struct CPU* cpu);
    
// TXA - Transfer X to Accumulator
void txa(struct stepInfo* info, struct CPU* cpu);
    
// TXS - Transfer X to Stack Pointer
void txs(struct stepInfo* info, struct CPU* cpu);
    
// TYA - Transfer Y to Accumulator
void tya(struct stepInfo* info, struct CPU* cpu);
    
// illegal opcodes below
void ahx(struct stepInfo* info, struct CPU* cpu);
void alr(struct stepInfo* info, struct CPU* cpu);
void anc(struct stepInfo* info, struct CPU* cpu);
void arr(struct stepInfo* info, struct CPU* cpu);
void axs(struct stepInfo* info, struct CPU* cpu);
void dcp(struct stepInfo* info, struct CPU* cpu);
void isc(struct stepInfo* info, struct CPU* cpu);
void kil(struct stepInfo* info, struct CPU* cpu);
void las(struct stepInfo* info, struct CPU* cpu);
void lax(struct stepInfo* info, struct CPU* cpu);
void rla(struct stepInfo* info, struct CPU* cpu);
void rra(struct stepInfo* info, struct CPU* cpu);
void sax(struct stepInfo* info, struct CPU* cpu);
void shx(struct stepInfo* info, struct CPU* cpu);
void shy(struct stepInfo* info, struct CPU* cpu);
void slo(struct stepInfo* info, struct CPU* cpu);
void sre(struct stepInfo* info, struct CPU* cpu);
void tas(struct stepInfo* info, struct CPU* cpu);
void xaa(struct stepInfo* info, struct CPU* cpu);

#endif
