#include <stdio.h>


int main(int argc, char** argv)
{
	printf("%s", "hello, nes!");
	return 0;
}
