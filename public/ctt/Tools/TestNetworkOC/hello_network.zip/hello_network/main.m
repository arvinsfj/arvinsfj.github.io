//

//gcc -framework Cocoa -o test main.m
//clang -framework Cocoa -o test main.m

#import <Cocoa/Cocoa.h>

@interface TestObj : NSObject

- (NSInteger)sum:(NSArray*)arr;

- (void)testNetwork;

@end

@implementation TestObj

- (NSInteger)sum:(NSArray*)arr
{
    NSInteger sum = 0;
    
    for (NSString* str in arr) {
        sum += [str integerValue];
    }
    
    return sum;
}

- (void)testNetwork
{
    dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:@"http://httpbin.org/get"];
    NSURLSessionTask *task =
    [session dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError* error) {
        NSLog(@"%@", [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil]);
        dispatch_semaphore_signal(semaphore);
    }];
    [task resume];
    dispatch_semaphore_wait(semaphore,DISPATCH_TIME_FOREVER);
}

@end


int main(int argc, char * argv[])
{
    NSLog(@"%@", @"hello, world!");
    
    TestObj* obj = [TestObj new];
    
    NSArray* testArr = @[@"290",@"5",@"22",@"24",@"32",@"12",@"34",@"189"];
    
    NSInteger sum = [obj sum:testArr];
    
    NSLog(@"SUM = %ld", sum);
    
    [obj testNetwork];
    
    return 0;
}
