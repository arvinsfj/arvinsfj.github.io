//
//  sdl.h
//  TestVGB
//
//  Created by vin on 2018/8/24.
//  Copyright © 2018年 vin. All rights reserved.
//

#ifndef sdl_h
#define sdl_h

#include <SDL2/SDL.h>
#include <sys/time.h>

int sdl_update(void);
void sdl_init(void);
void sdl_frame(void);
void sdl_quit(void);
unsigned int *sdl_get_framebuffer(void);
unsigned int sdl_get_buttons(void);
unsigned int sdl_get_directions(void);

#endif /* sdl_h */
