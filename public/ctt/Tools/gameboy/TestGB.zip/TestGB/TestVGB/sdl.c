//
//  sdl.c
//  TestVGB
//
//  Created by vin on 2018/8/24.
//  Copyright © 2018年 vin. All rights reserved.
//

#include "sdl.h"

static SDL_Window* window;
static SDL_Surface *screen;
static unsigned int frames;
static struct timeval tv1, tv2;

static int button_start, button_select, button_a, button_b, button_down, button_up, button_left, button_right;

// 初始化SDL2
void sdl_init(void)
{
    SDL_Init(SDL_INIT_VIDEO);
    window = SDL_CreateWindow("VGB", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_OPENGL);
    screen = SDL_GetWindowSurface(window);
    frames = 0;
}

// 刷新SDL2界面
unsigned int *sdl_get_framebuffer(void)
{
    return screen->pixels;
}

void sdl_frame(void)
{
    if (frames == 0) {
        gettimeofday(&tv1, NULL);
    }
    frames++;
    if (frames % 1000 == 0) {
        gettimeofday(&tv2, NULL);
        printf("FPS: %i\n", frames/((int)tv2.tv_sec - (int)tv1.tv_sec));
    }
    SDL_UpdateWindowSurface(window);
}

void sdl_quit()
{
    SDL_Quit();
}

// 按键交互处理
int sdl_update(void)
{
    SDL_Event e;
    
    while(SDL_PollEvent(&e))
    {
        if(e.type == SDL_QUIT)
            return 1;
        
        if(e.type == SDL_KEYDOWN)
        {
            switch(e.key.keysym.sym)
            {
                case SDLK_a:
                    button_a = 1;
                    break;
                case SDLK_s:
                    button_b = 1;
                    break;
                case SDLK_d:
                    button_select = 1;
                    break;
                case SDLK_f:
                    button_start = 1;
                    break;
                case SDLK_LEFT:
                    button_left = 1;
                    break;
                case SDLK_RIGHT:
                    button_right = 1;
                    break;
                case SDLK_DOWN:
                    button_down = 1;
                    break;
                case SDLK_UP:
                    button_up = 1;
                    break;
            }
        }
        
        if(e.type == SDL_KEYUP)
        {
            switch(e.key.keysym.sym)
            {
                case SDLK_a:
                    button_a = 0;
                    break;
                case SDLK_s:
                    button_b = 0;
                    break;
                case SDLK_d:
                    button_select = 0;
                    break;
                case SDLK_f:
                    button_start = 0;
                    break;
                case SDLK_LEFT:
                    button_left = 0;
                    break;
                case SDLK_RIGHT:
                    button_right = 0;
                    break;
                case SDLK_DOWN:
                    button_down = 0;
                    break;
                case SDLK_UP:
                    button_up = 0;
                    break;
            }
        }
        
    }
    return 0;
}

unsigned int sdl_get_buttons(void)
{
    return (button_start*8) | (button_select*4) | (button_b*2) | button_a;
}

unsigned int sdl_get_directions(void)
{
    return (button_down*8) | (button_up*4) | (button_left*2) | button_right;
}
