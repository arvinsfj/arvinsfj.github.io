#ifndef MBC_H
#define MBC_H
unsigned int MBC1_write_byte(unsigned short, unsigned char);
unsigned int MBC3_write_byte(unsigned short, unsigned char);
#endif
