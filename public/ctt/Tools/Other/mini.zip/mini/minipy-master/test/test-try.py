try:
    print("try 1")
    try:
        print("try 2")
    except:
        print("try 2 end")
except:
    print("try 1 end")