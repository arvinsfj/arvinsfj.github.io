
d = {
    "name": "test",
    "age" : 10
}

for k in d:
    print(k, d[k])