
import sys

assert len(sys.argv) == 1