#include <netdb.h>
#include <unistd.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tinycthread.h"

#define QUEUE_SIZE 1048576
#define RECV_SIZE 4096

//
static int sd = 0;
static char *queue = 0;
static int qsize = 0;

static thrd_t recv_thread;
static mtx_t mutex;

// 发送任意长度的字节数据
int sendall(int sd, char* data, int length)
{
	int count = 0, n = 0;
	while (count < length) {
		n = send(sd, data + count, length, 0);
		if (n == -1) return -1;
		count += n;
		length -= n;
	}
	return 0;
}

// 发送任意长度的字符串数据
void sendstr(char* data)
{
	if (sendall(sd, data, strlen(data)) == -1) {
		perror("sendstr");
		exit(1);
	}
}

// 自定义网络协议，测试
void send_version(int version) 
{
    char buffer[1024];
    snprintf(buffer, 1024, "V,%d\n", version);
    sendstr(buffer);
}

// ......

// 管道读数据：从多线程共享内存中获取数据（涉及内存区域的线程互斥）
char* recvqueue()
{
	char* result = 0;
	mtx_lock(&mutex);
	//互斥区域
	char* p = queue + qsize - 1;
	while (p >= queue && *p != '\n') p--; // 在queue中从后向前扫描字符'\n'
	if (p >= queue) {
		int length = p - queue + 1; // 字符串长度
		result = malloc(length + 1); // 多加1个字符存储字符串结束符'\0'
		memcpy(result, queue, length);
		result[length] = '\0';
		int remain = qsize - length;
		memmove(queue, p + 1, remain);
		qsize -= length;
	}
	mtx_unlock(&mutex);
	return result;
}

// 管道写数据：socket读数据线程向多线程共享内存中写数据（涉及内存区域的线程互斥）
int sendqueue(void* argv)
{
	char* data = malloc(RECV_SIZE);
	int length = 0;
	while (1) {
		if ((length = recv(sd, data, RECV_SIZE - 1, 0)) > 0) {
			data[length] = '\0';
			while (1) {
				int done = 0;
				mtx_lock(&mutex);
				//互斥区域
				if (qsize + length < QUEUE_SIZE) {
					memcpy(queue + qsize, data, length + 1);
					qsize += length;
					done = 1;
				}
				mtx_unlock(&mutex);
				if (done) {
					break;
				}
				sleep(0);
			}
		}
	}
	free(data);
	return 0;
}

// socket接受数据子线程客户端
void recvnet()
{
	queue = malloc(QUEUE_SIZE); // 分配线程共享区域内存
	qsize = 0;
	mtx_init(&mutex, mtx_plain); // 初始化互斥变量

	// 创建socket接受数据子线程
	if (thrd_create(&recv_thread, sendqueue, 0) != thrd_success) {
		perror("recvnet");
		exit(1);
	}
}

// socket创建和连接客户端
void connectnet(char* hostname, int port)
{
	struct hostent* host;
	struct sockaddr_in address;
	if ((host = gethostbyname(hostname)) == 0) {
		perror("gethostbyname");
		exit(1);
	}
	memset(&address, 0, sizeof(address));
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = ((struct in_addr *)(host->h_addr_list[0]))->s_addr;
	address.sin_port = htons(port);
	if ((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("socket");
		exit(1);
	}
	if (connect(sd, (struct sockaddr *)&address, sizeof(address)) == -1) {
		perror("connect");
        exit(1);
	}
}

// 客户端启动
void client_start(char* hostname, int port)
{
	connectnet(hostname, port);
	recvnet();
}

// 客户端关闭
void client_close()
{
	close(sd);
	qsize = 0;
	free(queue);
}

int main(int argc, char** argv)
{
	if (argc != 3) {
		return 0;
	}
	client_start(argv[1], atoi(argv[2]));
	// 操作区域 repl
	char cmd[128] = {0}, *str = 0;
	int done = 1, length = 0;
	while (done) {
		str = gets(cmd);
		if (str && !strcmp("quit", cmd)){
			done = 0;
		} else {
			strncat(str, "\r\n\r\n", 4);
			printf("%c", '\n');
			sendstr(str);
			sleep(3);
			printf("%s\n", recvqueue());
		}
	} 
	client_close();
	return 0;
}
