#include "Config.h"
#include "Emulator.h"
#include "GameBoy.h"

#ifdef WIN32
#include <Windows.h>
#include "SDL.h"
#include "SDL_opengl.h"
#else
#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>
#endif

static const int windowWidth = 160;
static const int windowHeight = 144 ;

///////////////////////////////////////////////////////////////////////////////////////

static int total = 0 ;
static int timer = 0 ;
static int current = 0 ;
static int counter = 0 ;
static bool first = true ;

static SDL_Window *window;
static SDL_Renderer *renderer;
static SDL_Texture *texture;
static SDL_Rect rect;

static void CheckFPS( )
{
	if (first)
	{
		first = false ;
		timer = SDL_GetTicks() ;
	}

	counter++ ;
	current = SDL_GetTicks() ;
	if ((timer + 1000) < current)
	{
		timer = current ;
		total = counter ;
		counter = 0 ;

		//OutputDebugStr(outputMessage);
	}
}

///////////////////////////////////////////////////////////////////////////////////////

static void DoRender( )
{
	GameBoy* gb = GameBoy::GetSingleton() ;
	gb->RenderGame( ) ;
}


///////////////////////////////////////////////////////////////////////////////////////

GameBoy* GameBoy::m_Instance = 0 ;

GameBoy* GameBoy::CreateInstance( )
{
	if (0 == m_Instance)
	{
		m_Instance = new GameBoy( ) ;
		m_Instance->Initialize( ) ;
	}
	return m_Instance ;
}

//////////////////////////////////////////////////////////////////////////////////////////

GameBoy* GameBoy::GetSingleton( )
{
	return m_Instance ;
}

//////////////////////////////////////////////////////////////////////////////////////////

GameBoy::GameBoy(void) :
	m_Emulator(NULL)
{
	m_Emulator = new Emulator( ) ;
	m_Emulator->LoadRom("ROMS/SuperMarioLand212.gb") ;
	m_Emulator->InitGame( DoRender ) ;
}

//////////////////////////////////////////////////////////////////////////////////////////

bool GameBoy::Initialize( )
{
	return CreateSDLWindow( ) ;
}

//////////////////////////////////////////////////////////////////////////////////////////
void GameBoy::StartEmulation( )
{
	bool quit = false ;
	SDL_Event event;

	float fps = 59.73 ;
	float interval = 1000 ;
	interval /= fps ;

	unsigned int time2 = SDL_GetTicks( ) ;

	while (!quit)
	{
		while( SDL_PollEvent( &event ) )
		{
			HandleInput( event ) ;

			if( event.type == SDL_QUIT )
			{
				quit = true;
			}
		}

		unsigned int current = SDL_GetTicks( ) ;

		if( (time2 + interval) < current )
		{
			CheckFPS( ) ;
			m_Emulator->Update( ) ;
			time2 = current ;
		}

	}
	SDL_Quit( ) ;
}

//////////////////////////////////////////////////////////////////////////////////////////

GameBoy::~GameBoy(void)
{
	delete m_Emulator ;
}

//////////////////////////////////////////////////////////////////////////////////////////

void GameBoy::RenderGame( )
{
	//EmulationLoop() ;
    void *p; int pitch;
    SDL_LockTexture(texture, &rect, &p, &pitch);
    SDL_memcpy(p, m_Emulator->m_ScreenData, windowHeight*windowWidth*3);
    SDL_UnlockTexture(texture);
    SDL_RenderClear(renderer);
    SDL_RenderCopy(renderer, texture, &rect, &rect);
    SDL_RenderPresent(renderer);
}

//////////////////////////////////////////////////////////////////////////////////////////

void GameBoy::SetKeyPressed(int key)
{
	m_Emulator->KeyPressed(key) ;
}

//////////////////////////////////////////////////////////////////////////////////////////

void GameBoy::SetKeyReleased(int key)
{
	m_Emulator->KeyReleased(key) ;
}

//////////////////////////////////////////////////////////////////////////////////////////

bool GameBoy::CreateSDLWindow( )
{
    int error = 0;
    if ((error = SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO)) != 0) {
        fprintf(stderr, "Couldn't init SDL: %s\n", SDL_GetError());
        return -1;
    }
    atexit(SDL_Quit);
    
    rect.x=rect.y=0;
    rect.h=windowHeight;
    rect.w=windowWidth;
    
    window = SDL_CreateWindow("GB",
                              SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              windowWidth, windowHeight,
                              SDL_WINDOW_SHOWN);
    if (!window) {
        fprintf(stderr, "Couldn't create SDL window: %s\n", SDL_GetError());
        return -1;
    }
    
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        fprintf(stderr, "Couldn't create SDL renderer: %s\n", SDL_GetError());
        return -1;
    }
    if (SDL_RenderSetLogicalSize(renderer, windowWidth, windowHeight) != 0) {
        fprintf(stderr, "Couldn't set SDL renderer logical resolution: %s\n", SDL_GetError());
        return -1;
    }
    texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGB24, SDL_TEXTUREACCESS_STREAMING, windowWidth, windowHeight);
    if (!texture) {
        fprintf(stderr, "Couldn't create SDL texture: %s\n", SDL_GetError());
        return -1;
    }
	return true ;
}

//////////////////////////////////////////////////////////////////////////////////////////

void GameBoy::HandleInput(SDL_Event& event)
{
	if( event.type == SDL_KEYDOWN )
	{
		int key = -1 ;
		switch( event.key.keysym.sym )
		{
			case SDLK_a : key = 4 ; break ;
			case SDLK_s : key = 5 ; break ;
			case SDLK_RETURN : key = 7 ; break ;
			case SDLK_SPACE : key = 6; break ;
			case SDLK_RIGHT : key = 0 ; break ;
			case SDLK_LEFT : key = 1 ; break ;
			case SDLK_UP : key = 2 ; break ;
			case SDLK_DOWN : key = 3 ; break ;
		}
		if (key != -1)
		{
			SetKeyPressed(key) ;
		}
	}
	//If a key was released
	else if( event.type == SDL_KEYUP )
	{
		int key = -1 ;
		switch( event.key.keysym.sym )
		{
			case SDLK_a : key = 4 ; break ;
			case SDLK_s : key = 5 ; break ;
			case SDLK_RETURN : key = 7 ; break ;
			case SDLK_SPACE : key = 6; break ;
			case SDLK_RIGHT : key = 0 ; break ;
			case SDLK_LEFT : key = 1 ; break ;
			case SDLK_UP : key = 2 ; break ;
			case SDLK_DOWN : key = 3 ; break ;
		}
		if (key != -1)
		{
			SetKeyReleased(key) ;
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////////////
