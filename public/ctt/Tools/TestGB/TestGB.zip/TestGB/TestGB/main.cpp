//
//  main.cpp
//  TestGB
//
//  Created by arvin on 2017/8/31.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#include <SDL2/SDL.h>

#include "Emulator.h"

static Emulator* m_Emulator = NULL;

static const int windowWidth = 160;
static const int windowHeight = 144 ;

static SDL_Window *window;
static SDL_Renderer *renderer;
static SDL_Texture *texture;
static SDL_Rect rect;

bool CreateSDLWindow( )
{
    int error = 0;
    if ((error = SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO)) != 0) {
        fprintf(stderr, "Couldn't init SDL: %s\n", SDL_GetError());
        return -1;
    }
    atexit(SDL_Quit);
    
    rect.x=rect.y=0;
    rect.h=windowHeight;
    rect.w=windowWidth;
    
    window = SDL_CreateWindow("GB",
                              SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              windowWidth, windowHeight,
                              SDL_WINDOW_SHOWN);
    if (!window) {
        fprintf(stderr, "Couldn't create SDL window: %s\n", SDL_GetError());
        return -1;
    }
    
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        fprintf(stderr, "Couldn't create SDL renderer: %s\n", SDL_GetError());
        return -1;
    }
    if (SDL_RenderSetLogicalSize(renderer, windowWidth, windowHeight) != 0) {
        fprintf(stderr, "Couldn't set SDL renderer logical resolution: %s\n", SDL_GetError());
        return -1;
    }
    texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGB24, SDL_TEXTUREACCESS_STREAMING, windowWidth, windowHeight);
    if (!texture) {
        fprintf(stderr, "Couldn't create SDL texture: %s\n", SDL_GetError());
        return -1;
    }
    return true ;
}

void HandleInput(SDL_Event event)
{
    if( event.type == SDL_KEYDOWN )
    {
        int key = -1 ;
        switch( event.key.keysym.sym )
        {
            case SDLK_a : key = 4 ; break ;
            case SDLK_s : key = 5 ; break ;
            case SDLK_RETURN : key = 7 ; break ;
            case SDLK_SPACE : key = 6; break ;
            case SDLK_RIGHT : key = 0 ; break ;
            case SDLK_LEFT : key = 1 ; break ;
            case SDLK_UP : key = 2 ; break ;
            case SDLK_DOWN : key = 3 ; break ;
        }
        if (key != -1)
        {
            m_Emulator->KeyPressed(key) ;
        }
    }
    //If a key was released
    else if( event.type == SDL_KEYUP )
    {
        int key = -1 ;
        switch( event.key.keysym.sym )
        {
            case SDLK_a : key = 4 ; break ;
            case SDLK_s : key = 5 ; break ;
            case SDLK_RETURN : key = 7 ; break ;
            case SDLK_SPACE : key = 6; break ;
            case SDLK_RIGHT : key = 0 ; break ;
            case SDLK_LEFT : key = 1 ; break ;
            case SDLK_UP : key = 2 ; break ;
            case SDLK_DOWN : key = 3 ; break ;
        }
        if (key != -1)
        {
            m_Emulator->KeyReleased(key) ;
        }
    }
}

void RenderGame()
{
    void *p; int pitch;
    SDL_LockTexture(texture, &rect, &p, &pitch);
    SDL_memcpy(p, m_Emulator->m_ScreenData, windowHeight*windowWidth*3);
    SDL_UnlockTexture(texture);
    SDL_RenderClear(renderer);
    SDL_RenderCopy(renderer, texture, &rect, &rect);
    SDL_RenderPresent(renderer);
}

void StartEmulation()
{
    bool quit = false ;
    SDL_Event event;
    
    float fps = 59.73 ;
    float interval = 1000/fps ;
    
    unsigned int time2 = SDL_GetTicks( ) ;
    
    while (!quit)
    {
        while( SDL_PollEvent( &event ) )
        {
            HandleInput( event ) ;
            
            if( event.type == SDL_QUIT )
            {
                quit = true;
            }
        }
        
        unsigned int current = SDL_GetTicks( ) ;
        
        if( (time2 + interval) < current )
        {
            m_Emulator->Update() ;
            time2 = current ;
        }
    }
    
    SDL_Quit( ) ;
}

int main(int argc, const char * argv[])
{
    if (argc < 2) {
        return 0;
    }
    CreateSDLWindow();
    m_Emulator = new Emulator() ;
    m_Emulator->LoadRom(argv[1]) ;
    m_Emulator->InitGame(RenderGame) ;
    StartEmulation();
    return 0;
}
