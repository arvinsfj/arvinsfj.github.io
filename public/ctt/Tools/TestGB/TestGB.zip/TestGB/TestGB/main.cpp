//
//  main.cpp
//  TestGB
//
//  Created by arvin on 2017/8/31.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#include <iostream>

#include "Config.h"
#include "GameBoy.h"
#include "GameSettings.h"

int main(int argc, const char * argv[])
{
    LogMessage* log = LogMessage::CreateInstance() ;
    GameSettings* settings = GameSettings::CreateInstance();
    
    GameBoy* gb = GameBoy::CreateInstance( ) ;
    
    gb->StartEmulation( ) ;
    
    delete gb ;
    delete settings ;
    delete log ;
    
    return 0;
}
