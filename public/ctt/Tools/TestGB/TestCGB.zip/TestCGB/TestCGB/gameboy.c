//
//  gameboy.c
//  TestCGB
//
//  Created by arvin on 2017/8/31.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#include "gameboy.h"

#define FLAG_MASK_Z 128
#define FLAG_MASK_N 64
#define FLAG_MASK_H 32
#define FLAG_MASK_C 16
#define FLAG_Z 7
#define FLAG_N 6
#define FLAG_H 5
#define FLAG_C 4

#define VERTICAL_BLANK_SCAN_LINE 0x90//144
#define VERTICAL_BLANK_SCAN_LINE_MAX 0x99//153
#define RETRACE_START 456

//GB的数据定义
BYTE m_JoypadState = 0;
bool m_GameLoaded = false;
BYTE m_Rom[0x10000] ;//CPU内部RAM
BYTE m_GameBank[0x200000] ;//卡带ROM，in cartridge
BYTE* m_RamBank[17] ;//MBC2 not use

WORD m_ProgramCounter ;//init 0x100
Register m_StackPointer;//init 0xFFFE
Register m_RegisterAF ;
Register m_RegisterBC ;
Register m_RegisterDE ;
Register m_RegisterHL ;
bool m_EnableRamBank = false;
int m_CyclesThisUpdate = 0;

int m_CurrentRomBank ;
int m_CurrentRamBank = 0;
bool m_UsingMemoryModel16_8 = true;
bool m_EnableInterupts = false;
bool m_PendingInteruptDisabled = false;
bool m_PendingInteruptEnabled = false;

int m_RetraceLY = RETRACE_START;

bool m_UsingMBC1 = false;
bool m_UsingMBC2 ;
bool m_Halted = false;
int m_TimerVariable = 0;
int m_DividerVariable = 0;
int m_CurrentClockSpeed = 1024;

//屏幕图像数据
BYTE m_ScreenData[144][160][3] ;//160*144
RenderFunc m_RenderFunc;

//////////////////////////////////////////////////
//字节按位操作工具方法
bool TestBit(WORD address, int position)
{
    return ((address>>position)&0x1)?(true):(false);
}

BYTE BitSet(BYTE data, int position)
{
    BYTE mask = 1 << position ;
    data |= mask ;
    return data ;
}

BYTE BitReset(BYTE data, int position)
{
    BYTE mask = 1 << position ;
    data &= ~mask ;
    return data ;
}

BYTE BitGetVal(BYTE data, int position)
{
    BYTE mask = 1 << position ;
    return ( data & mask ) ? 1 : 0 ;
}

//GB的按键实现
void RequestInterupt(int id);
void KeyPressed(int key)
{
    bool previouslyUnset = false ;
    
    // if setting from 1 to 0 we may have to request an interupt
    if (!TestBit(m_JoypadState, key)) {
        previouslyUnset = true ;
    }
    
    // remember if a keypressed its bit is 0 not 1
    m_JoypadState = BitReset(m_JoypadState, key) ;
    
    // button pressed
    bool button = true ;
    // is this a standard button or a directional button?
    if (key > 3)
        button = true ;
    else // directional button pressed
        button = false ;
    
    BYTE keyReq = m_Rom[0xFF00] ;//joypad register
    bool requestInterupt = false ;
    
    // only request interupt if the button just pressed is
    // the style of button the game is interested in
    if (button && !TestBit(keyReq,5)) requestInterupt = true ;
    
    // same as above but for directional button
    else if (!button && !TestBit(keyReq,4)) requestInterupt = true ;
    
    // request interupt
    if (requestInterupt && !previouslyUnset){
        RequestInterupt(4) ;//joypad interupts
    }
}

void KeyReleased(int key)
{
    m_JoypadState = BitSet(m_JoypadState,key) ;
}

BYTE GetJoypadState()
{
    BYTE res = m_Rom[0xFF00] ;
    // flip all the bits
    res ^= 0xFF ;
    
    // are we interested in the standard buttons?
    if (!TestBit(res, 4))
    {
        BYTE topJoypad = m_JoypadState >> 4 ;
        topJoypad |= 0xF0 ; // turn the top 4 bits on
        res &= topJoypad ; // show what buttons are pressed
    }
    else if (!TestBit(res,5))//directional buttons
    {
        BYTE bottomJoypad = m_JoypadState & 0xF ;
        bottomJoypad |= 0xF0 ;
        res &= bottomJoypad ;
    }
    return res ;
}

//GB的内存读写
BYTE ReadMemory(WORD memory)
{
    // reading from rom bank
    if (memory >= 0x4000 && memory <= 0x7FFF)
    {
        unsigned int newAddress = memory ;
        newAddress += ((m_CurrentRomBank-1)*0x4000) ;
        return m_GameBank[newAddress] ;
    }
    
    // reading from RAM Bank
    else if (memory >= 0xA000 && memory <= 0xBFFF)
    {
        WORD newAddress = memory - 0xA000 ;
        return m_RamBank[m_CurrentRamBank][newAddress] ;
    }
    // trying to read joypad state
    else if (memory == 0xFF00)
        return GetJoypadState( );
        
    return m_Rom[memory] ;
}

WORD ReadWord( )
{
    WORD res = ReadMemory(m_ProgramCounter+1) ;
    res <<= 8 ;
    res |= ReadMemory(m_ProgramCounter) ;
    return res ;
}

void WriteByte(WORD address, BYTE data)
{
    // writing to memory address 0x0 to 0x1FFF this disables writing to the ram bank. 0 disables, 0xA enables
    if (address <= 0x1FFF)
    {
        if (m_UsingMBC1)
        {
            if ((data & 0xF) == 0xA)
                m_EnableRamBank = true ;
            else if (data == 0x0)
                m_EnableRamBank = false ;
        }
        else if (m_UsingMBC2)
        {
            //bit 0 of upper byte must be 0
            if (!TestBit(address,8))
            {
                if ((data & 0xF) == 0xA)
                    m_EnableRamBank = true ;
                else if (data == 0x0)
                    m_EnableRamBank = false ;
            }
        }
        
    }
    
    // if writing to a memory address between 2000 and 3FFF then we need to change rom bank
    else if ( (address >= 0x2000) && (address <= 0x3FFF) )
    {
        if (m_UsingMBC1)
        {
            if (data == 0x00){
                data++;
            }
            data &= 31;
            
            // Turn off the lower 5-bits.
            m_CurrentRomBank &= 224;
            
            // Combine the written data with the register.
            m_CurrentRomBank |= data;
            
            char buffer[256] ;
            sprintf(buffer, "Chaning Rom Bank to %d", m_CurrentRomBank) ;
            //printf("%s\n", buffer);
            
        }
        else if (m_UsingMBC2)
        {
            data &= 0xF ;
            m_CurrentRomBank = data ;
        }
    }
    
    // writing to address 0x4000 to 0x5FFF switches ram banks (if enabled of course)
    else if ( (address >= 0x4000) && (address <= 0x5FFF))
    {
        if (m_UsingMBC1)
        {
            // are we using memory model 16/8
            if (m_UsingMemoryModel16_8)
            {
                // in this mode we can only use Ram Bank 0
                m_CurrentRamBank = 0 ;
                
                data &= 3;
                data <<= 5;
                
                if (!(m_CurrentRomBank & 31)) {
                    data++;
                }
                
                // Turn off bits 5 and 6, and 7 if it somehow got turned on.
                m_CurrentRomBank &= 31;
                
                // Combine the written data with the register.
                m_CurrentRomBank |= data;
                
                char buffer[256] ;
                sprintf(buffer, "Chaning Rom Bank to %d", m_CurrentRomBank) ;
                //printf("%s\n", buffer);
                
            }
            else
            {
                m_CurrentRamBank = data & 0x3 ;
                char buffer[256] ;
                sprintf(buffer, "=====Chaning Ram Bank to %d=====", m_CurrentRamBank) ;
                //printf("%s\n", buffer);
                
            }
        }
    }
    
    // writing to address 0x6000 to 0x7FFF switches memory model
    else if ( (address >= 0x6000) && (address <= 0x7FFF))
    {
        if (m_UsingMBC1)
        {
            // we're only interested in the first bit
            if (data&1) {
                m_CurrentRamBank = 0 ;
                m_UsingMemoryModel16_8 = false ;
            } else {
                m_UsingMemoryModel16_8 = true ;
            }
        }
    }
    
    // from now on we're writing to RAM
    
    else if ((address >= 0xA000) && (address <= 0xBFFF))
    {
        if (m_EnableRamBank)
        {
            if (m_UsingMBC1)
            {
                WORD newAddress = address - 0xA000 ;
                m_RamBank[m_CurrentRamBank][newAddress] = data;
            }
        }
        else if (m_UsingMBC2 && (address < 0xA200))
        {
            WORD newAddress = address - 0xA000 ;
            m_RamBank[m_CurrentRamBank][newAddress] = data;
        }
        
    }
    
    
    // we're right to internal RAM, remember that it needs to echo it
    else if ( (address >= 0xC000) && (address <= 0xDFFF) )
    {
        m_Rom[address] = data ;
    }
    
    // echo memory. Writes here and into the internal ram. Same as above
    else if ( (address >= 0xE000) && (address <= 0xFDFF) )
    {
        m_Rom[address] = data ;
        m_Rom[address - 0x2000] = data ; // echo data into ram address
    }
    
    // This area is restricted.
    else if ((address >= 0xFEA0) && (address <= 0xFEFF))
    {
    }
    
    // reset the divider register
    else if (address == 0xFF04)
    {
        m_Rom[0xFF04] = 0 ;
        m_DividerVariable = 0 ;
    }
    
    // not sure if this is correct
    else if (address == 0xFF07)
    {
        m_Rom[address] = data ;
        
        int timerVal = data & 0x03 ;
        
        int clockSpeed = 0 ;
        
        switch(timerVal)
        {
            case 0: clockSpeed = 1024 ; break ;
            case 1: clockSpeed = 16; break ;
            case 2: clockSpeed = 64 ;break ;
            case 3: clockSpeed = 256 ;break ; // 256
            default: assert(false); break ; // weird timer val
        }
        
        if (clockSpeed != m_CurrentClockSpeed)
        {
            m_TimerVariable = 0 ;
            m_CurrentClockSpeed = clockSpeed ;
        }
    }
    
    
    // FF44 shows which horizontal scanline is currently being draw. Writing here resets it
    else if (address == 0xFF44)
    {
        m_Rom[0xFF44] = 0 ;
    }
    
    else if (address == 0xFF45)
    {
        m_Rom[address] = data ;
    }
    // DMA transfer
    else if (address == 0xFF46)
    {
        WORD newAddress = (data << 8) ;
        for (int i = 0; i < 0xA0; i++)
        {
            m_Rom[0xFE00 + i] = ReadMemory(newAddress + i);
        }
    }
    
    // This area is restricted.
    else if ((address >= 0xFF4C) && (address <= 0xFF7F))
    {
    }
    
    
    // I guess we're ok to write to memory... gulp
    else
    {
        m_Rom[address] = data ;
    }
}

//////////////////////////////////////////////////////////////////
//中断请求
void RequestInterupt(int bit)
{
    BYTE requestFlag = ReadMemory(0xFF0F) ;//IF
    requestFlag = BitSet(requestFlag,bit) ;//设置某位位 1
    WriteByte(0xFF0F, requestFlag) ;
}

void IssueVerticalBlank( )
{
    RequestInterupt(0) ;//v-blank interrupts
}

//////////////////////////////////////////////////////////////////
//入栈和出栈
void PushWordOntoStack(WORD word)
{
    BYTE hi = word >> 8 ;
    BYTE lo = word & 0xFF;
    m_StackPointer.reg-- ;
    WriteByte(m_StackPointer.reg, hi) ;
    m_StackPointer.reg-- ;
    WriteByte(m_StackPointer.reg, lo) ;
}

//////////////////////////////////////////////////////////////////

WORD PopWordOffStack( )
{
    WORD word = ReadMemory(m_StackPointer.reg+1) << 8 ;
    word |= ReadMemory(m_StackPointer.reg) ;
    m_StackPointer.reg+=2 ;
    
    return word ;
}

//下面是CPU指令集的实现
//////////////////////////////////////////////////////////////////////////////////

// put 1 byte immediate data into reg
void CPU_8BIT_LOAD( BYTE* reg )
{
    m_CyclesThisUpdate += 8 ;
    BYTE n = ReadMemory(m_ProgramCounter) ;
    m_ProgramCounter++ ;
    *reg = n ;
}

//////////////////////////////////////////////////////////////////////////////////

// put 2 byte immediate data into reg
void CPU_16BIT_LOAD(  WORD* reg )
{
    m_CyclesThisUpdate += 12 ;
    WORD n = ReadWord() ;
    m_ProgramCounter+=2 ;
    *reg = n ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_REG_LOAD(BYTE* reg, BYTE load, int cycles)
{
    m_CyclesThisUpdate += cycles ;
    *reg = load ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_REG_LOAD_ROM(BYTE* reg, WORD address)
{
    m_CyclesThisUpdate+=8 ;
    *reg = ReadMemory(address) ;
}

//////////////////////////////////////////////////////////////////////////////////

// apparently no flags affected
void CPU_16BIT_DEC( WORD* word, int cycles)
{
    m_CyclesThisUpdate+=cycles ;
    (*word)--;
}

//////////////////////////////////////////////////////////////////////////////////

// apparently no flags affected
void CPU_16BIT_INC( WORD* word, int cycles)
{
    m_CyclesThisUpdate+=cycles;
    (*word)++;
}

//////////////////////////////////////////////////////////////////////////

// add to reg. Can be immediate data, and can also add the carry flag to the result
void CPU_8BIT_ADD(BYTE* reg, BYTE toAdd, int cycles, bool useImmediate, bool addCarry)
{
    m_CyclesThisUpdate+=cycles ;
    BYTE before = *reg ;
    BYTE adding = 0 ;
    
    // are we adding immediate data or the second param?
    if (useImmediate)
    {
        BYTE n = ReadMemory(m_ProgramCounter) ;
        m_ProgramCounter++ ;
        adding = n ;
    }
    else
    {
        adding = toAdd ;
    }
    
    // are we also adding the carry flag?
    if (addCarry)
    {
        if (TestBit(m_RegisterAF.lo, FLAG_C))
            adding++ ;
    }
    
    (*reg)+=adding ;
    
    // set the flags
    m_RegisterAF.lo = 0 ;
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    WORD htest = (before & 0xF) ;
    htest += (adding & 0xF) ;
    
    if (htest > 0xF)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_H) ;
    
    if ((before + adding) > 0xFF)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    //	_asm int 3; // IM UNSURE IF the flags for FLAG C and FLAG H are correct... Need to check
}

//////////////////////////////////////////////////////////////////////////////////

// subtracts away from reg, can also subtract the carry flag too
void CPU_8BIT_SUB(BYTE* reg, BYTE subtracting, int cycles, bool useImmediate, bool subCarry)
{
    m_CyclesThisUpdate += cycles ;
    BYTE before = *reg ;
    BYTE toSubtract = 0 ;
    
    if (useImmediate)
    {
        BYTE n = ReadMemory(m_ProgramCounter) ;
        m_ProgramCounter++ ;
        toSubtract = n ;
    }
    else
    {
        toSubtract = subtracting ;
    }
    
    if (subCarry)
    {
        if (TestBit(m_RegisterAF.lo, FLAG_C))
            toSubtract++ ;
    }
    
    (*reg) -= toSubtract ;
    
    m_RegisterAF.lo = 0 ;
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_N) ;
    
    // set if no borrow
    if (before < toSubtract)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    SIGNED_WORD htest = (before & 0xF) ;
    htest -= (toSubtract & 0xF) ;
    
    if (htest < 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_H) ;
    
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_8BIT_AND(BYTE* reg, BYTE toAnd, int cycles, bool useImmediate)
{
    m_CyclesThisUpdate+=cycles ;
    BYTE myand = 0 ;
    
    if (useImmediate)
    {
        BYTE n = ReadMemory(m_ProgramCounter) ;
        m_ProgramCounter++ ;
        myand = n ;
    }
    else
    {
        myand = toAnd ;
    }
    
    (*reg) &= myand ;
    
    m_RegisterAF.lo = 0 ;
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_H) ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_8BIT_OR(BYTE* reg, BYTE toOr, int cycles, bool useImmediate)
{
    m_CyclesThisUpdate+=cycles ;
    BYTE myor = 0 ;
    
    if (useImmediate)
    {
        BYTE n = ReadMemory(m_ProgramCounter) ;
        m_ProgramCounter++ ;
        myor = n ;
    }
    else
    {
        myor = toOr ;
    }
    
    (*reg)|= myor ;
    
    m_RegisterAF.lo = 0 ;
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_8BIT_XOR(BYTE* reg, BYTE toXOr, int cycles, bool useImmediate)
{
    m_CyclesThisUpdate+=cycles ;
    BYTE myxor = 0 ;
    
    if (useImmediate)
    {
        BYTE n = ReadMemory(m_ProgramCounter) ;
        m_ProgramCounter++ ;
        myxor = n ;
    }
    else
    {
        myxor = toXOr ;
    }
    
    (*reg) ^= myxor ;
    
    m_RegisterAF.lo = 0 ;
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
}

//////////////////////////////////////////////////////////////////////////////////

// this does not affect any registers, hence why im not passing a reference

void CPU_8BIT_COMPARE(BYTE reg, BYTE subtracting, int cycles, bool useImmediate)
{
    m_CyclesThisUpdate += cycles ;
    BYTE before = reg ;
    BYTE toSubtract = 0 ;
    
    if (useImmediate)
    {
        BYTE n = ReadMemory(m_ProgramCounter) ;
        m_ProgramCounter++ ;
        toSubtract = n ;
    }
    else
    {
        toSubtract = subtracting ;
    }
    
    reg -= toSubtract ;
    
    m_RegisterAF.lo = 0 ;
    
    if (reg == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_N) ;
    
    // set if no borrow
    if (before < toSubtract)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    
    SIGNED_WORD htest = before & 0xF ;
    htest -= (toSubtract & 0xF) ;
    
    if (htest < 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_H) ;
    
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_8BIT_INC(BYTE* reg, int cycles)
{
    // WHEN EDITING THIS FUNCTION DONT FORGET TO MAKE THE SAME CHANGES TO CPU_8BIT_MEMORY_INC
    
    m_CyclesThisUpdate+= cycles ;
    
    BYTE before = *reg ;
    
    (*reg)++ ;
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    else
        m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_Z) ;
    
    m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_N) ;
    
    if ((before & 0xF) == 0xF)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_H) ;
    else
        m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_H) ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_8BIT_MEMORY_INC(WORD address, int cycles)
{
    // WHEN EDITING THIS FUNCTION DONT FORGET TO MAKE THE SAME CHANGES TO CPU_8BIT_INC
    
    m_CyclesThisUpdate+= cycles ;
    
    BYTE before = ReadMemory( address ) ;
    WriteByte(address, (before+1)) ;
    BYTE now =  before+1 ;
    
    if (now == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    else
        m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_Z) ;
    
    m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_N) ;
    
    if ((before & 0xF) == 0xF)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_H) ;
    else
        m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_H) ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_8BIT_DEC(BYTE* reg, int cycles)
{
    // WHEN EDITING THIS FUNCTION DONT FORGET TO MAKE THE SAME CHANGES TO CPU_8BIT_MEMORY_DEC
    
    m_CyclesThisUpdate+=cycles ;
    BYTE before = *reg ;
    
    (*reg)-- ;
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    else
        m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_Z) ;
    
    m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_N) ;
    
    if ((before & 0x0F) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_H) ;
    else
        m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_H) ;
    
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_8BIT_MEMORY_DEC(WORD address, int cycles)
{
    // WHEN EDITING THIS FUNCTION DONT FORGET TO MAKE THE SAME CHANGES TO CPU_8BIT_DEC
    
    m_CyclesThisUpdate+=cycles ;
    BYTE before = ReadMemory(address) ;
    WriteByte(address, (before-1)) ;
    BYTE now = before-1 ;
    
    if (now == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    else
        m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_Z) ;
    
    m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_N) ;
    
    if ((before & 0x0F) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_H) ;
    else
        m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_H) ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_16BIT_ADD( WORD* reg, WORD toAdd, int cycles)
{
    m_CyclesThisUpdate += cycles ;
    WORD before = *reg ;
    
    (*reg) += toAdd ;
    
    m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_N) ;
    
    if ((before + toAdd) > 0xFFFF)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    else
        m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_C) ;
    
    
    if (( (before & 0xFF00) & 0xF) + ((toAdd >> 8) & 0xF))
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_H) ;
    else
        m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_H) ;
    
    //	_asm int 3; // not sure about flag h
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_JUMP(bool useCondition, int flag, bool condition)
{
    m_CyclesThisUpdate += 12 ;
    
    WORD nn = ReadWord( ) ;
    m_ProgramCounter += 2 ;
    
    if (!useCondition)
    {
        m_ProgramCounter = nn ;
        return ;
    }
    
    if (TestBit(m_RegisterAF.lo, flag) == condition)
    {
        m_ProgramCounter = nn ;
    }
    
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_JUMP_IMMEDIATE(bool useCondition, int flag, bool condition)
{
    m_CyclesThisUpdate += 8 ;
    
    SIGNED_BYTE n = (SIGNED_BYTE)ReadMemory(m_ProgramCounter) ;
    
    if (!useCondition)
    {
        m_ProgramCounter += n;
    }
    else if (TestBit(m_RegisterAF.lo, flag) == condition)
    {
        m_ProgramCounter += n ;
    }
    
    m_ProgramCounter++ ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_CALL(bool useCondition, int flag, bool condition)
{
    m_CyclesThisUpdate+=12 ;
    WORD nn = ReadWord( ) ;
    m_ProgramCounter += 2;
    
    if (!useCondition)
    {
        PushWordOntoStack(m_ProgramCounter) ;
        m_ProgramCounter = nn ;
        return ;
    }
    
    if (TestBit(m_RegisterAF.lo, flag)==condition)
    {
        PushWordOntoStack(m_ProgramCounter) ;
        m_ProgramCounter = nn ;
    }
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_RETURN(bool useCondition, int flag, bool condition)
{
    m_CyclesThisUpdate += 8 ;
    if (!useCondition)
    {
        m_ProgramCounter = PopWordOffStack( ) ;
        return ;
    }
    
    if (TestBit(m_RegisterAF.lo, flag) == condition)
    {
        m_ProgramCounter = PopWordOffStack( ) ;
    }
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_SWAP_NIBBLES(BYTE* reg)
{
    m_CyclesThisUpdate += 8 ;
    
    m_RegisterAF.lo = 0 ;
    
    *reg = ((((*reg) & 0xF0) >> 4) | (((*reg) & 0x0F) << 4));
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    // WHEN EDITING THIS FUNCTION ALSO EDIT CPU_SWAP_NIB_MEM
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_SWAP_NIB_MEM(WORD address)
{
    m_CyclesThisUpdate += 16 ;
    
    m_RegisterAF.lo = 0 ;
    
    BYTE mem = ReadMemory(address) ;
    mem = (((mem & 0xF0) >> 4) | ((mem & 0x0F) << 4));
    
    WriteByte(address,mem) ;
    
    if (mem == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    
    // WHEN EDITING THIS FUNCTION ALSO EDIT CPU_SWAP_NIBBLES
    
    
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_RESTARTS(BYTE n)
{
    PushWordOntoStack(m_ProgramCounter) ;
    m_CyclesThisUpdate += 32 ;
    m_ProgramCounter = n ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_SHIFT_LEFT_CARRY(BYTE* reg)
{
    // WHEN EDITING THIS FUNCTION ALSO EDIT CPU_SHIFT_LEFT_CARRY_MEMORY
    m_CyclesThisUpdate += 8 ;
    m_RegisterAF.lo = 0 ;
    if (TestBit(*reg,7))
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    (*reg) <<= 1 ;
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_SHIFT_LEFT_CARRY_MEMORY(WORD address)
{
    // WHEN EDITING THIS FUNCTION ALSO EDIT CPU_SHIFT_LEFT_CARRY
    m_CyclesThisUpdate += 16 ;
    BYTE before = ReadMemory(address) ;
    
    m_RegisterAF.lo = 0 ;
    if (TestBit(before,7))
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    before <<= 1 ;
    if (before == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    WriteByte(address, before) ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_RESET_BIT(BYTE* reg, int bit)
{
    // WHEN EDITING THIS ALSO EDIT CPU_RESET_BIT_MEMORY
    *reg = BitReset(*reg, bit) ;
    m_CyclesThisUpdate += 8 ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_RESET_BIT_MEMORY(WORD address, int bit)
{
    // WHEN EDITING THIS ALSO EDIT CPU_RESET_BIT
    BYTE mem = ReadMemory(address) ;
    mem = BitReset(mem, bit) ;
    WriteByte(address, mem) ;
    m_CyclesThisUpdate += 16 ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_TEST_BIT(BYTE reg, int bit, int cycles)
{
    if (TestBit(reg, bit))
        m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_Z) ;
    else
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_N) ;
    m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_H) ;
    
    m_CyclesThisUpdate += cycles ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_SET_BIT(BYTE* reg, int bit)
{
    // WHEN EDITING THIS ALSO EDIT CPU_SET_BIT_MEMORY
    *reg = BitSet(*reg, bit) ;
    m_CyclesThisUpdate += 8 ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_SET_BIT_MEMORY(WORD address, int bit)
{
    // WHEN EDITING THIS ALSO EDIT CPU_SET_BIT
    BYTE mem = ReadMemory(address) ;
    mem = BitSet(mem, bit) ;
    WriteByte(address, mem) ;
    m_CyclesThisUpdate += 16 ;
}

//////////////////////////////////////////////////////////////////////////////////

// STOLEN
void CPU_DAA( )
{
    m_CyclesThisUpdate += 4 ;
    
    if(TestBit(m_RegisterAF.lo, FLAG_N))
    {
        if((m_RegisterAF.hi &0x0F ) >0x09 || (m_RegisterAF.lo &0x20) )
        {
            m_RegisterAF.hi -=0x06; //Half borrow: (0-1) = (0xF-0x6) = 9
            if((m_RegisterAF.hi&0xF0)==0xF0) m_RegisterAF.lo|=0x10; else m_RegisterAF.lo&=~0x10;
        }
        
        if((m_RegisterAF.hi&0xF0)>0x90 || m_RegisterAF.lo&0x10) m_RegisterAF.hi-=0x60;
    }
    else
    {
        if((m_RegisterAF.hi&0x0F)>9 || m_RegisterAF.lo&0x20)
        {
            m_RegisterAF.hi+=0x06; //Half carry: (9+1) = (0xA+0x6) = 10
            if((m_RegisterAF.hi&0xF0)==0) m_RegisterAF.lo|=0x10; else m_RegisterAF.lo&=~0x10;
        }
        
        if((m_RegisterAF.hi&0xF0)>0x90 || m_RegisterAF.lo&0x10) m_RegisterAF.hi+=0x60;
    }
    
    if(m_RegisterAF.hi==0) m_RegisterAF.lo|=0x80; else m_RegisterAF.lo&=~0x80;
}

//////////////////////////////////////////////////////////////////////////////////

// rotate right through carry
void CPU_RR(BYTE* reg)
{
    // WHEN EDITING THIS ALSO EDIT CPU_RR_MEMORY
    m_CyclesThisUpdate += 8 ;
    
    bool isCarrySet = TestBit(m_RegisterAF.lo, FLAG_C) ;
    bool isLSBSet = TestBit(*reg, 0) ;
    
    m_RegisterAF.lo = 0 ;
    
    (*reg) >>= 1 ;
    
    if (isLSBSet)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    if (isCarrySet)
        *reg = BitSet(*reg, 7) ;
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
}

//////////////////////////////////////////////////////////////////////////////////

// rotate right through carry
void CPU_RR_MEMORY(WORD address)
{
    // WHEN EDITING THIS ALSO EDIT CPU_RR
    
    m_CyclesThisUpdate += 16 ;
    
    BYTE reg = ReadMemory(address) ;
    
    bool isCarrySet = TestBit(m_RegisterAF.lo, FLAG_C) ;
    bool isLSBSet = TestBit(reg, 0) ;
    
    m_RegisterAF.lo = 0 ;
    
    reg >>= 1 ;
    
    if (isLSBSet)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    if (isCarrySet)
        reg = BitSet(reg, 7) ;
    
    if (reg == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    WriteByte(address, reg) ;
}

//////////////////////////////////////////////////////////////////////////////////

// rotate left
void CPU_RLC(BYTE* reg)
{
    //WHEN EDITING THIS FUNCTION ALSO EDIT CPU_RLC_MEMORY
    
    m_CyclesThisUpdate += 8 ;
    
    bool isMSBSet = TestBit(*reg, 7) ;
    
    m_RegisterAF.lo = 0 ;
    
    (*reg) <<= 1;
    
    if (isMSBSet)
    {
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
        *reg = BitSet(*reg,0) ;
    }
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
}

//////////////////////////////////////////////////////////////////////////////////

// rotate left
void CPU_RLC_MEMORY(WORD address)
{
    //WHEN EDITING THIS FUNCTION ALSO EDIT CPU_RLC
    
    m_CyclesThisUpdate += 16 ;
    
    BYTE reg = ReadMemory(address) ;
    
    bool isMSBSet = TestBit(reg, 7) ;
    
    m_RegisterAF.lo = 0 ;
    
    reg <<= 1;
    
    if (isMSBSet)
    {
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
        reg = BitSet(reg,0) ;
    }
    
    if (reg == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    WriteByte(address, reg) ;
    
}

//////////////////////////////////////////////////////////////////////////////////

// rotate right
void CPU_RRC(BYTE* reg)
{
    // WHEN EDITING THIS FUNCTION ALSO EDIT CPU_RRC_MEMORY
    
    m_CyclesThisUpdate += 8 ;
    
    bool isLSBSet = TestBit(*reg, 0) ;
    
    m_RegisterAF.lo = 0 ;
    
    (*reg) >>= 1;
    
    if (isLSBSet)
    {
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
        *reg = BitSet(*reg,7) ;
    }
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
}

//////////////////////////////////////////////////////////////////////////////////

// rotate right
void CPU_RRC_MEMORY(WORD address)
{
    // WHEN EDITING THIS FUNCTION ALSO EDIT CPU_RRC
    
    m_CyclesThisUpdate += 16 ;
    
    BYTE reg = ReadMemory(address) ;
    
    bool isLSBSet = TestBit(reg, 0) ;
    
    m_RegisterAF.lo = 0 ;
    
    reg >>= 1;
    
    if (isLSBSet)
    {
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
        reg = BitSet(reg,7) ;
    }
    
    if (reg == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    WriteByte(address, reg) ;
}

//////////////////////////////////////////////////////////////////////////////////

// shift left arithmetically (basically bit 0 gets set to 0) (bit 7 goes into carry)
void CPU_SLA(BYTE* reg)
{
    // WHEN EDITING THIS ALSO EDIT CPU_SLA_MEMORY
    
    m_CyclesThisUpdate += 8 ;
    
    bool isMSBSet = TestBit(*reg, 7);
    
    (*reg) <<= 1;
    
    m_RegisterAF.lo = 0 ;
    
    if (isMSBSet)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
}

//////////////////////////////////////////////////////////////////////////////////

void CPU_SLA_MEMORY(WORD address)
{
    // WHEN EDITING THIS ALSO EDIT CPU_SLA_MEMORY
    
    m_CyclesThisUpdate += 16 ;
    
    BYTE reg = ReadMemory(address) ;
    
    bool isMSBSet = TestBit(reg, 7);
    
    reg <<= 1;
    
    m_RegisterAF.lo = 0 ;
    
    if (isMSBSet)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    if (reg == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    WriteByte(address, reg) ;
}
//////////////////////////////////////////////////////////////////////////////////

// shift right. LSB into carry. bit 7 doesn't change
void CPU_SRA(BYTE* reg)
{
    // WHEN EDITING THIS FUNCTION ALSO EDIT CPU_SRA_MEMORY
    
    m_CyclesThisUpdate += 8 ;
    
    bool isLSBSet = TestBit(*reg,0) ;
    bool isMSBSet = TestBit(*reg,7) ;
    
    m_RegisterAF.lo = 0 ;
    
    (*reg) >>= 1;
    
    if (isMSBSet)
        *reg = BitSet(*reg,7) ;
    if (isLSBSet)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
}

//////////////////////////////////////////////////////////////////////////////////

// shift right. LSB into carry. bit 7 doesn't change
void CPU_SRA_MEMORY(WORD address)
{
    // WHEN EDITING THIS FUNCTION ALSO EDIT CPU_SRA
    
    m_CyclesThisUpdate += 16 ;
    
    BYTE reg = ReadMemory(address) ;
    
    bool isLSBSet = TestBit(reg,0) ;
    bool isMSBSet = TestBit(reg,7) ;
    
    m_RegisterAF.lo = 0 ;
    
    reg >>= 1;
    
    if (isMSBSet)
        reg = BitSet(reg,7) ;
    if (isLSBSet)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    if (reg == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    WriteByte(address, reg) ;
}

//////////////////////////////////////////////////////////////////////////////////

// shift right. bit 0 into carry
void CPU_SRL(BYTE* reg)
{
    //WHEN EDITING THIS FUNCTION ALSO EDIT CPU_SRL_MEMORY
    
    m_CyclesThisUpdate += 8 ;
    
    bool isLSBSet = TestBit(*reg,0) ;
    
    m_RegisterAF.lo = 0 ;
    
    (*reg) >>= 1;
    
    if (isLSBSet)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
}

//////////////////////////////////////////////////////////////////////////////////

// shift right. bit 0 into carry
void CPU_SRL_MEMORY(WORD address)
{
    //WHEN EDITING THIS FUNCTION ALSO EDIT CPU_SRL
    
    m_CyclesThisUpdate += 8 ;
    
    BYTE reg = ReadMemory(address) ;
    
    bool isLSBSet = TestBit(reg,0) ;
    
    m_RegisterAF.lo = 0 ;
    
    reg >>= 1;
    
    if (isLSBSet)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    if (reg == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    WriteByte(address, reg) ;
    
}


// rotate left through carry flag
void CPU_RL(BYTE* reg)
{
    // WHEN EDITING THIS FUNCTION ALSO EDIT CPU_RL_MEMORY
    m_CyclesThisUpdate += 8 ;
    
    bool isCarrySet = TestBit(m_RegisterAF.lo, FLAG_C) ;
    bool isMSBSet = TestBit(*reg, 7) ;
    
    m_RegisterAF.lo = 0 ;
    
    (*reg) <<= 1 ;
    
    if (isMSBSet)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    if (isCarrySet)
        *reg = BitSet(*reg, 0) ;
    
    if ((*reg) == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
}

//////////////////////////////////////////////////////////////////////////////////

// rotate left through carry flag
void CPU_RL_MEMORY(WORD address)
{
    // WHEN EDITING THIS FUNCTION ALSO EDIT CPU_RL
    
    m_CyclesThisUpdate += 16 ;
    BYTE reg = ReadMemory(address) ;
    
    bool isCarrySet = TestBit(m_RegisterAF.lo, FLAG_C) ;
    bool isMSBSet = TestBit(reg, 7) ;
    
    m_RegisterAF.lo = 0 ;
    
    reg <<= 1 ;
    
    if (isMSBSet)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
    
    if (isCarrySet)
        reg = BitSet(reg, 0) ;
    
    if (reg == 0)
        m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_Z) ;
    
    WriteByte(address, reg) ;
}

//指令集的实现结束
/////////////////////////////////////////////////////////////////

//CPU的实现
void ExecuteExtendedOpcode()
{
    BYTE opcode = m_Rom[m_ProgramCounter] ;
    
    if ((m_ProgramCounter >= 0x4000 && m_ProgramCounter <= 0x7FFF) || (m_ProgramCounter >= 0xA000 && m_ProgramCounter <= 0xBFFF)){
        opcode = ReadMemory(m_ProgramCounter) ;
    }
    
    m_ProgramCounter++ ;
    
    switch(opcode)
    {
            // rotate left through carry
        case 0x0 : CPU_RLC(&(m_RegisterBC.hi)) ; break ;
        case 0x1 : CPU_RLC(&(m_RegisterBC.lo)) ; break ;
        case 0x2 : CPU_RLC(&(m_RegisterDE.hi)) ; break ;
        case 0x3 : CPU_RLC(&(m_RegisterDE.lo)) ; break ;
        case 0x4 : CPU_RLC(&(m_RegisterHL.hi)) ; break ;
        case 0x5 : CPU_RLC(&(m_RegisterHL.lo)) ; break ;
        case 0x6 : CPU_RLC_MEMORY(m_RegisterHL.reg) ; break ;
        case 0x7 : CPU_RLC(&(m_RegisterAF.hi)) ; break ;
            
            // rotate right through carry
        case 0x8 : CPU_RRC(&(m_RegisterBC.hi)) ; break ;
        case 0x9 : CPU_RRC(&(m_RegisterBC.lo)) ; break ;
        case 0xA : CPU_RRC(&(m_RegisterDE.hi)) ; break ;
        case 0xB : CPU_RRC(&(m_RegisterDE.lo)) ; break ;
        case 0xC : CPU_RRC(&(m_RegisterHL.hi)) ; break ;
        case 0xD : CPU_RRC(&(m_RegisterHL.lo)) ; break ;
        case 0xE : CPU_RRC_MEMORY(m_RegisterHL.reg) ; break ;
        case 0xF : CPU_RRC(&(m_RegisterAF.hi)) ; break ;
            
            // rotate left
        case 0x10: CPU_RL(&(m_RegisterBC.hi)); break;
        case 0x11: CPU_RL(&(m_RegisterBC.lo)); break;
        case 0x12: CPU_RL(&(m_RegisterDE.hi)); break;
        case 0x13: CPU_RL(&(m_RegisterDE.lo)); break;
        case 0x14: CPU_RL(&(m_RegisterHL.hi)); break;
        case 0x15: CPU_RL(&(m_RegisterHL.lo)); break;
        case 0x16: CPU_RL_MEMORY(m_RegisterHL.reg); break;
        case 0x17: CPU_RL(&(m_RegisterAF.hi)); break;
            
            // rotate right
        case 0x18: CPU_RR(&(m_RegisterBC.hi)); break;
        case 0x19: CPU_RR(&(m_RegisterBC.lo)); break;
        case 0x1A: CPU_RR(&(m_RegisterDE.hi)); break;
        case 0x1B: CPU_RR(&(m_RegisterDE.lo)); break;
        case 0x1C: CPU_RR(&(m_RegisterHL.hi)); break;
        case 0x1D: CPU_RR(&(m_RegisterHL.lo)); break;
        case 0x1E: CPU_RR_MEMORY(m_RegisterHL.reg); break;
        case 0x1F: CPU_RR(&(m_RegisterAF.hi)); break;
            
        case 0x20 : CPU_SLA( &(m_RegisterBC.hi) ) ;break ;
        case 0x21 : CPU_SLA( &(m_RegisterBC.lo) ) ;break ;
        case 0x22 : CPU_SLA( &(m_RegisterDE.hi) ) ;break ;
        case 0x23 : CPU_SLA( &(m_RegisterDE.lo) ) ;break ;
        case 0x24 : CPU_SLA( &(m_RegisterHL.hi) ) ;break ;
        case 0x25 : CPU_SLA( &(m_RegisterHL.lo) ) ;break ;
        case 0x26 : CPU_SLA_MEMORY( m_RegisterHL.reg ) ;break ;
        case 0x27 : CPU_SLA( &(m_RegisterAF.hi) ) ;break ;
            
        case 0x28 : CPU_SRA( &(m_RegisterBC.hi) ) ; break ;
        case 0x29 : CPU_SRA( &(m_RegisterBC.lo) ) ; break ;
        case 0x2A : CPU_SRA( &(m_RegisterDE.hi) ) ; break ;
        case 0x2B : CPU_SRA( &(m_RegisterDE.lo) ) ; break ;
        case 0x2C : CPU_SRA( &(m_RegisterHL.hi) ) ; break ;
        case 0x2D : CPU_SRA( &(m_RegisterHL.lo) ) ; break ;
        case 0x2E : CPU_SRA_MEMORY( m_RegisterHL.reg ) ; break ;
        case 0x2F : CPU_SRA( &(m_RegisterAF.hi) ) ; break ;
            
        case 0x38 : CPU_SRL( &(m_RegisterBC.hi) ) ; break ;
        case 0x39 : CPU_SRL( &(m_RegisterBC.lo) ) ; break ;
        case 0x3A : CPU_SRL( &(m_RegisterDE.hi) ) ; break ;
        case 0x3B : CPU_SRL( &(m_RegisterDE.lo) ) ; break ;
        case 0x3C : CPU_SRL( &(m_RegisterHL.hi) ) ; break ;
        case 0x3D : CPU_SRL( &(m_RegisterHL.lo) ) ; break ;
        case 0x3E : CPU_SRL_MEMORY( m_RegisterHL.reg ) ; break ;
        case 0x3F : CPU_SRL( &(m_RegisterAF.hi) ) ; break ;
            
            // swap nibbles
        case 0x37 : CPU_SWAP_NIBBLES( &(m_RegisterAF.hi) ) ;break ;
        case 0x30 : CPU_SWAP_NIBBLES( &(m_RegisterBC.hi) ) ;break ;
        case 0x31 : CPU_SWAP_NIBBLES( &(m_RegisterBC.lo) ) ;break ;
        case 0x32 : CPU_SWAP_NIBBLES( &(m_RegisterDE.hi) ) ;break ;
        case 0x33 : CPU_SWAP_NIBBLES( &(m_RegisterDE.lo) ) ;break ;
        case 0x34 : CPU_SWAP_NIBBLES( &(m_RegisterHL.hi) ) ;break ;
        case 0x35 : CPU_SWAP_NIBBLES( &(m_RegisterHL.lo) ) ;break ;
        case 0x36 : CPU_SWAP_NIB_MEM( m_RegisterHL.reg ) ;break ;
            
            // test bit
        case 0x40 : CPU_TEST_BIT( m_RegisterBC.hi, 0 , 8 ) ; break ;
        case 0x41 : CPU_TEST_BIT( m_RegisterBC.lo, 0 , 8 ) ; break ;
        case 0x42 : CPU_TEST_BIT( m_RegisterDE.hi, 0 , 8 ) ; break ;
        case 0x43 : CPU_TEST_BIT( m_RegisterDE.lo, 0 , 8 ) ; break ;
        case 0x44 : CPU_TEST_BIT( m_RegisterHL.hi, 0 , 8 ) ; break ;
        case 0x45 : CPU_TEST_BIT( m_RegisterHL.lo, 0 , 8 ) ; break ;
        case 0x46 : CPU_TEST_BIT(ReadMemory(m_RegisterHL.reg), 0 , 16 ) ; break ;
        case 0x47 : CPU_TEST_BIT( m_RegisterAF.hi, 0 , 8 ) ; break ;
        case 0x48 : CPU_TEST_BIT( m_RegisterBC.hi, 1 , 8 ) ; break ;
        case 0x49 : CPU_TEST_BIT( m_RegisterBC.lo, 1 , 8 ) ; break ;
        case 0x4A : CPU_TEST_BIT( m_RegisterDE.hi, 1 , 8 ) ; break ;
        case 0x4B : CPU_TEST_BIT( m_RegisterDE.lo, 1 , 8 ) ; break ;
        case 0x4C : CPU_TEST_BIT( m_RegisterHL.hi, 1 , 8 ) ; break ;
        case 0x4D : CPU_TEST_BIT( m_RegisterHL.lo, 1 , 8 ) ; break ;
        case 0x4E : CPU_TEST_BIT(ReadMemory(m_RegisterHL.reg), 1 , 16 ) ; break ;
        case 0x4F : CPU_TEST_BIT( m_RegisterAF.hi, 1 , 8 ) ; break ;
        case 0x50 : CPU_TEST_BIT( m_RegisterBC.hi, 2 , 8 ) ; break ;
        case 0x51 : CPU_TEST_BIT( m_RegisterBC.lo, 2 , 8 ) ; break ;
        case 0x52 : CPU_TEST_BIT( m_RegisterDE.hi, 2 , 8 ) ; break ;
        case 0x53 : CPU_TEST_BIT( m_RegisterDE.lo, 2 , 8 ) ; break ;
        case 0x54 : CPU_TEST_BIT( m_RegisterHL.hi, 2 , 8 ) ; break ;
        case 0x55 : CPU_TEST_BIT( m_RegisterHL.lo, 2 , 8 ) ; break ;
        case 0x56 : CPU_TEST_BIT(ReadMemory(m_RegisterHL.reg), 2 , 16 ) ; break ;
        case 0x57 : CPU_TEST_BIT( m_RegisterAF.hi, 2 , 8 ) ; break ;
        case 0x58 : CPU_TEST_BIT( m_RegisterBC.hi, 3 , 8 ) ; break ;
        case 0x59 : CPU_TEST_BIT( m_RegisterBC.lo, 3 , 8 ) ; break ;
        case 0x5A : CPU_TEST_BIT( m_RegisterDE.hi, 3 , 8 ) ; break ;
        case 0x5B : CPU_TEST_BIT( m_RegisterDE.lo, 3 , 8 ) ; break ;
        case 0x5C : CPU_TEST_BIT( m_RegisterHL.hi, 3 , 8 ) ; break ;
        case 0x5D : CPU_TEST_BIT( m_RegisterHL.lo, 3 , 8 ) ; break ;
        case 0x5E : CPU_TEST_BIT(ReadMemory(m_RegisterHL.reg), 3 , 16 ) ; break ;
        case 0x5F : CPU_TEST_BIT( m_RegisterAF.hi, 3 , 8 ) ; break ;
        case 0x60 : CPU_TEST_BIT( m_RegisterBC.hi, 4 , 8 ) ; break ;
        case 0x61 : CPU_TEST_BIT( m_RegisterBC.lo, 4 , 8 ) ; break ;
        case 0x62 : CPU_TEST_BIT( m_RegisterDE.hi, 4 , 8 ) ; break ;
        case 0x63 : CPU_TEST_BIT( m_RegisterDE.lo, 4 , 8 ) ; break ;
        case 0x64 : CPU_TEST_BIT( m_RegisterHL.hi, 4 , 8 ) ; break ;
        case 0x65 : CPU_TEST_BIT( m_RegisterHL.lo, 4 , 8 ) ; break ;
        case 0x66 : CPU_TEST_BIT(ReadMemory(m_RegisterHL.reg), 4 , 16 ) ; break ;
        case 0x67 : CPU_TEST_BIT( m_RegisterAF.hi, 4 , 8 ) ; break ;
        case 0x68 : CPU_TEST_BIT( m_RegisterBC.hi, 5 , 8 ) ; break ;
        case 0x69 : CPU_TEST_BIT( m_RegisterBC.lo, 5 , 8 ) ; break ;
        case 0x6A : CPU_TEST_BIT( m_RegisterDE.hi, 5 , 8 ) ; break ;
        case 0x6B : CPU_TEST_BIT( m_RegisterDE.lo, 5 , 8 ) ; break ;
        case 0x6C : CPU_TEST_BIT( m_RegisterHL.hi, 5 , 8 ) ; break ;
        case 0x6D : CPU_TEST_BIT( m_RegisterHL.lo, 5 , 8 ) ; break ;
        case 0x6E : CPU_TEST_BIT(ReadMemory(m_RegisterHL.reg), 5 , 16 ) ; break ;
        case 0x6F : CPU_TEST_BIT( m_RegisterAF.hi, 5 , 8 ) ; break ;
        case 0x70 : CPU_TEST_BIT( m_RegisterBC.hi, 6 , 8 ) ; break ;
        case 0x71 : CPU_TEST_BIT( m_RegisterBC.lo, 6 , 8 ) ; break ;
        case 0x72 : CPU_TEST_BIT( m_RegisterDE.hi, 6 , 8 ) ; break ;
        case 0x73 : CPU_TEST_BIT( m_RegisterDE.lo, 6 , 8 ) ; break ;
        case 0x74 : CPU_TEST_BIT( m_RegisterHL.hi, 6 , 8 ) ; break ;
        case 0x75 : CPU_TEST_BIT( m_RegisterHL.lo, 6 , 8 ) ; break ;
        case 0x76 : CPU_TEST_BIT(ReadMemory(m_RegisterHL.reg), 6 , 16 ) ; break ;
        case 0x77 : CPU_TEST_BIT( m_RegisterAF.hi, 6 , 8 ) ; break ;
        case 0x78 : CPU_TEST_BIT( m_RegisterBC.hi, 7 , 8 ) ; break ;
        case 0x79 : CPU_TEST_BIT( m_RegisterBC.lo, 7 , 8 ) ; break ;
        case 0x7A : CPU_TEST_BIT( m_RegisterDE.hi, 7 , 8 ) ; break ;
        case 0x7B : CPU_TEST_BIT( m_RegisterDE.lo, 7 , 8 ) ; break ;
        case 0x7C : CPU_TEST_BIT( m_RegisterHL.hi, 7 , 8 ) ; break ;
        case 0x7D : CPU_TEST_BIT( m_RegisterHL.lo, 7 , 8 ) ; break ;
        case 0x7E : CPU_TEST_BIT(ReadMemory(m_RegisterHL.reg), 7 , 16 ) ; break ;
        case 0x7F : CPU_TEST_BIT( m_RegisterAF.hi, 7 , 8 ) ; break ;
            
            // reset bit
        case 0x80 : CPU_RESET_BIT( &(m_RegisterBC.hi), 0 ) ; break ;
        case 0x81 : CPU_RESET_BIT( &(m_RegisterBC.lo), 0 ) ; break ;
        case 0x82 : CPU_RESET_BIT( &(m_RegisterDE.hi), 0 ) ; break ;
        case 0x83 : CPU_RESET_BIT( &(m_RegisterDE.lo), 0 ) ; break ;
        case 0x84 : CPU_RESET_BIT( &(m_RegisterHL.hi), 0 ) ; break ;
        case 0x85 : CPU_RESET_BIT( &(m_RegisterHL.lo), 0 ) ; break ;
        case 0x86 : CPU_RESET_BIT_MEMORY( m_RegisterHL.reg, 0 ) ; break ;
        case 0x87 : CPU_RESET_BIT( &(m_RegisterAF.hi), 0 ) ; break ;
        case 0x88 : CPU_RESET_BIT( &(m_RegisterBC.hi), 1  ) ; break ;
        case 0x89 : CPU_RESET_BIT( &(m_RegisterBC.lo), 1 ) ; break ;
        case 0x8A : CPU_RESET_BIT( &(m_RegisterDE.hi), 1 ) ; break ;
        case 0x8B : CPU_RESET_BIT( &(m_RegisterDE.lo), 1 ) ; break ;
        case 0x8C : CPU_RESET_BIT( &(m_RegisterHL.hi), 1 ) ; break ;
        case 0x8D : CPU_RESET_BIT( &(m_RegisterHL.lo), 1 ) ; break ;
        case 0x8E : CPU_RESET_BIT_MEMORY( m_RegisterHL.reg, 1 ) ; break ;
        case 0x8F : CPU_RESET_BIT( &(m_RegisterAF.hi), 1  ) ; break ;
        case 0x90 : CPU_RESET_BIT( &(m_RegisterBC.hi), 2  ) ; break ;
        case 0x91 : CPU_RESET_BIT( &(m_RegisterBC.lo), 2  ) ; break ;
        case 0x92 : CPU_RESET_BIT( &(m_RegisterDE.hi), 2  ) ; break ;
        case 0x93 : CPU_RESET_BIT( &(m_RegisterDE.lo), 2  ) ; break ;
        case 0x94 : CPU_RESET_BIT( &(m_RegisterHL.hi), 2  ) ; break ;
        case 0x95 : CPU_RESET_BIT( &(m_RegisterHL.lo), 2  ) ; break ;
        case 0x96 : CPU_RESET_BIT_MEMORY( m_RegisterHL.reg, 2 ) ; break ;
        case 0x97 : CPU_RESET_BIT( &(m_RegisterAF.hi), 2  ) ; break ;
        case 0x98 : CPU_RESET_BIT( &(m_RegisterBC.hi), 3  ) ; break ;
        case 0x99 : CPU_RESET_BIT( &(m_RegisterBC.lo), 3  ) ; break ;
        case 0x9A : CPU_RESET_BIT( &(m_RegisterDE.hi), 3  ) ; break ;
        case 0x9B : CPU_RESET_BIT( &(m_RegisterDE.lo), 3  ) ; break ;
        case 0x9C : CPU_RESET_BIT( &(m_RegisterHL.hi), 3  ) ; break ;
        case 0x9D : CPU_RESET_BIT( &(m_RegisterHL.lo), 3  ) ; break ;
        case 0x9E : CPU_RESET_BIT_MEMORY( m_RegisterHL.reg, 3  ) ; break ;
        case 0x9F : CPU_RESET_BIT( &(m_RegisterAF.hi), 3  ) ; break ;
        case 0xA0 : CPU_RESET_BIT( &(m_RegisterBC.hi), 4  ) ; break ;
        case 0xA1 : CPU_RESET_BIT( &(m_RegisterBC.lo), 4  ) ; break ;
        case 0xA2 : CPU_RESET_BIT( &(m_RegisterDE.hi), 4  ) ; break ;
        case 0xA3 : CPU_RESET_BIT( &(m_RegisterDE.lo), 4  ) ; break ;
        case 0xA4 : CPU_RESET_BIT( &(m_RegisterHL.hi), 4  ) ; break ;
        case 0xA5 : CPU_RESET_BIT( &(m_RegisterHL.lo), 4  ) ; break ;
        case 0xA6 : CPU_RESET_BIT_MEMORY( m_RegisterHL.reg, 4) ; break ;
        case 0xA7 : CPU_RESET_BIT( &(m_RegisterAF.hi), 4 ) ; break ;
        case 0xA8 : CPU_RESET_BIT( &(m_RegisterBC.hi), 5 ) ; break ;
        case 0xA9 : CPU_RESET_BIT( &(m_RegisterBC.lo), 5 ) ; break ;
        case 0xAA : CPU_RESET_BIT( &(m_RegisterDE.hi), 5 ) ; break ;
        case 0xAB : CPU_RESET_BIT( &(m_RegisterDE.lo), 5 ) ; break ;
        case 0xAC : CPU_RESET_BIT( &(m_RegisterHL.hi), 5 ) ; break ;
        case 0xAD : CPU_RESET_BIT( &(m_RegisterHL.lo), 5 ) ; break ;
        case 0xAE : CPU_RESET_BIT_MEMORY( m_RegisterHL.reg, 5 ) ; break ;
        case 0xAF : CPU_RESET_BIT( &(m_RegisterAF.hi), 5  ) ; break ;
        case 0xB0 : CPU_RESET_BIT( &(m_RegisterBC.hi), 6  ) ; break ;
        case 0xB1 : CPU_RESET_BIT( &(m_RegisterBC.lo), 6  ) ; break ;
        case 0xB2 : CPU_RESET_BIT( &(m_RegisterDE.hi), 6  ) ; break ;
        case 0xB3 : CPU_RESET_BIT( &(m_RegisterDE.lo), 6  ) ; break ;
        case 0xB4 : CPU_RESET_BIT( &(m_RegisterHL.hi), 6  ) ; break ;
        case 0xB5 : CPU_RESET_BIT( &(m_RegisterHL.lo), 6  ) ; break ;
        case 0xB6 : CPU_RESET_BIT_MEMORY( m_RegisterHL.reg, 6 ) ; break ;
        case 0xB7 : CPU_RESET_BIT( &(m_RegisterAF.hi), 6  ) ; break ;
        case 0xB8 : CPU_RESET_BIT( &(m_RegisterBC.hi), 7  ) ; break ;
        case 0xB9 : CPU_RESET_BIT( &(m_RegisterBC.lo), 7  ) ; break ;
        case 0xBA : CPU_RESET_BIT( &(m_RegisterDE.hi), 7  ) ; break ;
        case 0xBB : CPU_RESET_BIT( &(m_RegisterDE.lo), 7  ) ; break ;
        case 0xBC : CPU_RESET_BIT( &(m_RegisterHL.hi), 7  ) ; break ;
        case 0xBD : CPU_RESET_BIT( &(m_RegisterHL.lo), 7  ) ; break ;
        case 0xBE : CPU_RESET_BIT_MEMORY( m_RegisterHL.reg, 7 ) ; break ;
        case 0xBF : CPU_RESET_BIT( &(m_RegisterAF.hi), 7 ) ; break ;
            
            
            // set bit
        case 0xC0 : CPU_SET_BIT( &(m_RegisterBC.hi), 0 ) ; break ;
        case 0xC1 : CPU_SET_BIT( &(m_RegisterBC.lo), 0 ) ; break ;
        case 0xC2 : CPU_SET_BIT( &(m_RegisterDE.hi), 0 ) ; break ;
        case 0xC3 : CPU_SET_BIT( &(m_RegisterDE.lo), 0 ) ; break ;
        case 0xC4 : CPU_SET_BIT( &(m_RegisterHL.hi), 0 ) ; break ;
        case 0xC5 : CPU_SET_BIT( &(m_RegisterHL.lo), 0 ) ; break ;
        case 0xC6 : CPU_SET_BIT_MEMORY( m_RegisterHL.reg, 0 ) ; break ;
        case 0xC7 : CPU_SET_BIT( &(m_RegisterAF.hi), 0 ) ; break ;
        case 0xC8 : CPU_SET_BIT( &(m_RegisterBC.hi), 1  ) ; break ;
        case 0xC9 : CPU_SET_BIT( &(m_RegisterBC.lo), 1 ) ; break ;
        case 0xCA : CPU_SET_BIT( &(m_RegisterDE.hi), 1 ) ; break ;
        case 0xCB : CPU_SET_BIT( &(m_RegisterDE.lo), 1 ) ; break ;
        case 0xCC : CPU_SET_BIT( &(m_RegisterHL.hi), 1 ) ; break ;
        case 0xCD : CPU_SET_BIT( &(m_RegisterHL.lo), 1 ) ; break ;
        case 0xCE : CPU_SET_BIT_MEMORY( m_RegisterHL.reg, 1 ) ; break ;
        case 0xCF : CPU_SET_BIT( &(m_RegisterAF.hi), 1  ) ; break ;
        case 0xD0 : CPU_SET_BIT( &(m_RegisterBC.hi), 2  ) ; break ;
        case 0xD1 : CPU_SET_BIT( &(m_RegisterBC.lo), 2  ) ; break ;
        case 0xD2 : CPU_SET_BIT( &(m_RegisterDE.hi), 2  ) ; break ;
        case 0xD3 : CPU_SET_BIT( &(m_RegisterDE.lo), 2  ) ; break ;
        case 0xD4 : CPU_SET_BIT( &(m_RegisterHL.hi), 2  ) ; break ;
        case 0xD5 : CPU_SET_BIT( &(m_RegisterHL.lo), 2  ) ; break ;
        case 0xD6 : CPU_SET_BIT_MEMORY( m_RegisterHL.reg, 2 ) ; break ;
        case 0xD7 : CPU_SET_BIT( &(m_RegisterAF.hi), 2  ) ; break ;
        case 0xD8 : CPU_SET_BIT( &(m_RegisterBC.hi), 3  ) ; break ;
        case 0xD9 : CPU_SET_BIT( &(m_RegisterBC.lo), 3  ) ; break ;
        case 0xDA : CPU_SET_BIT( &(m_RegisterDE.hi), 3  ) ; break ;
        case 0xDB : CPU_SET_BIT( &(m_RegisterDE.lo), 3  ) ; break ;
        case 0xDC : CPU_SET_BIT( &(m_RegisterHL.hi), 3  ) ; break ;
        case 0xDD : CPU_SET_BIT( &(m_RegisterHL.lo), 3  ) ; break ;
        case 0xDE : CPU_SET_BIT_MEMORY( m_RegisterHL.reg, 3  ) ; break ;
        case 0xDF : CPU_SET_BIT( &(m_RegisterAF.hi), 3  ) ; break ;
        case 0xE0 : CPU_SET_BIT( &(m_RegisterBC.hi), 4  ) ; break ;
        case 0xE1 : CPU_SET_BIT( &(m_RegisterBC.lo), 4  ) ; break ;
        case 0xE2 : CPU_SET_BIT( &(m_RegisterDE.hi), 4  ) ; break ;
        case 0xE3 : CPU_SET_BIT( &(m_RegisterDE.lo), 4  ) ; break ;
        case 0xE4 : CPU_SET_BIT( &(m_RegisterHL.hi), 4  ) ; break ;
        case 0xE5 : CPU_SET_BIT( &(m_RegisterHL.lo), 4  ) ; break ;
        case 0xE6 : CPU_SET_BIT_MEMORY( m_RegisterHL.reg, 4) ; break ;
        case 0xE7 : CPU_SET_BIT( &(m_RegisterAF.hi), 4 ) ; break ;
        case 0xE8 : CPU_SET_BIT( &(m_RegisterBC.hi), 5 ) ; break ;
        case 0xE9 : CPU_SET_BIT( &(m_RegisterBC.lo), 5 ) ; break ;
        case 0xEA : CPU_SET_BIT( &(m_RegisterDE.hi), 5 ) ; break ;
        case 0xEB : CPU_SET_BIT( &(m_RegisterDE.lo), 5 ) ; break ;
        case 0xEC : CPU_SET_BIT( &(m_RegisterHL.hi), 5 ) ; break ;
        case 0xED : CPU_SET_BIT( &(m_RegisterHL.lo), 5 ) ; break ;
        case 0xEE : CPU_SET_BIT_MEMORY( m_RegisterHL.reg, 5 ) ; break ;
        case 0xEF : CPU_SET_BIT( &(m_RegisterAF.hi), 5  ) ; break ;
        case 0xF0 : CPU_SET_BIT( &(m_RegisterBC.hi), 6  ) ; break ;
        case 0xF1 : CPU_SET_BIT( &(m_RegisterBC.lo), 6  ) ; break ;
        case 0xF2 : CPU_SET_BIT( &(m_RegisterDE.hi), 6  ) ; break ;
        case 0xF3 : CPU_SET_BIT( &(m_RegisterDE.lo), 6  ) ; break ;
        case 0xF4 : CPU_SET_BIT( &(m_RegisterHL.hi), 6  ) ; break ;
        case 0xF5 : CPU_SET_BIT( &(m_RegisterHL.lo), 6  ) ; break ;
        case 0xF6 : CPU_SET_BIT_MEMORY( m_RegisterHL.reg, 6 ) ; break ;
        case 0xF7 : CPU_SET_BIT( &(m_RegisterAF.hi), 6 ) ; break ;
        case 0xF8 : CPU_SET_BIT( &(m_RegisterBC.hi), 7  ) ; break ;
        case 0xF9 : CPU_SET_BIT( &(m_RegisterBC.lo), 7  ) ; break ;
        case 0xFA : CPU_SET_BIT( &(m_RegisterDE.hi), 7  ) ; break ;
        case 0xFB : CPU_SET_BIT( &(m_RegisterDE.lo), 7  ) ; break ;
        case 0xFC : CPU_SET_BIT( &(m_RegisterHL.hi), 7  ) ; break ;
        case 0xFD : CPU_SET_BIT( &(m_RegisterHL.lo), 7  ) ; break ;
        case 0xFE : CPU_SET_BIT_MEMORY( m_RegisterHL.reg, 7 ) ; break ;
        case 0xFF : CPU_SET_BIT( &(m_RegisterAF.hi), 7 ) ; break ;
            
            
        default:
        {
            char buffer[256];
            sprintf(buffer, "Unhandled Extended Opcode %x", opcode) ;
            printf("%s\n", buffer);
            assert(false) ;
        } break;
    }
}

//////////////////////////////////////////////////////////////////////////////////

void ExecuteOpcode(BYTE opcode)
{
    switch(opcode)
    {
            //no-op
        case 0x00: m_CyclesThisUpdate+=4 ; break ;
            
            // 8-Bit Loads
        case 0x06: CPU_8BIT_LOAD(&(m_RegisterBC.hi)) ; break ;
        case 0x0E: CPU_8BIT_LOAD(&(m_RegisterBC.lo)) ; break ;
        case 0x16: CPU_8BIT_LOAD(&(m_RegisterDE.hi)) ; break ;
        case 0x1E: CPU_8BIT_LOAD(&(m_RegisterDE.lo)) ; break ;
        case 0x26: CPU_8BIT_LOAD(&(m_RegisterHL.hi)) ; break ;
        case 0x2E: CPU_8BIT_LOAD(&(m_RegisterHL.lo)) ; break ;
            
            // load reg
        case 0x7F: CPU_REG_LOAD(&(m_RegisterAF.hi), m_RegisterAF.hi, 4) ; break ;
        case 0x78: CPU_REG_LOAD(&(m_RegisterAF.hi), m_RegisterBC.hi, 4) ; break ;
        case 0x79: CPU_REG_LOAD(&(m_RegisterAF.hi), m_RegisterBC.lo, 4) ; break ;
        case 0x7A: CPU_REG_LOAD(&(m_RegisterAF.hi), m_RegisterDE.hi, 4) ; break ;
        case 0x7B: CPU_REG_LOAD(&(m_RegisterAF.hi), m_RegisterDE.lo, 4) ; break ;
        case 0x7C: CPU_REG_LOAD(&(m_RegisterAF.hi), m_RegisterHL.hi, 4) ; break ;
        case 0x7D: CPU_REG_LOAD(&(m_RegisterAF.hi), m_RegisterHL.lo, 4) ; break ;
        case 0x40: CPU_REG_LOAD(&(m_RegisterBC.hi), m_RegisterBC.hi, 4) ; break ;
        case 0x41: CPU_REG_LOAD(&(m_RegisterBC.hi), m_RegisterBC.lo, 4) ; break ;
        case 0x42: CPU_REG_LOAD(&(m_RegisterBC.hi), m_RegisterDE.hi, 4) ; break ;
        case 0x43: CPU_REG_LOAD(&(m_RegisterBC.hi), m_RegisterDE.lo, 4) ; break ;
        case 0x44: CPU_REG_LOAD(&(m_RegisterBC.hi), m_RegisterHL.hi, 4) ; break ;
        case 0x45: CPU_REG_LOAD(&(m_RegisterBC.hi), m_RegisterHL.lo, 4) ; break ;
        case 0x48: CPU_REG_LOAD(&(m_RegisterBC.lo), m_RegisterBC.hi, 4) ; break ;
        case 0x49: CPU_REG_LOAD(&(m_RegisterBC.lo), m_RegisterBC.lo, 4) ; break ;
        case 0x4A: CPU_REG_LOAD(&(m_RegisterBC.lo), m_RegisterDE.hi, 4) ; break ;
        case 0x4B: CPU_REG_LOAD(&(m_RegisterBC.lo), m_RegisterDE.lo, 4) ; break ;
        case 0x4C: CPU_REG_LOAD(&(m_RegisterBC.lo), m_RegisterHL.hi, 4) ; break ;
        case 0x4D: CPU_REG_LOAD(&(m_RegisterBC.lo), m_RegisterHL.lo, 4) ; break ;
        case 0x50: CPU_REG_LOAD(&(m_RegisterDE.hi), m_RegisterBC.hi, 4) ; break ;
        case 0x51: CPU_REG_LOAD(&(m_RegisterDE.hi), m_RegisterBC.lo, 4) ; break ;
        case 0x52: CPU_REG_LOAD(&(m_RegisterDE.hi), m_RegisterDE.hi, 4) ; break ;
        case 0x53: CPU_REG_LOAD(&(m_RegisterDE.hi), m_RegisterDE.lo, 4) ; break ;
        case 0x54: CPU_REG_LOAD(&(m_RegisterDE.hi), m_RegisterHL.hi, 4) ; break ;
        case 0x55: CPU_REG_LOAD(&(m_RegisterDE.hi), m_RegisterHL.lo, 4) ; break ;
        case 0x58: CPU_REG_LOAD(&(m_RegisterDE.lo), m_RegisterBC.hi, 4) ; break ;
        case 0x59: CPU_REG_LOAD(&(m_RegisterDE.lo), m_RegisterBC.lo, 4) ; break ;
        case 0x5A: CPU_REG_LOAD(&(m_RegisterDE.lo), m_RegisterDE.hi, 4) ; break ;
        case 0x5B: CPU_REG_LOAD(&(m_RegisterDE.lo), m_RegisterDE.lo, 4) ; break ;
        case 0x5C: CPU_REG_LOAD(&(m_RegisterDE.lo), m_RegisterHL.hi, 4) ; break ;
        case 0x5D: CPU_REG_LOAD(&(m_RegisterDE.lo), m_RegisterHL.lo, 4) ; break ;
        case 0x60: CPU_REG_LOAD(&(m_RegisterHL.hi), m_RegisterBC.hi, 4) ; break ;
        case 0x61: CPU_REG_LOAD(&(m_RegisterHL.hi), m_RegisterBC.lo, 4) ; break ;
        case 0x62: CPU_REG_LOAD(&(m_RegisterHL.hi), m_RegisterDE.hi, 4) ; break ;
        case 0x63: CPU_REG_LOAD(&(m_RegisterHL.hi), m_RegisterDE.lo, 4) ; break ;
        case 0x64: CPU_REG_LOAD(&(m_RegisterHL.hi), m_RegisterHL.hi, 4) ; break ;
        case 0x65: CPU_REG_LOAD(&(m_RegisterHL.hi), m_RegisterHL.lo, 4) ; break ;
        case 0x68: CPU_REG_LOAD(&(m_RegisterHL.lo), m_RegisterBC.hi, 4) ; break ;
        case 0x69: CPU_REG_LOAD(&(m_RegisterHL.lo), m_RegisterBC.lo, 4) ; break ;
        case 0x6A: CPU_REG_LOAD(&(m_RegisterHL.lo), m_RegisterDE.hi, 4) ; break ;
        case 0x6B: CPU_REG_LOAD(&(m_RegisterHL.lo), m_RegisterDE.lo, 4) ; break ;
        case 0x6C: CPU_REG_LOAD(&(m_RegisterHL.lo), m_RegisterHL.hi, 4) ; break ;
        case 0x6D: CPU_REG_LOAD(&(m_RegisterHL.lo), m_RegisterHL.lo, 4) ; break ;
            
            // write reg to memory
        case 0x70: WriteByte(m_RegisterHL.reg, m_RegisterBC.hi) ; m_CyclesThisUpdate+=8;break ;
        case 0x71: WriteByte(m_RegisterHL.reg, m_RegisterBC.lo) ; m_CyclesThisUpdate+=8;break ;
        case 0x72: WriteByte(m_RegisterHL.reg, m_RegisterDE.hi) ; m_CyclesThisUpdate+=8;break ;
        case 0x73: WriteByte(m_RegisterHL.reg, m_RegisterDE.lo) ; m_CyclesThisUpdate+=8;break ;
        case 0x74: WriteByte(m_RegisterHL.reg, m_RegisterHL.hi) ; m_CyclesThisUpdate+=8;break ;
        case 0x75: WriteByte(m_RegisterHL.reg, m_RegisterHL.lo) ; m_CyclesThisUpdate+=8;break ;
            
            // write memory to reg
        case 0x7E: CPU_REG_LOAD_ROM(&(m_RegisterAF.hi), m_RegisterHL.reg) ; break ;
        case 0x46: CPU_REG_LOAD_ROM(&(m_RegisterBC.hi), m_RegisterHL.reg) ; break ;
        case 0x4E: CPU_REG_LOAD_ROM(&(m_RegisterBC.lo), m_RegisterHL.reg) ; break ;
        case 0x56: CPU_REG_LOAD_ROM(&(m_RegisterDE.hi), m_RegisterHL.reg) ; break ;
        case 0x5E: CPU_REG_LOAD_ROM(&(m_RegisterDE.lo), m_RegisterHL.reg) ; break ;
        case 0x66: CPU_REG_LOAD_ROM(&(m_RegisterHL.hi), m_RegisterHL.reg) ; break ;
        case 0x6E: CPU_REG_LOAD_ROM(&(m_RegisterHL.lo), m_RegisterHL.reg) ; break ;
        case 0x0A: CPU_REG_LOAD_ROM(&(m_RegisterAF.hi), m_RegisterBC.reg) ; break ;
        case 0x1A: CPU_REG_LOAD_ROM(&(m_RegisterAF.hi), m_RegisterDE.reg) ; break ;
        case 0xF2: CPU_REG_LOAD_ROM(&(m_RegisterAF.hi), (0xFF00+m_RegisterBC.lo)) ; break ;
            
            
            
            // put a into register
        case 0x47 : CPU_REG_LOAD(&(m_RegisterBC.hi), m_RegisterAF.hi, 4) ; break ;
        case 0x4F : CPU_REG_LOAD(&(m_RegisterBC.lo), m_RegisterAF.hi, 4) ; break ;
        case 0x57 : CPU_REG_LOAD(&(m_RegisterDE.hi), m_RegisterAF.hi, 4) ; break ;
        case 0x5F : CPU_REG_LOAD(&(m_RegisterDE.lo), m_RegisterAF.hi, 4) ; break ;
        case 0x67 : CPU_REG_LOAD(&(m_RegisterHL.hi), m_RegisterAF.hi, 4) ; break ;
        case 0x6F : CPU_REG_LOAD(&(m_RegisterHL.lo), m_RegisterAF.hi, 4) ; break ;
            
            // put a into memory address
        case 0x02: WriteByte(m_RegisterBC.reg, m_RegisterAF.hi) ; m_CyclesThisUpdate+=8; break ;
        case 0x12: WriteByte(m_RegisterDE.reg, m_RegisterAF.hi) ; m_CyclesThisUpdate+=8; break ;
        case 0x77: WriteByte(m_RegisterHL.reg, m_RegisterAF.hi) ; m_CyclesThisUpdate+=8; break ;
        case 0xE2: WriteByte((0xFF00+m_RegisterBC.lo), m_RegisterAF.hi) ; m_CyclesThisUpdate+=8; break ;
            
            // put memory into a, decrement/increment memory
        case 0x3A: CPU_REG_LOAD_ROM(&(m_RegisterAF.hi),m_RegisterHL.reg ) ; CPU_16BIT_DEC(&(m_RegisterHL.reg),0) ;break ;
        case 0x2A: CPU_REG_LOAD_ROM(&(m_RegisterAF.hi),m_RegisterHL.reg ) ; CPU_16BIT_INC(&(m_RegisterHL.reg),0) ;break ;
            
            // put a into memory, decrement/increment reg
        case 0x32: WriteByte(m_RegisterHL.reg, m_RegisterAF.hi); CPU_16BIT_DEC(&(m_RegisterHL.reg),0) ; m_CyclesThisUpdate += 8; break;
        case 0x22: WriteByte(m_RegisterHL.reg, m_RegisterAF.hi); CPU_16BIT_INC(&(m_RegisterHL.reg),0) ; m_CyclesThisUpdate += 8;break;
            
            // 16 bit loads
        case 0x01: CPU_16BIT_LOAD( &(m_RegisterBC.reg) ); break ;
        case 0x11: CPU_16BIT_LOAD( &(m_RegisterDE.reg) );break ;
        case 0x21: CPU_16BIT_LOAD( &(m_RegisterHL.reg) );break ;
        case 0x31: CPU_16BIT_LOAD( &(m_StackPointer.reg) );break ;
        case 0xF9: m_StackPointer.reg = m_RegisterHL.reg ; m_CyclesThisUpdate+=8; break ;
            
            // push word onto stack
        case 0xF5: PushWordOntoStack( m_RegisterAF.reg ) ; m_CyclesThisUpdate+=16 ;break;
        case 0xC5: PushWordOntoStack( m_RegisterBC.reg ) ; m_CyclesThisUpdate+=16 ;break;
        case 0xD5: PushWordOntoStack( m_RegisterDE.reg ) ; m_CyclesThisUpdate+=16 ;break;
        case 0xE5: PushWordOntoStack( m_RegisterHL.reg ) ; m_CyclesThisUpdate+=16 ; break;
            
            // pop word from stack into reg
        case 0xF1: m_RegisterAF.reg = PopWordOffStack( ) ; m_CyclesThisUpdate+=12 ;break;
        case 0xC1: m_RegisterBC.reg = PopWordOffStack( ) ; m_CyclesThisUpdate+=12 ;break;
        case 0xD1: m_RegisterDE.reg = PopWordOffStack( ) ; m_CyclesThisUpdate+=12 ;break;
        case 0xE1: m_RegisterHL.reg = PopWordOffStack( ) ; m_CyclesThisUpdate+=12 ; break;
            
            // 8-bit add
        case 0x87: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterAF.hi,4,false,false) ; break ;
        case 0x80: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterBC.hi,4,false,false) ; break ;
        case 0x81: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterBC.lo,4,false,false) ; break ;
        case 0x82: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterDE.hi,4,false,false) ; break ;
        case 0x83: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterDE.lo,4,false,false) ; break ;
        case 0x84: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterHL.hi,4,false,false) ; break ;
        case 0x85: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterHL.lo,4,false,false) ; break ;
        case 0x86: CPU_8BIT_ADD(&(m_RegisterAF.hi), ReadMemory(m_RegisterHL.reg),8,false,false) ; break ;
        case 0xC6: CPU_8BIT_ADD(&(m_RegisterAF.hi), 0,8,true,false) ; break ;
            
            // 8-bit add + carry
        case 0x8F: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterAF.hi,4,false,true) ; break ;
        case 0x88: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterBC.hi,4,false,true) ; break ;
        case 0x89: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterBC.lo,4,false,true) ; break ;
        case 0x8A: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterDE.hi,4,false,true) ; break ;
        case 0x8B: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterDE.lo,4,false,true) ; break ;
        case 0x8C: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterHL.hi,4,false,true) ; break ;
        case 0x8D: CPU_8BIT_ADD(&(m_RegisterAF.hi), m_RegisterHL.lo,4,false,true) ; break ;
        case 0x8E: CPU_8BIT_ADD(&(m_RegisterAF.hi), ReadMemory(m_RegisterHL.reg),8,false,true) ; break ;
        case 0xCE: CPU_8BIT_ADD(&(m_RegisterAF.hi), 0,8,true,true) ; break ;
            
            // 8-bit subtract
        case 0x97: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterAF.hi,4,false,false) ; break ;
        case 0x90: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterBC.hi,4,false,false) ; break ;
        case 0x91: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterBC.lo,4,false,false) ; break ;
        case 0x92: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterDE.hi,4,false,false) ; break ;
        case 0x93: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterDE.lo,4,false,false) ; break ;
        case 0x94: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterHL.hi,4,false,false) ; break ;
        case 0x95: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterHL.lo,4,false,false) ; break ;
        case 0x96: CPU_8BIT_SUB(&(m_RegisterAF.hi), ReadMemory(m_RegisterHL.reg),8,false,false) ; break ;
        case 0xD6: CPU_8BIT_SUB(&(m_RegisterAF.hi), 0,8,true,false) ; break ;
            
            // 8-bit subtract + carry
        case 0x9F: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterAF.hi,4,false,true) ; break ;
        case 0x98: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterBC.hi,4,false,true) ; break ;
        case 0x99: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterBC.lo,4,false,true) ; break ;
        case 0x9A: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterDE.hi,4,false,true) ; break ;
        case 0x9B: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterDE.lo,4,false,true) ; break ;
        case 0x9C: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterHL.hi,4,false,true) ; break ;
        case 0x9D: CPU_8BIT_SUB(&(m_RegisterAF.hi), m_RegisterHL.lo,4,false,true) ; break ;
        case 0x9E: CPU_8BIT_SUB(&(m_RegisterAF.hi), ReadMemory(m_RegisterHL.reg),8,false,true) ; break ;
        case 0xDE: CPU_8BIT_SUB(&(m_RegisterAF.hi), 0,8,true,true) ; break ;
            
            // 8-bit AND reg with reg
        case 0xA7: CPU_8BIT_AND(&(m_RegisterAF.hi), m_RegisterAF.hi,4, false) ; break ;
        case 0xA0: CPU_8BIT_AND(&(m_RegisterAF.hi), m_RegisterBC.hi,4, false) ; break ;
        case 0xA1: CPU_8BIT_AND(&(m_RegisterAF.hi), m_RegisterBC.lo,4, false) ; break ;
        case 0xA2: CPU_8BIT_AND(&(m_RegisterAF.hi), m_RegisterDE.hi,4, false) ; break ;
        case 0xA3: CPU_8BIT_AND(&(m_RegisterAF.hi), m_RegisterDE.lo,4, false) ; break ;
        case 0xA4: CPU_8BIT_AND(&(m_RegisterAF.hi), m_RegisterHL.hi,4, false) ; break ;
        case 0xA5: CPU_8BIT_AND(&(m_RegisterAF.hi), m_RegisterHL.lo,4, false) ; break ;
        case 0xA6: CPU_8BIT_AND(&(m_RegisterAF.hi), ReadMemory(m_RegisterHL.reg),8, false) ; break ;
        case 0xE6: CPU_8BIT_AND(&(m_RegisterAF.hi), 0,8, true) ; break ;
            
            // 8-bit OR reg with reg
        case 0xB7: CPU_8BIT_OR(&(m_RegisterAF.hi), m_RegisterAF.hi,4, false) ; break ;
        case 0xB0: CPU_8BIT_OR(&(m_RegisterAF.hi), m_RegisterBC.hi,4, false) ; break ;
        case 0xB1: CPU_8BIT_OR(&(m_RegisterAF.hi), m_RegisterBC.lo,4, false) ; break ;
        case 0xB2: CPU_8BIT_OR(&(m_RegisterAF.hi), m_RegisterDE.hi,4, false) ; break ;
        case 0xB3: CPU_8BIT_OR(&(m_RegisterAF.hi), m_RegisterDE.lo,4, false) ; break ;
        case 0xB4: CPU_8BIT_OR(&(m_RegisterAF.hi), m_RegisterHL.hi,4, false) ; break ;
        case 0xB5: CPU_8BIT_OR(&(m_RegisterAF.hi), m_RegisterHL.lo,4, false) ; break ;
        case 0xB6: CPU_8BIT_OR(&(m_RegisterAF.hi), ReadMemory(m_RegisterHL.reg),8, false) ; break ;
        case 0xF6: CPU_8BIT_OR(&(m_RegisterAF.hi), 0,8, true) ; break ;
            
            // 8-bit XOR reg with reg
        case 0xAF: CPU_8BIT_XOR(&(m_RegisterAF.hi), m_RegisterAF.hi,4, false) ; break ;
        case 0xA8: CPU_8BIT_XOR(&(m_RegisterAF.hi), m_RegisterBC.hi,4, false) ; break ;
        case 0xA9: CPU_8BIT_XOR(&(m_RegisterAF.hi), m_RegisterBC.lo,4, false) ; break ;
        case 0xAA: CPU_8BIT_XOR(&(m_RegisterAF.hi), m_RegisterDE.hi,4, false) ; break ;
        case 0xAB: CPU_8BIT_XOR(&(m_RegisterAF.hi), m_RegisterDE.lo,4, false) ; break ;
        case 0xAC: CPU_8BIT_XOR(&(m_RegisterAF.hi), m_RegisterHL.hi,4, false) ; break ;
        case 0xAD: CPU_8BIT_XOR(&(m_RegisterAF.hi), m_RegisterHL.lo,4, false) ; break ;
        case 0xAE: CPU_8BIT_XOR(&(m_RegisterAF.hi), ReadMemory(m_RegisterHL.reg),8, false) ; break ;
        case 0xEE: CPU_8BIT_XOR(&(m_RegisterAF.hi), 0,8, true) ; break ;
            
            // 8-Bit compare
        case 0xBF: CPU_8BIT_COMPARE(m_RegisterAF.hi, m_RegisterAF.hi,4, false) ; break ;
        case 0xB8: CPU_8BIT_COMPARE(m_RegisterAF.hi, m_RegisterBC.hi,4, false) ; break ;
        case 0xB9: CPU_8BIT_COMPARE(m_RegisterAF.hi, m_RegisterBC.lo,4, false) ; break ;
        case 0xBA: CPU_8BIT_COMPARE(m_RegisterAF.hi, m_RegisterDE.hi,4, false) ; break ;
        case 0xBB: CPU_8BIT_COMPARE(m_RegisterAF.hi, m_RegisterDE.lo,4, false) ; break ;
        case 0xBC: CPU_8BIT_COMPARE(m_RegisterAF.hi, m_RegisterHL.hi,4, false) ; break ;
        case 0xBD: CPU_8BIT_COMPARE(m_RegisterAF.hi, m_RegisterHL.lo,4, false) ; break ;
        case 0xBE: CPU_8BIT_COMPARE(m_RegisterAF.hi, ReadMemory(m_RegisterHL.reg),8, false) ; break;
        case 0xFE: CPU_8BIT_COMPARE(m_RegisterAF.hi, 0,8, true) ; break ;
            
            // 8-bit inc
        case 0x3C: CPU_8BIT_INC(&(m_RegisterAF.hi),4); break ;
        case 0x04: CPU_8BIT_INC(&(m_RegisterBC.hi),4); break ;
        case 0x0C: CPU_8BIT_INC(&(m_RegisterBC.lo),4); break ;
        case 0x14: CPU_8BIT_INC(&(m_RegisterDE.hi),4); break ;
        case 0x1C: CPU_8BIT_INC(&(m_RegisterDE.lo),4); break ;
        case 0x24: CPU_8BIT_INC(&(m_RegisterHL.hi),4); break ;
        case 0x2C: CPU_8BIT_INC(&(m_RegisterHL.lo),4); break ;
        case 0x34: CPU_8BIT_MEMORY_INC(m_RegisterHL.reg,12); break ;
            
            // 8-bit dec
        case 0x3D: CPU_8BIT_DEC(&(m_RegisterAF.hi),4); break ;
        case 0x05: CPU_8BIT_DEC(&(m_RegisterBC.hi),4); break ;
        case 0x0D: CPU_8BIT_DEC(&(m_RegisterBC.lo),4); break ;
        case 0x15: CPU_8BIT_DEC(&(m_RegisterDE.hi),4); break ;
        case 0x1D: CPU_8BIT_DEC(&(m_RegisterDE.lo),4); break ;
        case 0x25: CPU_8BIT_DEC(&(m_RegisterHL.hi),4); break ;
        case 0x2D: CPU_8BIT_DEC(&(m_RegisterHL.lo),4); break ;
        case 0x35: CPU_8BIT_MEMORY_DEC(m_RegisterHL.reg,12); break ;
            
            // 16-bit add
        case 0x09: CPU_16BIT_ADD(&(m_RegisterHL.reg),m_RegisterBC.reg,8) ; break ;
        case 0x19: CPU_16BIT_ADD(&(m_RegisterHL.reg),m_RegisterDE.reg,8) ; break ;
        case 0x29: CPU_16BIT_ADD(&(m_RegisterHL.reg),m_RegisterHL.reg,8) ; break ;
        case 0x39: CPU_16BIT_ADD(&(m_RegisterHL.reg),m_StackPointer.reg,8) ; break ;
            
            // inc 16-bit register
        case 0x03: CPU_16BIT_INC( &(m_RegisterBC.reg), 8) ; break ;
        case 0x13: CPU_16BIT_INC( &(m_RegisterDE.reg), 8) ; break ;
        case 0x23: CPU_16BIT_INC( &(m_RegisterHL.reg), 8) ; break ;
        case 0x33: CPU_16BIT_INC( &(m_StackPointer.reg), 8) ; break ;
            
            // dec 16-bit register
        case 0x0B: CPU_16BIT_DEC( &(m_RegisterBC.reg), 8) ; break ;
        case 0x1B: CPU_16BIT_DEC( &(m_RegisterDE.reg), 8) ; break ;
        case 0x2B: CPU_16BIT_DEC( &(m_RegisterHL.reg), 8) ; break ;
        case 0x3B: CPU_16BIT_DEC( &(m_StackPointer.reg), 8) ; break ;
            
            // jumps
        case 0xE9: m_CyclesThisUpdate+=4 ; m_ProgramCounter = m_RegisterHL.reg ; break ;
        case 0xC3: CPU_JUMP(false, 0, false) ; break ;
        case 0xC2: CPU_JUMP(true, FLAG_Z, false) ; break ;
        case 0xCA: CPU_JUMP(true, FLAG_Z, true) ; break ;
        case 0xD2: CPU_JUMP(true, FLAG_C, false) ; break ;
        case 0xDA: CPU_JUMP(true, FLAG_C, true) ; break ;
            
            // jump with immediate data
        case 0x18 : CPU_JUMP_IMMEDIATE( false, 0, false ) ; break ;
        case 0x20 : CPU_JUMP_IMMEDIATE( true, FLAG_Z, false ) ;break ;
        case 0x28 : CPU_JUMP_IMMEDIATE( true, FLAG_Z, true ) ;break ;
        case 0x30 : CPU_JUMP_IMMEDIATE( true, FLAG_C, false) ;break ;
        case 0x38 : CPU_JUMP_IMMEDIATE( true, FLAG_C, true ) ;break ;
            
            // calls
        case 0xCD : CPU_CALL( false, 0, false) ; break ;
        case 0xC4 : CPU_CALL( true, FLAG_Z, false) ;break ;
        case 0xCC : CPU_CALL( true, FLAG_Z, true) ;break ;
        case 0xD4 : CPU_CALL( true, FLAG_C, false) ;break ;
        case 0xDC : CPU_CALL( true, FLAG_C, true) ; break ;
            
            // returns
        case 0xC9: CPU_RETURN( false, 0, false ) ; break ;
        case 0xC0: CPU_RETURN( true, FLAG_Z, false ) ; break ;
        case 0xC8: CPU_RETURN( true, FLAG_Z, true ) ; break ;
        case 0xD0: CPU_RETURN( true, FLAG_C, false ) ; break ;
        case 0xD8: CPU_RETURN( true, FLAG_C, true ) ; break ;
            
            
            // restarts
        case 0xC7: CPU_RESTARTS( 0x00 ) ; break ;
        case 0xCF: CPU_RESTARTS( 0x08 ) ; break ;
        case 0xD7: CPU_RESTARTS( 0x10 ) ; break ;
        case 0xDF: CPU_RESTARTS( 0x18 ) ; break ;
        case 0xE7: CPU_RESTARTS( 0x20 ) ; break ;
        case 0xEF: CPU_RESTARTS( 0x28 ) ; break ;
        case 0xF7: CPU_RESTARTS( 0x30 ) ; break ;
        case 0xFF: CPU_RESTARTS( 0x38 ) ; break ;
            
        case 0x27: CPU_DAA( ) ; break ;
            
            // handle the extended opcodes
        case 0xCB: ExecuteExtendedOpcode( ) ; break ;
            
            // unique instructions
        case 0x07:CPU_RLC(&(m_RegisterAF.hi)); break ;
        case 0x0F:CPU_RRC(&(m_RegisterAF.hi)) ;	break ;
        case 0x17:CPU_RL(&(m_RegisterAF.hi)) ; break ;
        case 0x1F:CPU_RR(&(m_RegisterAF.hi)) ;	break ;
            
        case 0xD9:
        {
            //LOGMESSAGE(Logging::MSG_INFO, "Returning from iterupt") ;
            m_ProgramCounter = PopWordOffStack( ) ;
            m_EnableInterupts = true ;
            m_CyclesThisUpdate+=8 ;
        }break ;
            
        case 0x08:
        {
            WORD nn = ReadWord( ) ;
            m_ProgramCounter+=2 ;
            WriteByte(nn, m_StackPointer.lo) ;
            nn++ ;
            WriteByte(nn, m_StackPointer.hi) ;
            m_CyclesThisUpdate += 20 ;
        }break ;
            
        case 0x36:
        {
            m_CyclesThisUpdate+=12 ;
            BYTE n = ReadMemory(m_ProgramCounter) ;
            m_ProgramCounter++;
            WriteByte(m_RegisterHL.reg, n) ;
        }break ;
            
        case 0xFA:
        {
            m_CyclesThisUpdate+=16 ;
            WORD nn = ReadWord( ) ;
            m_ProgramCounter+=2 ;
            BYTE n = ReadMemory(nn) ;
            m_RegisterAF.hi = n ;
        }break ;
            
        case 0x3E:
        {
            m_CyclesThisUpdate+=8;
            BYTE n = ReadMemory(m_ProgramCounter) ;
            m_ProgramCounter++ ;
            m_RegisterAF.hi = n;
        }break ;
        case 0xEA:
        {
            m_CyclesThisUpdate+=16 ;
            WORD nn = ReadWord( ) ;
            m_ProgramCounter+=2 ;
            WriteByte(nn, m_RegisterAF.hi) ;
        }break ;
            
        case 0xF3:
        {
            m_PendingInteruptDisabled = true ;
            m_CyclesThisUpdate+=4 ;
        }break ;
            
        case 0xFB:
        {
            m_PendingInteruptEnabled = true ;
            m_CyclesThisUpdate+=4 ;
        }break ;
            
        case 0xE0:
        {
            BYTE n = ReadMemory(m_ProgramCounter) ;
            m_ProgramCounter++ ;
            WORD address = 0xFF00 + n ;
            WriteByte(address, m_RegisterAF.hi) ;
            m_CyclesThisUpdate += 12 ;
        }break ;
            
        case 0xF0:
        {
            BYTE n = ReadMemory(m_ProgramCounter) ;
            m_ProgramCounter++ ;
            WORD address = 0xFF00 + n ;
            m_RegisterAF.hi = ReadMemory( address ) ;
            m_CyclesThisUpdate+=12 ;
        }break ;
            
        case 0x2F:
        {
            m_CyclesThisUpdate += 4;
            m_RegisterAF.hi ^= 0xFF;
            
            m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_N) ;
            m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_H) ;
        }break ;
            
        case 0x76:
        {
            m_CyclesThisUpdate += 4 ;
            m_Halted = true ;
        }break ;
            
        case 0x3F:
        {
            m_CyclesThisUpdate += 4 ;
            if (TestBit(m_RegisterAF.lo, FLAG_C))
                m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_C) ;
            else
                m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C) ;
            
            m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_H) ;
            m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_N) ;
        }break ;
            
        case 0x37:
        {
            m_CyclesThisUpdate += 4;
            m_RegisterAF.lo = BitSet(m_RegisterAF.lo, FLAG_C);
            m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_H);
            m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_N);
        } break ;
            
        case 0xF8:
        {
            SIGNED_BYTE n = ReadMemory(m_ProgramCounter) ;
            m_ProgramCounter++ ;
            m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_Z);
            m_RegisterAF.lo = BitReset(m_RegisterAF.lo, FLAG_N);
            
            
            WORD value = (m_StackPointer.reg + n) & 0xFFFF;
            
            m_RegisterHL.reg = value ;
            //unsigned int v = m_StackPointer.reg + n ;
            
            /*
            if( n > 0xFFFF )
                m_RegisterAF.lo = BitSet(m_RegisterAF.lo,FLAG_C) ;
            else
                m_RegisterAF.lo = BitReset(m_RegisterAF.lo,FLAG_C) ;
             */
            m_RegisterAF.lo = BitReset(m_RegisterAF.lo,FLAG_C) ;
            
            if( (m_StackPointer.reg & 0xF) + (n & 0xF) > 0xF )
                m_RegisterAF.lo = BitSet(m_RegisterAF.lo,FLAG_H) ;
            else
                m_RegisterAF.lo = BitReset(m_RegisterAF.lo,FLAG_H) ;
            
        }break ;
            
        case 0x10:
        {
            m_ProgramCounter++ ;
            m_CyclesThisUpdate+= 4 ;
        }break ;
            
        default:
        {
            char buffer[200] ;
            sprintf(buffer, "Unhandled Opcode %x", opcode) ;
            printf("%s\n", buffer);
            assert(false) ;
        } break;
    }
}


//下面是GB业务逻辑
//////////////////////////////////////////////////

void DoTimers( int cycles )
{
    // do divider register
    m_DividerVariable += cycles ;
    if (m_DividerVariable >= 256)//freq 16382
    {
        m_DividerVariable = 0;
        m_Rom[0xFF04]++ ;//Divider Register
    }
    
    // do timer
    BYTE timerAtts = m_Rom[0xFF07];//TMC 设置freq
    if (TestBit(timerAtts, 2))//bit 3 enable the timer
    {
        m_TimerVariable += cycles ;
        
        // time to increment the timer
        if (m_TimerVariable >= m_CurrentClockSpeed)
        {
            m_TimerVariable = 0 ;
            if (m_Rom[0xFF05] == 0xFF)//溢出则发送中断请求
            {
                m_Rom[0xFF05] = m_Rom[0xFF06] ;//重制计数器
                RequestInterupt(2) ;
            }else{
                m_Rom[0xFF05]++ ;//counter加1
            }
        }
    }
}

BYTE GetLCDMode()
{
    BYTE lcdStatus = m_Rom[0xFF41] ;
    return lcdStatus & 0x3 ;
}

void SetLCDStatus( )
{
    BYTE lcdStatus = m_Rom[0xFF41] ;
    
    if (!TestBit(ReadMemory(0xFF40), 7))
    {
        m_RetraceLY = RETRACE_START ;
        m_Rom[0xFF44] = 0 ;
        // mode gets set to 1 when disabled screen.
        lcdStatus &= 252 ;
        lcdStatus = BitSet(lcdStatus,0) ;
        WriteByte(0xFF41,lcdStatus) ;
        return ;
    }
    
    
    BYTE lY = ReadMemory(0xFF44) ;
    
    BYTE currentMode = GetLCDMode( ) ;
    
    int mode = 0 ;
    bool reqInt = false ;
    
    // set mode as vertical blank
    if (lY >= VERTICAL_BLANK_SCAN_LINE)
    {
        // mode 1
        mode = 1 ;
        lcdStatus = BitSet(lcdStatus,0) ;
        lcdStatus = BitReset(lcdStatus,1) ;
        reqInt = TestBit(lcdStatus, 4) ;
    }
    else
    {
        int mode2Bounds = (RETRACE_START - 80) ;
        int mode3Bounds = (mode2Bounds - 172) ;
        
        
        // mode 2
        if (m_RetraceLY >= mode2Bounds)
        {
            mode = 2 ;
            lcdStatus = BitSet(lcdStatus,1) ;
            lcdStatus = BitReset(lcdStatus,0) ;
            reqInt = TestBit(lcdStatus,5) ;
        }
        // mode 3
        else if (m_RetraceLY >= mode3Bounds)
        {
            mode = 3 ;
            lcdStatus = BitSet(lcdStatus,1) ;
            lcdStatus = BitSet(lcdStatus,0) ;
        }
        // mode 3
        else
        {
            mode = 0 ;
            lcdStatus = BitReset(lcdStatus,1) ;
            lcdStatus = BitReset(lcdStatus,0) ;
            reqInt = TestBit(lcdStatus,3) ;
        }
        
    }
    
    // just entered a new mode. Request interupt
    if (reqInt && (currentMode != mode)){
        RequestInterupt(1) ;
    }
    
    // check for coincidence flag
    if ( lY == ReadMemory(0xFF45))
    {
        lcdStatus = BitSet(lcdStatus,2) ;
        
        if (TestBit(lcdStatus,6))
        {
            RequestInterupt(1) ;
        }
    }
    else
    {
        lcdStatus = BitReset(lcdStatus,2) ;
    }
    
    WriteByte(0xFF41, lcdStatus) ;
}

COLOUR GetColour(BYTE colourNum, WORD address)
{
    COLOUR res = WHITE ;
    BYTE palette = ReadMemory(address) ;
    int hi = 0 ;
    int lo = 0 ;
    
    // which bits of the colour palette does the colour id map to?
    switch (colourNum)
    {
        case 0: hi = 1 ; lo = 0 ;break ;
        case 1: hi = 3 ; lo = 2 ;break ;
        case 2: hi = 5 ; lo = 4 ;break ;
        case 3: hi = 7 ; lo = 6 ;break ;
    }
    
    // use the palette to get the colour
    int colour = 0;
    colour = BitGetVal(palette, hi) << 1;
    colour |= BitGetVal(palette, lo) ;
    
    // convert the game colour to emulator colour
    switch (colour)
    {
        case 0: res = WHITE ;break ;
        case 1: res = LIGHT_GRAY ;break ;
        case 2: res = DARK_GRAY ;break ;
        case 3: res = BLACK ;break ;
    }
    
    return res ;
}

//绘制背景
void RenderBackground(BYTE lcdControl)
{
    // lets draw the background (however it does need to be enabled)
    if (TestBit(lcdControl, 0)) { //background enable
        
        WORD tileData = 0 ;
        WORD backgroundMemory =0 ;
        bool unsig = true ;
        
        BYTE scrollY = ReadMemory(0xFF42) ;//ScrollY
        BYTE scrollX = ReadMemory(0xFF43) ;//ScrollX
        BYTE windowY = ReadMemory(0xFF4A) ;//WindowY
        BYTE windowX = ReadMemory(0xFF4B) - 7;//WindowX
        
        bool usingWindow = false ;
        
        if (TestBit(lcdControl,5))
        {
            if (windowY <= ReadMemory(0xFF44)) {//0xFF44 扫描线计数器
                usingWindow = true ;
            }
        }
        
        // which tile data are we using?
        if (TestBit(lcdControl,4))
        {
            tileData = 0x8000 ;
            unsig = true ;
        }
        else
        {
            tileData = 0x8800 ;
            unsig = false ;
        }
        
        // which background mem?
        if (false == usingWindow)
        {
            if (TestBit(lcdControl,3))
                backgroundMemory = 0x9C00 ;
            else
                backgroundMemory = 0x9800 ;
        }
        else
        {
            if (TestBit(lcdControl,6))
                backgroundMemory = 0x9C00 ;
            else
                backgroundMemory = 0x9800 ;
        }
        
        
        BYTE yPos = 0 ;
        
        if (!usingWindow)
            yPos = scrollY + ReadMemory(0xFF44) ;
        else
            yPos = ReadMemory(0xFF44) - windowY;
        
        WORD tileRow = (((BYTE)(yPos/8))*32) ;
        
        for (int pixel = 0 ; pixel < 160; pixel++)
        {
            BYTE xPos = pixel+scrollX ;
            
            if (usingWindow)
            {
                if (pixel >= windowX)
                {
                    xPos = pixel - windowX ;
                }
            }
            
            WORD tileCol = (xPos/8) ;
            SIGNED_WORD tileNum ;
            
            if(unsig)
                tileNum = (BYTE)ReadMemory(backgroundMemory+tileRow + tileCol) ;
            else
                tileNum = (SIGNED_BYTE)ReadMemory(backgroundMemory+tileRow + tileCol) ;
            
            WORD tileLocation = tileData ;
            
            if (unsig)
                tileLocation += (tileNum * 16) ;
            else
                tileLocation += ((tileNum+128) *16) ;
            
            BYTE line = yPos % 8 ;
            line *= 2;
            BYTE data1 = ReadMemory(tileLocation + line) ;
            BYTE data2 = ReadMemory(tileLocation + line + 1) ;
            
            int colourBit = xPos % 8 ;
            colourBit -= 7 ;
            colourBit *= -1 ;
            
            int colourNum = BitGetVal(data2,colourBit) ;
            colourNum <<= 1;
            colourNum |= BitGetVal(data1,colourBit) ;
            
            COLOUR col = GetColour(colourNum, 0xFF47) ;//bg palette
            int red = 0;
            int green = 0;
            int blue = 0;
            
            switch(col)
            {
                case WHITE:    red = 255; green = 255 ; blue = 255; break ;
                case LIGHT_GRAY:red = 0xCC; green = 0xCC ; blue = 0xCC; break ;
                case DARK_GRAY:    red = 0x77; green = 0x77 ; blue = 0x77; break ;
                default:break;
            }
            
            int finaly = ReadMemory(0xFF44) ;
            
            if ((finaly < 0) || (finaly > 143) || (pixel < 0) || (pixel > 159))
            {
                continue ;
            }
            
            m_ScreenData[finaly][pixel][0] = red ;
            m_ScreenData[finaly][pixel][1] = green ;
            m_ScreenData[finaly][pixel][2] = blue ;
        }
    }
}

//////////////////////////////////////////////////////////////////
//绘制精灵
void RenderSprites(BYTE lcdControl)
{
    // lets draw the sprites (however it does need to be enabled)
    if (TestBit(lcdControl, 1)) {//sprite enable
        
        bool use8x16 = false ;
        if (TestBit(lcdControl,2)) {
            use8x16 = true ;
        }
        
        for (int sprite = 0 ; sprite < 40; sprite++)
        {
            BYTE index = sprite*4 ;
            BYTE yPos = ReadMemory(0xFE00+index) - 16;
            BYTE xPos = ReadMemory(0xFE00+index+1) - 8;
            BYTE tileLocation = ReadMemory(0xFE00+index+2) ;
            BYTE attributes = ReadMemory(0xFE00+index+3) ;
            
            bool yFlip = TestBit(attributes,6) ;
            bool xFlip = TestBit(attributes,5) ;
            
            int scanline = ReadMemory(0xFF44);//当前扫描线
            
            int ysize = 8;
            if (use8x16){
                ysize = 16;
            }
            
            if ((scanline >= yPos) && (scanline < (yPos+ysize)))
            {
                int line = scanline - yPos ;
                
                if (yFlip){
                    line -= ysize ;
                    line *= -1 ;
                }
                
                line *= 2;
                BYTE data1 = ReadMemory( (0x8000 + (tileLocation * 16)) + line ) ;
                BYTE data2 = ReadMemory( (0x8000 + (tileLocation * 16)) + line + 1 ) ;
                
                for (int tilePixel = 7; tilePixel >= 0; tilePixel--)
                {
                    int colourbit = tilePixel ;
                    if (xFlip) {
                        colourbit -= 7 ;
                        colourbit *= -1 ;
                    }
                    int colourNum = BitGetVal(data2,colourbit) ;
                    colourNum <<= 1;
                    colourNum |= BitGetVal(data1,colourbit) ;
                    
                    COLOUR col = GetColour(colourNum, TestBit(attributes,4)?0xFF49:0xFF48);//sprite pallete
                    
                    // white is transparent for sprites.
                    if (col == WHITE){
                        continue ;
                    }
                    
                    int red = 0;
                    int green = 0;
                    int blue = 0;
                    
                    switch(col)
                    {
                        case WHITE:    red = 255; green = 255 ; blue = 255; break ;
                        case LIGHT_GRAY:red = 0xCC; green = 0xCC ; blue = 0xCC; break ;
                        case DARK_GRAY:    red = 0x77; green = 0x77 ; blue = 0x77; break ;
                        default:break;
                    }
                    
                    int xPix = 0 - tilePixel ;
                    xPix += 7 ;
                    
                    int pixel = xPos+xPix ;
                    
                    if ((scanline < 0) || (scanline > 143) || (pixel < 0) || (pixel > 159)){
                        continue ;
                    }
                    
                    // check if pixel is hidden behind background
                    if (TestBit(attributes, 7) == 1) {
                        if ( (m_ScreenData[scanline][pixel][0] != 255) || (m_ScreenData[scanline][pixel][1] != 255) || (m_ScreenData[scanline][pixel][2] != 255) ){
                            continue ;
                        }
                    }
                    
                    m_ScreenData[scanline][pixel][0] = red ;
                    m_ScreenData[scanline][pixel][1] = green ;
                    m_ScreenData[scanline][pixel][2] = blue ;
                    
                }
            }
        }
    }
}

//////////////////////////////////////////////////////////////////

void DrawScanLine( )
{
    BYTE lcdControl = ReadMemory(0xFF40) ;// LCD control register
    // we can only draw of the LCD is enabled
    if (TestBit(lcdControl, 7)) {
        RenderBackground( lcdControl ) ;
        RenderSprites( lcdControl ) ;
    }
}

void DrawCurrentLine( )
{
    if (!TestBit(ReadMemory(0xFF40), 7)){
        return ;
    }
    
    m_Rom[0xFF44]++ ;//扫描线计数器加 1
    m_RetraceLY = RETRACE_START ;//每条扫描线的cycle总数
    
    BYTE scanLine = ReadMemory(0xFF44) ;//当前扫描线
    
    if ( scanLine == VERTICAL_BLANK_SCAN_LINE) {
        IssueVerticalBlank( ) ;
    }
    
    if (scanLine > VERTICAL_BLANK_SCAN_LINE_MAX) {
        m_Rom[0xFF44] = 0 ;
    }
    
    if (scanLine < VERTICAL_BLANK_SCAN_LINE)
    {
        DrawScanLine( ) ;
    }
}

void DoInterupts( )
{
    // are interrupts enabled
    if (m_EnableInterupts) {//master interupt enabled switch
        BYTE requestFlag = ReadMemory(0xFF0F);//IF Interupt Request Register
        if (requestFlag > 0) {
            // which requested interrupt has the lowest priority?
            for (int bit = 0; bit < 8; bit++) {
                if (TestBit(requestFlag, bit)) {
                    // this interupt has been requested. But is it enabled?
                    BYTE enabledReg = ReadMemory(0xFFFF);//IE Interupt Enabled Register
                    if (TestBit(enabledReg, bit)) {
                        // do interrupts service
                        PushWordOntoStack(m_ProgramCounter) ;
                        m_Halted = false ;
                        char buffer[200] ;
                        sprintf(buffer, "servicing interupt %d", bit) ;
                        //printf("%s\n", buffer);
                        switch(bit) {
                            case 0: m_ProgramCounter = 0x40 ; break ;// V-Blank
                            case 1: m_ProgramCounter = 0x48 ; break ;// LCD-STATE
                            case 2: m_ProgramCounter = 0x50 ; break ;// Timer
                            case 4: m_ProgramCounter = 0x60 ; break ;// JoyPad
                            default: assert(false) ; break ;
                        }
                        m_EnableInterupts = false ;
                        m_Rom[0xFF0F] = BitReset(m_Rom[0xFF0F], bit) ;//IF
                    }
                }
            }
        }
    }
}

BYTE ExecuteNextOpcode( )
{
    
    BYTE opcode = m_Rom[m_ProgramCounter] ;
    
    if ((m_ProgramCounter >= 0x4000 && m_ProgramCounter <= 0x7FFF) || (m_ProgramCounter >= 0xA000 && m_ProgramCounter <= 0xBFFF)){
        opcode = ReadMemory(m_ProgramCounter) ;
    }
    
    if (!m_Halted)
    {
        m_ProgramCounter++ ;
        ExecuteOpcode( opcode ) ;
    }
    else
    {
        m_CyclesThisUpdate += 4;
    }
    
    // we are trying to disable interupts, however interupts get disabled after the next instruction
    // 0xF3 is the opcode for disabling interupt
    if (m_PendingInteruptDisabled)
    {
        if (ReadMemory(m_ProgramCounter-1) != 0xF3)
        {
            m_PendingInteruptDisabled = false ;
            m_EnableInterupts = false ;
        }
    }
    
    if (m_PendingInteruptEnabled)
    {
        if (ReadMemory(m_ProgramCounter-1) != 0xFB)
        {
            m_PendingInteruptEnabled = false ;
            m_EnableInterupts = true ;
        }
    }
    
    return opcode ;
}

void DoGraphics( int cycles )
{
    SetLCDStatus( ) ;
    
    if (TestBit(ReadMemory(0xFF40), 7)) {// LCD Display Enable
        m_RetraceLY -= cycles ;
    }
    
    if (m_Rom[0xFF44] > VERTICAL_BLANK_SCAN_LINE_MAX) {//153
        m_Rom[0xFF44] = 0 ;//扫描线计数器
    }
    
    if (m_RetraceLY <= 0) {//如果每条扫描线的cycle用完，则绘制
        DrawCurrentLine() ;
    }
}

void Update()
{
    m_CyclesThisUpdate = 0 ;
    const int m_TargetCycles = 70221 ;
    while ((m_CyclesThisUpdate < m_TargetCycles))//||(ReadMemory(0xFF44) < 144))
    {
        int currentCycle = m_CyclesThisUpdate ;
        ExecuteNextOpcode( ) ;
        int cycles = m_CyclesThisUpdate - currentCycle ;
        DoTimers( cycles ) ;
        DoGraphics( cycles ) ;
        DoInterupts( ) ;
    }
    
    m_RenderFunc() ;
}

void StopGame()
{
    m_GameLoaded = false ;
}

bool LoadRom(const char* romName)
{
    if (m_GameLoaded) StopGame( );
    
    m_GameLoaded = true ;
    
    memset(m_Rom,0,sizeof(m_Rom)) ;
    memset(m_GameBank,0,sizeof(m_GameBank)) ;
    
    FILE *in;
    in = fopen( romName, "rb" );
    fread(m_GameBank, 1, 0x200000, in);
    fclose(in);
    
    memcpy(m_Rom, m_GameBank, 0x8000) ;
    
    m_CurrentRomBank = 1;
    
    memset(m_RamBank,0,17) ;
    m_CurrentRamBank=0;
    
    return true ;
}

//////////////////////////////////////////////////////////////////

void CreateRamBanks(int numBanks)
{
    // DOES THE FIRST RAM BANK NEED TO BE SET TO THE CONTENTS of m_Rom[0xA000] - m_Rom[0xC000]?
    for (int i = 0; i < 17; i++) {//最大17个
        BYTE* ram = malloc(sizeof(BYTE)*0x2000) ;
        memset(ram, 0, sizeof(BYTE)*0x2000);
        m_RamBank[i] = ram;
    }
    
    //第0个ram_bank加载m_Rom的0xA000开始后的0x2000个字节
    for (int i = 0 ; i < 0x2000; i++){
        m_RamBank[0][i] = m_Rom[0xA000+i];
    }
}

void ResetScreen( )
{
    for (int x = 0 ; x < 144; x++)
    {
        for (int y = 0; y < 160; y++)
        {
            m_ScreenData[x][y][0] = 255 ;
            m_ScreenData[x][y][1] = 255 ;
            m_ScreenData[x][y][2] = 255 ;
        }
    }
}

//////////////////////////////////////////////////////////////////

bool ResetCPU( )
{
    ResetScreen( ) ;
    
    m_CurrentRamBank = 0 ;
    m_TimerVariable = 0 ;
    m_CurrentClockSpeed = 1024 ;
    m_DividerVariable = 0 ;
    m_Halted = false ;
    m_JoypadState = 0xFF ;
    m_CyclesThisUpdate = 0 ;
    
    m_ProgramCounter = 0x100 ;
    m_StackPointer.reg = 0xFFFE ;
    m_RegisterAF.hi = 0x01;//A
    m_RegisterAF.lo = 0xB0;//Flags
    m_RegisterBC.reg = 0x0013 ;
    m_RegisterDE.reg = 0x00D8 ;
    m_RegisterHL.reg = 0x014D ;
    
    m_Rom[0xFF00] = 0xFF ;
    m_Rom[0xFF05] = 0x00   ;
    m_Rom[0xFF06] = 0x00   ;
    m_Rom[0xFF07] = 0x00   ;
    m_Rom[0xFF10] = 0x80   ;
    m_Rom[0xFF11] = 0xBF   ;
    m_Rom[0xFF12] = 0xF3   ;
    m_Rom[0xFF14] = 0xBF   ;
    m_Rom[0xFF16] = 0x3F   ;
    m_Rom[0xFF17] = 0x00   ;
    m_Rom[0xFF19] = 0xBF   ;
    m_Rom[0xFF1A] = 0x7F   ;
    m_Rom[0xFF1B] = 0xFF   ;
    m_Rom[0xFF1C] = 0x9F   ;
    m_Rom[0xFF1E] = 0xBF   ;
    m_Rom[0xFF20] = 0xFF   ;
    m_Rom[0xFF21] = 0x00   ;
    m_Rom[0xFF22] = 0x00   ;
    m_Rom[0xFF23] = 0xBF   ;
    m_Rom[0xFF24] = 0x77   ;
    m_Rom[0xFF25] = 0xF3   ;
    m_Rom[0xFF26] = 0xF1   ;
    m_Rom[0xFF40] = 0x91   ;
    m_Rom[0xFF42] = 0x00   ;
    m_Rom[0xFF43] = 0x00   ;
    m_Rom[0xFF45] = 0x00   ;
    m_Rom[0xFF47] = 0xFC   ;
    m_Rom[0xFF48] = 0xFF   ;
    m_Rom[0xFF49] = 0xFF   ;
    m_Rom[0xFF4A] = 0x00   ;
    m_Rom[0xFF4B] = 0x00   ;
    m_Rom[0xFFFF] = 0x00   ;
    
    m_RetraceLY = RETRACE_START ;
    
    m_EnableRamBank = false ;
    
    m_UsingMBC1 = false;
    m_UsingMBC2 = false;
    // what kinda rom switching are we using, if any?
    switch(ReadMemory(0x147)) {
        case 0: m_UsingMBC1 = false ; break ; // not using any memory swapping
        case 1:
        case 2:
        case 3 : m_UsingMBC1 = true ; break ;
        case 5 : m_UsingMBC2 = true ; break ;
        case 6 : m_UsingMBC2 = true ; break ;
        default: return false ; // unhandled memory swappping, probably MBC2
    }
    
    // how many ram banks do we neeed, if any?
    int numRamBanks = 0 ;
    switch (ReadMemory(0x149)) {
        case 0: numRamBanks = 0 ;break ;
        case 1: numRamBanks = 1 ;break ;
        case 2: numRamBanks = 1 ;break ;
        case 3: numRamBanks = 4 ;break ;
        case 4: numRamBanks = 16 ;break ;
    }
    CreateRamBanks(numRamBanks) ;
    
    return true ;
}

bool InitGB(RenderFunc func)
{
    m_RenderFunc = func;
    return ResetCPU();
}
