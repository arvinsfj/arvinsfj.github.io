//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MasterSystem.rc
//
#define IDD_DIALOG1                     101
#define ID_DIALOG_MAIN                  101
#define ID_DIALOG_DEBUG                 102
#define IDSTART                         1001
#define IDC_LIST1                       1002
#define IDC_ROMLIST                     1002
#define IDC_MEM                         1002
#define IDSTEPINTO                      1003
#define IDSTEPOVER                      1004
#define IDC_EDIT1                       1005
#define IDC_RUNUNTIL                    1006
#define IDC_REGAF                       1008
#define IDC_REGBC                       1009
#define IDC_REGDE                       1010
#define IDC_REGHL                       1011
#define IDC_REGPC                       1012
#define IDC_REGSP                       1013
#define IDC_REGAFP                      1014
#define IDC_REGBCP                      1015
#define IDC_REGDEP                      1016
#define IDC_REGHLP                      1017
#define IDC_REGIX                       1018
#define IDC_REGIY                       1019
#define IDC_FLAGS                       1020
#define IDC_FLAGZ                       1021
#define IDC_FLAGB5                      1022
#define IDC_FLAGH                       1024
#define IDC_FLAGB3                      1025
#define IDC_FLAGPV                      1026
#define IDC_FLAGN                       1027
#define IDC_FLAGC                       1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
