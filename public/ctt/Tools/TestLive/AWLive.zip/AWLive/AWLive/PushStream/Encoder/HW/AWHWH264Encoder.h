/*
 copyright 2016 wanghongyu.
 The project page：https://github.com/hardman/AWLive
 My blog page: http://blog.csdn.net/hard_man/
 */

/*
 h264硬编码器
 */

#import "AWVideoEncoder.h"

@interface AWHWH264Encoder : AWVideoEncoder

@end
