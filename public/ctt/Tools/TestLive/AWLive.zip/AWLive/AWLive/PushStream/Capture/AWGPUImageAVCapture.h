/*
 copyright 2016 wanghongyu.
 The project page：https://github.com/hardman/AWLive
 My blog page: http://blog.csdn.net/hard_man/
 */

/*
 使用GPUImage进行音视频捕获，可以使用GPUImage美颜，或者其他滤镜效果。
 */

#import <Foundation/Foundation.h>
#import "AWAVCapture.h"

@interface AWGPUImageAVCapture : AWAVCapture
@end
