/*
 copyright 2016 wanghongyu.
 The project page：https://github.com/hardman/AWLive
 My blog page: http://blog.csdn.net/hard_man/
 */

/*
 aac软编码器(faac)
 */

#import "AWAudioEncoder.h"

@interface AWSWFaacEncoder : AWAudioEncoder

@end
