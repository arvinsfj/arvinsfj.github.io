/*
 copyright 2016 wanghongyu.
 The project page：https://github.com/hardman/AWLive
 My blog page: http://blog.csdn.net/hard_man/
 */

/*
 AAC硬编码器
 */

#import "AWAudioEncoder.h"

@interface AWHWAACEncoder : AWAudioEncoder

@end
