//
//  AppDelegate.h
//  AWLive
//
//  Created by wanghongyu on 5/11/16.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

