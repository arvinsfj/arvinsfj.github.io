/*
 copyright 2016 wanghongyu.
 The project page：https://github.com/hardman/AWLive
 My blog page: http://blog.csdn.net/hard_man/
 */

/*
 h264硬编码器
 */

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <VideoToolbox/VideoToolbox.h>
#include "aw_all.h"


@class AWAVCapture;
@interface AWHWH264Encoder : NSObject

@property (nonatomic, strong) AWAVCapture* capture;

-(aw_flv_video_tag *) encodeVideoSampleBufToFlvTag:(CMSampleBufferRef)videoSample;
-(aw_flv_video_tag *)createSpsPpsFlvTag;
- (void)open;
- (void)close;

@end
