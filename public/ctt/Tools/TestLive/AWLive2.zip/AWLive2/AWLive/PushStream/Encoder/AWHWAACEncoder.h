/*
 copyright 2016 wanghongyu.
 The project page：https://github.com/hardman/AWLive
 My blog page: http://blog.csdn.net/hard_man/
 */

/*
 AAC硬编码器
 */

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>
#include "aw_all.h"

@class AWAVCapture;
@interface AWHWAACEncoder : NSObject

@property (nonatomic, strong) AWAVCapture* capture;

-(aw_flv_audio_tag *) encodeAudioSampleBufToFlvTag:(CMSampleBufferRef)audioSample;
-(aw_flv_audio_tag *)createAudioSpecificConfigFlvTag;
- (void)open;
- (void)close;

@end
