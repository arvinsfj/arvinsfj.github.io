//
//  ViewController.h
//  AWLive
//
//  Created by wanghongyu on 5/11/16.
//
//

//注意：
//1. 竖屏
//2. 8.0
//3. disable bitcode
//4. search header & search library
//5. embeded library 添加 GpuImage
//6. ipv6
//7. info.plist NSCameraUsageDescription/NSMicrophoneUsageDescription/(ipv6还是https的那个)

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

