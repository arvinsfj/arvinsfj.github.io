/*
 copyright 2016 wanghongyu.
 The project page：https://github.com/hardman/AWLive
 My blog page: http://blog.csdn.net/hard_man/
 */

#import <Foundation/Foundation.h>
#import "ViewController.h"

@interface TestAVCapture : NSObject

-(instancetype) initWithViewController:(ViewController *)viewCtl;

-(void) onLayout;
@end
