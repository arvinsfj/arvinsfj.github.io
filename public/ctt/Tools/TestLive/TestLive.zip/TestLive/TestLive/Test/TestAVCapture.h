
#import <Foundation/Foundation.h>
#import "ViewController.h"

@interface TestAVCapture : NSObject

- (instancetype)initWithViewController:(ViewController *)viewCtl;
- (void)onLayout;

@end
