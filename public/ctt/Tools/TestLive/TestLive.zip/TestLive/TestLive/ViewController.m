//
//  ViewController.m
//  TestLive
//
//  Created by arvin on 2017/9/11.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import "ViewController.h"

#import "TestAVCapture.h"

@interface ViewController ()
@property (nonatomic, strong) TestAVCapture *testAVCapture;
@end

@implementation ViewController

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.testAVCapture = [[TestAVCapture alloc] initWithViewController:self];
    
    NSString* netStr = [[NSString alloc] initWithContentsOfURL:[NSURL URLWithString:@"http://www.baidu.com/"] encoding:NSUTF8StringEncoding error:nil];
    NSLog(@">>>>%@", netStr);
}

-(void)viewWillLayoutSubviews{
    [super viewWillLayoutSubviews];
    [self.testAVCapture onLayout];
}


@end
