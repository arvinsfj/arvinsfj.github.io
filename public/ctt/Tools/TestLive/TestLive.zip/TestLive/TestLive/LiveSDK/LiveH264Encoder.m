
#import "LiveH264Encoder.h"
#import "LiveAVCapture.h"

@interface LiveH264Encoder()

@property (nonatomic, unsafe_unretained) VTCompressionSessionRef vEnSession;
@property (nonatomic, strong) dispatch_semaphore_t vSemaphore;
@property (nonatomic, copy) NSData *spsPpsData;
@property (nonatomic, copy) NSData *naluData;
@property (nonatomic, unsafe_unretained) BOOL isKeyFrame;

@end

@implementation LiveH264Encoder

- (void)onErrorWithCode:(LiveEncoderErrorCode) code des:(NSString *)des
{
    aw_log("[ERROR] encoder error code:%ld des:%s", (unsigned long)code, des.UTF8String);
}

- (dispatch_semaphore_t)vSemaphore
{
    if (!_vSemaphore) {
        _vSemaphore = dispatch_semaphore_create(0);
    }
    return _vSemaphore;
}

- (aw_flv_video_tag *)encodeVideoSampleBufToFlvTag:(CMSampleBufferRef)videoSample
{
    return [self encodeYUVDataToFlvTag:[self convertVideoSmapleBufferToYuvData:videoSample]];
}

- (NSData *)convertVideoSmapleBufferToYuvData:(CMSampleBufferRef)videoSample
{
    CVImageBufferRef pixelBuffer = CMSampleBufferGetImageBuffer(videoSample);
    CVPixelBufferLockBaseAddress(pixelBuffer, 0);
    size_t pixelWidth = CVPixelBufferGetWidth(pixelBuffer);
    size_t pixelHeight = CVPixelBufferGetHeight(pixelBuffer);
    //yuv中的y所占字节数
    size_t y_size = pixelWidth * pixelHeight;
    size_t uv_size = y_size / 4;
    uint8_t *yuv_frame = aw_alloc(uv_size * 2 + y_size);
    uint8_t *y_frame = CVPixelBufferGetBaseAddressOfPlane(pixelBuffer, 0);
    memcpy(yuv_frame, y_frame, y_size);
    uint8_t *uv_frame = CVPixelBufferGetBaseAddressOfPlane(pixelBuffer, 1);
    memcpy(yuv_frame + y_size, uv_frame, uv_size * 2);
    CVPixelBufferUnlockBaseAddress(pixelBuffer, 0);
    NSData *nv12Data = [NSData dataWithBytesNoCopy:yuv_frame length:y_size + uv_size * 2];
    return nv12Data;
}

- (aw_flv_video_tag *)encodeYUVDataToFlvTag:(NSData *)yuvData
{
    if (!_vEnSession) {
        return NULL;
    }
    OSStatus status = noErr;
    size_t pixelWidth = 540;
    size_t pixelHeight = 960;
    CVPixelBufferRef pixelBuf = NULL;
    CVPixelBufferCreate(NULL, pixelWidth, pixelHeight, kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange, NULL, &pixelBuf);
    if(CVPixelBufferLockBaseAddress(pixelBuf, 0) != kCVReturnSuccess){
        [self onErrorWithCode:AWEncoderErrorCodeLockSampleBaseAddressFailed des:@"encode video lock base address failed"];
        return NULL;
    }
    size_t y_size = aw_stride(pixelWidth) * pixelHeight;
    size_t uv_size = y_size / 4;
    uint8_t *yuv_frame = (uint8_t *)yuvData.bytes;
    uint8_t *y_frame = CVPixelBufferGetBaseAddressOfPlane(pixelBuf, 0);
    memcpy(y_frame, yuv_frame, y_size);
    uint8_t *uv_frame = CVPixelBufferGetBaseAddressOfPlane(pixelBuf, 1);
    memcpy(uv_frame, yuv_frame + y_size, uv_size * 2);
    uint32_t ptsMs = _capture.timestamp + 1; //self.vFrameCount++ * 1000.f / self.videoConfig.fps;
    CMTime pts = CMTimeMake(ptsMs, 1000);
    
    status = VTCompressionSessionEncodeFrame(_vEnSession, pixelBuf, pts, kCMTimeInvalid, NULL, pixelBuf, NULL);
    
    if (status == noErr) {
        dispatch_semaphore_wait(self.vSemaphore, DISPATCH_TIME_FOREVER);
        if (_naluData) {
            uint32_t naluLen = (uint32_t)_naluData.length;
            uint8_t naluLenArr[4] = {naluLen >> 24 & 0xff, naluLen >> 16 & 0xff, naluLen >> 8 & 0xff, naluLen & 0xff};
            NSMutableData *mutableData = [NSMutableData dataWithBytes:naluLenArr length:4];
            [mutableData appendData:_naluData];
            aw_flv_video_tag *video_tag = aw_encoder_create_video_tag((int8_t *)mutableData.bytes, mutableData.length, ptsMs, 0, self.isKeyFrame);
            _naluData = nil;
            _isKeyFrame = NO;
            CVPixelBufferUnlockBaseAddress(pixelBuf, 0);
            CFRelease(pixelBuf);
            return video_tag;
        }
    }else{
        [self onErrorWithCode:AWEncoderErrorCodeEncodeVideoFrameFailed des:@"encode video frame error"];
    }
    CVPixelBufferUnlockBaseAddress(pixelBuf, 0);
    CFRelease(pixelBuf);
    return NULL;
}

- (aw_flv_video_tag *)createSpsPpsFlvTag
{
    while(!self.spsPpsData) {
        dispatch_semaphore_wait(self.vSemaphore, DISPATCH_TIME_FOREVER);
    }
    aw_data *sps_pps_data = alloc_aw_data((uint32_t)self.spsPpsData.length);
    memcpy_aw_data(&sps_pps_data, (uint8_t *)self.spsPpsData.bytes, (uint32_t)self.spsPpsData.length);
    aw_flv_video_tag *sps_pps_tag = aw_encoder_create_sps_pps_tag(sps_pps_data);
    free_aw_data(&sps_pps_data);
    return sps_pps_tag;
}

static void vtCompressionSessionCallback (void * CM_NULLABLE outputCallbackRefCon,
                                          void * CM_NULLABLE sourceFrameRefCon,
                                          OSStatus status,
                                          VTEncodeInfoFlags infoFlags,
                                          CM_NULLABLE CMSampleBufferRef sampleBuffer)
{
    LiveH264Encoder *encoder = (__bridge LiveH264Encoder *)(outputCallbackRefCon);
    if (status != noErr) {
        dispatch_semaphore_signal(encoder.vSemaphore);
        [encoder onErrorWithCode:AWEncoderErrorCodeEncodeVideoFrameFailed des:@"encode video frame error 1"];
        return;
    }
    if (!CMSampleBufferDataIsReady(sampleBuffer)) {
        dispatch_semaphore_signal(encoder.vSemaphore);
        [encoder onErrorWithCode:AWEncoderErrorCodeEncodeVideoFrameFailed des:@"encode video frame error 2"];
        return;
    }
    BOOL isKeyFrame = !CFDictionaryContainsKey( (CFArrayGetValueAtIndex(CMSampleBufferGetSampleAttachmentsArray(sampleBuffer, true), 0)), kCMSampleAttachmentKey_NotSync);
    
    BOOL needSpsPps = NO;
    if (!encoder.spsPpsData) {
        if (isKeyFrame) {
            CMFormatDescriptionRef sampleBufFormat = CMSampleBufferGetFormatDescription(sampleBuffer);
            NSDictionary *dict = (__bridge NSDictionary *)CMFormatDescriptionGetExtensions(sampleBufFormat);
            encoder.spsPpsData = dict[@"SampleDescriptionExtensionAtoms"][@"avcC"];
        }
        needSpsPps = YES;
    }

    CMBlockBufferRef blockBuffer = CMSampleBufferGetDataBuffer(sampleBuffer);
    size_t blockDataLen;
    uint8_t *blockData;
    status = CMBlockBufferGetDataPointer(blockBuffer, 0, NULL, &blockDataLen, (char **)&blockData);
    if (status == noErr) {
        size_t currReadPos = 0;
        while (currReadPos < blockDataLen - 4) {
            uint32_t naluLen = 0;
            memcpy(&naluLen, blockData + currReadPos, 4);
            naluLen = CFSwapInt32BigToHost(naluLen);
            encoder.naluData = [NSData dataWithBytes:blockData + currReadPos + 4 length:naluLen];
            currReadPos += 4 + naluLen;
            encoder.isKeyFrame = isKeyFrame;
        }
    }else{
        [encoder onErrorWithCode:AWEncoderErrorCodeEncodeGetH264DataFailed des:@"got h264 data failed"];
    }
    dispatch_semaphore_signal(encoder.vSemaphore);
    if (needSpsPps) {
        dispatch_semaphore_signal(encoder.vSemaphore);
    }
}

- (void)open
{
    OSStatus status = VTCompressionSessionCreate(NULL, 540, 960, kCMVideoCodecType_H264, NULL, NULL, NULL, vtCompressionSessionCallback, (__bridge void * _Nullable)(self), &_vEnSession);
    if (status == noErr) {
        VTSessionSetProperty(_vEnSession, kVTCompressionPropertyKey_ProfileLevel, kVTProfileLevel_H264_Main_AutoLevel);
        VTSessionSetProperty(_vEnSession, kVTCompressionPropertyKey_AverageBitRate, (__bridge CFTypeRef)@(1000000));
        VTSessionSetProperty(_vEnSession, kVTCompressionPropertyKey_RealTime, kCFBooleanTrue);
        VTSessionSetProperty(_vEnSession, kVTCompressionPropertyKey_AllowFrameReordering, kCFBooleanFalse);
        VTSessionSetProperty(_vEnSession, kVTCompressionPropertyKey_MaxKeyFrameInterval, (__bridge CFTypeRef)@(20 * 2));
        status = VTCompressionSessionPrepareToEncodeFrames(_vEnSession);
        if (status != noErr) {
            [self onErrorWithCode:AWEncoderErrorCodeVTSessionPrepareFailed des:@"硬编码vtsession prepare失败"];
        }
    }else{
        [self onErrorWithCode:AWEncoderErrorCodeVTSessionCreateFailed des:@"硬编码vtsession创建失败"];
    }
}

- (void)close
{
    dispatch_semaphore_signal(self.vSemaphore);
    VTCompressionSessionInvalidate(_vEnSession);
    _vEnSession = nil;
    self.naluData = nil;
    self.isKeyFrame = NO;
    self.spsPpsData = nil;
}

@end
