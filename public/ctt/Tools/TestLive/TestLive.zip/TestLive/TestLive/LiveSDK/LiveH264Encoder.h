//
//  LiveH264Encoder.h
//  TestLive
//
//  Created by arvin on 2017/9/11.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <VideoToolbox/VideoToolbox.h>
#include "aw_all.h"

#import "LiveAVCapture.h"

@interface LiveH264Encoder : NSObject

@property (nonatomic, strong) LiveAVCapture* capture;

- (aw_flv_video_tag *)encodeVideoSampleBufToFlvTag:(CMSampleBufferRef)videoSample;
- (aw_flv_video_tag *)createSpsPpsFlvTag;
-(void)open;
-(void)close;

@end
