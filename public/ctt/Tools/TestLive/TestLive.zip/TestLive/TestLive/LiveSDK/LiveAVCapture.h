
/*
 音视频捕获。将捕获的音/视频数据送入 encodeSampleQueue串行队列进行编码，然后送入sendSampleQueue队列发送至rtmp接口。
 */

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#include "aw_all.h"

typedef enum : NSUInteger {
    AWEncoderErrorCodeVTSessionCreateFailed,
    AWEncoderErrorCodeVTSessionPrepareFailed,
    AWEncoderErrorCodeLockSampleBaseAddressFailed,
    AWEncoderErrorCodeEncodeVideoFrameFailed,
    AWEncoderErrorCodeEncodeCreateBlockBufFailed,
    AWEncoderErrorCodeEncodeCreateSampleBufFailed,
    AWEncoderErrorCodeEncodeGetSpsPpsFailed,
    AWEncoderErrorCodeEncodeGetH264DataFailed,
    
    AWEncoderErrorCodeCreateAudioConverterFailed,
    AWEncoderErrorCodeAudioConverterGetMaxFrameSizeFailed,
    AWEncoderErrorCodeAudioEncoderFailed,
} LiveEncoderErrorCode;

@class LiveAVCapture;
@protocol LiveAVCaptureDelegate <NSObject>

- (void)avCapture:(LiveAVCapture *)capture stateChangeFrom:(aw_rtmp_state)fromState toState:(aw_rtmp_state)toState;

@end

@interface LiveAVCapture : NSObject

//时间戳
@property (nonatomic, assign) uint32_t timestamp;

//状态变化回调
@property (nonatomic, weak) id<LiveAVCaptureDelegate> stateDelegate;

//是否将数据发送出去
@property (nonatomic, unsafe_unretained) BOOL isCapturing;

//预览view
@property (nonatomic, strong) UIView *preview;

//初始化
- (instancetype)init;

//切换摄像头
- (void)switchCamera;

//停止capture
- (void)stopCapture;

//开始capture
- (BOOL)startCaptureWithRtmpUrl:(NSString *)rtmpUrl;

@end
