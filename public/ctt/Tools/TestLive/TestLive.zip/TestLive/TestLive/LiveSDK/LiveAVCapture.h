//
//  LiveAVCapture.h
//  TestLive
//
//  Created by arvin on 2017/9/11.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "aw_all.h"

enum: NSUInteger {
    AWEncoderErrorCodeVTSessionCreateFailed,
    AWEncoderErrorCodeVTSessionPrepareFailed,
    AWEncoderErrorCodeLockSampleBaseAddressFailed,
    AWEncoderErrorCodeEncodeVideoFrameFailed,
    AWEncoderErrorCodeEncodeCreateBlockBufFailed,
    AWEncoderErrorCodeEncodeCreateSampleBufFailed,
    AWEncoderErrorCodeEncodeGetSpsPpsFailed,
    AWEncoderErrorCodeEncodeGetH264DataFailed,
    
    AWEncoderErrorCodeCreateAudioConverterFailed,
    AWEncoderErrorCodeAudioConverterGetMaxFrameSizeFailed,
    AWEncoderErrorCodeAudioEncoderFailed,
};

//rtmp状态回调
extern void aw_rtmp_state_changed_cb_in_oc(aw_rtmp_state old_state, aw_rtmp_state new_state);

@class LiveAVCapture;
@protocol LiveAVCaptureDelegate <NSObject>
-(void) avCapture:(LiveAVCapture *)capture stateChangeFrom:(aw_rtmp_state) fromState toState:(aw_rtmp_state) toState;
@end

@interface LiveAVCapture : NSObject

@property (nonatomic, unsafe_unretained) uint32_t timestamp;

//判断是否开始capture
@property (nonatomic, assign) BOOL isCapturing;

@property (nonatomic, strong) id<LiveAVCaptureDelegate> stateDelegate;

- (instancetype)initWithPreView:(UIView*)preview;
- (void)startCapture;
- (void)stopCapture;

@end
