//
//  LiveAVCapture.m
//  TestLive
//
//  Created by arvin on 2017/9/11.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import "LiveAVCapture.h"

#import "LiveAACEncoder.h"
#import "LiveH264Encoder.h"

@interface LiveAVCapture ()<AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureAudioDataOutputSampleBufferDelegate>
//数据输入设备
@property (nonatomic, strong) AVCaptureDeviceInput *videoInputDevice;//默认后置摄像头
@property (nonatomic, strong) AVCaptureDeviceInput *audioInputDevice;

//输出数据接收
@property (nonatomic, strong) AVCaptureVideoDataOutput *videoDataOutput;
@property (nonatomic, strong) AVCaptureAudioDataOutput *audioDataOutput;
//会话
@property (nonatomic, strong) AVCaptureSession *captureSession;
//预览
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *previewLayer;

//音视频编码和RTMP发送相关
//数据编码队列和发送队列
@property (nonatomic, strong) dispatch_queue_t encodeSampleQueue;
@property (nonatomic, strong) dispatch_queue_t sendSampleQueue;
//RTMP地址
@property (nonatomic, strong) NSString *rtmpUrl;
//是否已发送了sps/pps
@property (nonatomic, unsafe_unretained) BOOL isSpsPpsAndAudioSpecificConfigSent;
//音视频编码
@property (nonatomic, strong) LiveH264Encoder* videoEncoder;//h264硬编码器
@property (nonatomic, strong) LiveAACEncoder* audioEncoder;//acc硬编码器


@end

@implementation LiveAVCapture

__weak static LiveAVCapture *sAWAVCapture = nil;

extern void aw_rtmp_state_changed_cb_in_oc(aw_rtmp_state old_state, aw_rtmp_state new_state){
    NSLog(@"[OC] rtmp state changed from(%s), to(%s)", aw_rtmp_state_description(old_state), aw_rtmp_state_description(new_state));
    dispatch_async(dispatch_get_main_queue(), ^{
        [sAWAVCapture.stateDelegate avCapture:sAWAVCapture stateChangeFrom:old_state toState:new_state];
    });
}

- (instancetype)initWithPreView:(UIView*)preview
{
    if (self = [super init]) {
        [self initCaptureWithPreView:preview];
        [self initEncoder];
    }
    return self;
}

//初始化编码器
- (void)initEncoder
{
    self.encodeSampleQueue = dispatch_queue_create("aw.encode.queue", DISPATCH_QUEUE_SERIAL);
    self.sendSampleQueue = dispatch_queue_create("aw.send.queue", DISPATCH_QUEUE_SERIAL);
    self.rtmpUrl = @"rtmp://192.168.2.2:9997/rtmplive/room";
    self.isSpsPpsAndAudioSpecificConfigSent = NO;
    
    self.videoEncoder = [[LiveH264Encoder alloc] init];
    self.audioEncoder = [[LiveAACEncoder alloc] init];
}

//初始化音视频的捕获
- (void)initCaptureWithPreView:(UIView*)preview
{
    //创建输入设备
    self.videoInputDevice = [AVCaptureDeviceInput deviceInputWithDevice:[AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo] error:nil];
    self.audioInputDevice = [AVCaptureDeviceInput deviceInputWithDevice:[AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeAudio] error:nil];
    //创建输出接收
    self.videoDataOutput = [[AVCaptureVideoDataOutput alloc] init];
    [self.videoDataOutput setSampleBufferDelegate:self queue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
    self.videoDataOutput.alwaysDiscardsLateVideoFrames = YES;
    self.videoDataOutput.videoSettings = @{(__bridge NSString *)kCVPixelBufferPixelFormatTypeKey:@(kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange)};
    self.audioDataOutput = [[AVCaptureAudioDataOutput alloc] init];
    [self.audioDataOutput setSampleBufferDelegate:self queue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
    //创建会话
    self.captureSession = [[AVCaptureSession alloc] init];
    [self.captureSession beginConfiguration];
    //
    [self.captureSession addInput:self.videoInputDevice];
    [self.captureSession addInput:self.audioInputDevice];
    [self.captureSession addOutput:self.videoDataOutput];
    [self.captureSession addOutput:self.audioDataOutput];
    for (AVCaptureConnection *conn in self.videoDataOutput.connections) {
        if (conn.isVideoStabilizationSupported) {
            [conn setPreferredVideoStabilizationMode:AVCaptureVideoStabilizationModeAuto];
        }
        if (conn.isVideoOrientationSupported) {
            [conn setVideoOrientation:AVCaptureVideoOrientationPortrait];
        }
        if (conn.isVideoMirrored) {
            [conn setVideoMirrored: YES];
        }
    }
    self.captureSession.sessionPreset = AVCaptureSessionPreset640x480;
    [self.captureSession commitConfiguration];
    //创建视频预览层
    self.previewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:self.captureSession];
    self.previewLayer.frame = preview.bounds;
    if (preview) {
        [preview.layer addSublayer:self.previewLayer];
    }
    [self updateFps:20];//20fps
}

- (void)updateFps:(NSInteger)fps
{
    AVCaptureDevice *videoDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    float maxRate = [(AVFrameRateRange *)[videoDevice.activeFormat.videoSupportedFrameRateRanges objectAtIndex:0] maxFrameRate];
    if (maxRate >= fps) {
        if ([videoDevice lockForConfiguration:NULL]) {
            videoDevice.activeVideoMinFrameDuration = CMTimeMake(10, (int)(fps * 10));
            videoDevice.activeVideoMaxFrameDuration = videoDevice.activeVideoMinFrameDuration;
            [videoDevice unlockForConfiguration];
        }
    }
}

- (void)startCapture
{
    if (self.captureSession) {
        __weak typeof(self) weakSelf = self;
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            //先开启encoder
            [_videoEncoder open];
            [_audioEncoder open];
            //再打开rtmp
            int retcode = aw_streamer_open(_rtmpUrl.UTF8String, aw_rtmp_state_changed_cb_in_oc);
            if(retcode){
                [weakSelf.captureSession startRunning];
                weakSelf.isCapturing = YES;
            }else{
                NSLog(@"startCapture rtmpOpen error!!! retcode=%d", retcode);
                [weakSelf stopCapture];
            }
        });
    }
}

- (void)stopCapture
{
    if (self.captureSession) {
        [self.captureSession stopRunning];
        self.isCapturing = NO;
        self.isSpsPpsAndAudioSpecificConfigSent = NO;
        dispatch_sync(self.sendSampleQueue, ^{
            aw_streamer_close();
        });
        dispatch_sync(self.encodeSampleQueue, ^{
            [_videoEncoder close];
            [_audioEncoder close];
        });
    }
}

- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection{
    if (self.isCapturing) {
        if ([self.videoDataOutput isEqual:captureOutput]) {
            [self sendVideoSampleBuffer:sampleBuffer];
        }else if([self.audioDataOutput isEqual:captureOutput]){
            [self sendAudioSampleBuffer:sampleBuffer];
        }
    }
}

//使用rtmp协议发送数据
- (void)sendVideoSampleBuffer:(CMSampleBufferRef)sampleBuffer
{
    CFRetain(sampleBuffer);
    __weak typeof(self) weakSelf = self;
    dispatch_async(_encodeSampleQueue, ^{
        if (weakSelf.isCapturing) {
            aw_flv_video_tag *video_tag = [weakSelf.videoEncoder encodeVideoSampleBufToFlvTag:sampleBuffer];
            [weakSelf sendFlvVideoTag:video_tag];
        }
        CFRelease(sampleBuffer);
    });
}
- (void)sendAudioSampleBuffer:(CMSampleBufferRef)sampleBuffer
{
    CFRetain(sampleBuffer);
    __weak typeof(self) weakSelf = self;
    dispatch_async(_encodeSampleQueue, ^{
        if (weakSelf.isCapturing) {
            aw_flv_audio_tag *audio_tag = [weakSelf.audioEncoder encodeAudioSampleBufToFlvTag:sampleBuffer];
            [weakSelf sendFlvAudioTag:audio_tag];
        }
        CFRelease(sampleBuffer);
    });
}

- (void)sendFlvVideoTag:(aw_flv_video_tag *)video_tag
{
    __weak typeof(self) weakSelf = self;
    if (video_tag) {
        dispatch_async(_sendSampleQueue, ^{
            if(weakSelf.isCapturing){
                if (!weakSelf.isSpsPpsAndAudioSpecificConfigSent) {
                    [weakSelf sendSpsPpsAndAudioSpecificConfigTagToSendQueue:_sendSampleQueue];
                    free_aw_flv_video_tag((aw_flv_video_tag **)&video_tag);
                }else{
                    aw_streamer_send_video_data(video_tag);
                }
            }
        });
    }
}

- (void)sendFlvAudioTag:(aw_flv_audio_tag *)audio_tag
{
    __weak typeof(self) weakSelf = self;
    if(audio_tag){
        dispatch_async(_sendSampleQueue, ^{
            if(weakSelf.isCapturing){
                if (!weakSelf.isSpsPpsAndAudioSpecificConfigSent) {
                    [weakSelf sendSpsPpsAndAudioSpecificConfigTagToSendQueue:_sendSampleQueue];
                    free_aw_flv_audio_tag((aw_flv_audio_tag **)&audio_tag);
                }else{
                    aw_streamer_send_audio_data(audio_tag);
                }
            }
        });
    }
}

-(void) sendSpsPpsAndAudioSpecificConfigTagToSendQueue:(dispatch_queue_t)sendQueue
{
    if (self.isSpsPpsAndAudioSpecificConfigSent) {
        return;
    }
    __weak typeof(self) weakSelf = self;
    dispatch_async(sendQueue, ^{
        if (!weakSelf.isCapturing || weakSelf.isSpsPpsAndAudioSpecificConfigSent) {
            return;
        }
        //video sps pps tag
        aw_flv_video_tag *spsPpsTag = [weakSelf.videoEncoder createSpsPpsFlvTag];
        if (spsPpsTag) {
            aw_streamer_send_video_sps_pps_tag(spsPpsTag);
        }
        //audio specific config tag
        aw_flv_audio_tag *audioSpecificConfigTag = [weakSelf.audioEncoder createAudioSpecificConfigFlvTag];
        if (audioSpecificConfigTag) {
            aw_streamer_send_audio_specific_config_tag(audioSpecificConfigTag);
        }
        weakSelf.isSpsPpsAndAudioSpecificConfigSent = spsPpsTag || audioSpecificConfigTag;
        
        aw_log("[D] is sps pps and audio sepcific config sent=%d", weakSelf.isSpsPpsAndAudioSpecificConfigSent);
    });
}

@end
