
#import "LiveAVCapture.h"

#import "LiveAACEncoder.h"
#import "LiveH264Encoder.h"

__weak static LiveAVCapture *sAWAVCapture = nil;
extern void aw_rtmp_state_changed_cb_in_oc(aw_rtmp_state old_state, aw_rtmp_state new_state)
{
    NSLog(@"[OC] rtmp state changed from(%s), to(%s)", aw_rtmp_state_description(old_state), aw_rtmp_state_description(new_state));
    dispatch_async(dispatch_get_main_queue(), ^{
        [sAWAVCapture.stateDelegate liveCapture:sAWAVCapture stateChangeFrom:old_state toState:new_state];
    });
}

@interface LiveAVCapture()<AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureAudioDataOutputSampleBufferDelegate>

//编码队列，发送队列
@property (nonatomic, strong) dispatch_queue_t encodeSampleQueue;
@property (nonatomic, strong) dispatch_queue_t sendSampleQueue;

//编码器
@property (nonatomic, strong) LiveH264Encoder *videoEncoder;
@property (nonatomic, strong) LiveAACEncoder *audioEncoder;

//是否已发送了sps/pps
@property (nonatomic, unsafe_unretained) BOOL isSpsPpsAndAudioSpecificConfigSent;

//前后摄像头
@property (nonatomic, strong) AVCaptureDeviceInput *frontCamera;
@property (nonatomic, strong) AVCaptureDeviceInput *backCamera;
//当前使用的视频设备
@property (nonatomic, weak) AVCaptureDeviceInput *videoInputDevice;
@property (nonatomic, strong) AVCaptureDeviceInput *audioInputDevice;
//输出数据接收
@property (nonatomic, strong) AVCaptureVideoDataOutput *videoDataOutput;
@property (nonatomic, strong) AVCaptureAudioDataOutput *audioDataOutput;
//会话
@property (nonatomic, strong) AVCaptureSession *captureSession;
//预览
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *previewLayer;

@end

@implementation LiveAVCapture

- (dispatch_queue_t)encodeSampleQueue
{
    if (!_encodeSampleQueue) {
        _encodeSampleQueue = dispatch_queue_create("aw.encodesample.queue", DISPATCH_QUEUE_SERIAL);
    }
    return _encodeSampleQueue;
}

- (dispatch_queue_t)sendSampleQueue
{
    if (!_sendSampleQueue) {
        _sendSampleQueue = dispatch_queue_create("aw.sendsample.queue", DISPATCH_QUEUE_SERIAL);
    }
    return _sendSampleQueue;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        sAWAVCapture = self;
        [self createCaptureDevice];
        [self createOutput];
        [self createCaptureSession];
        [self createPreviewLayer];
        //更新fps
        [self updateFps: 20];
    }
    return self;
}

//修改fps
- (void)updateFps:(NSInteger)fps
{
    NSArray *videoDevices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    
    for (AVCaptureDevice *vDevice in videoDevices) {
        float maxRate = [(AVFrameRateRange *)[vDevice.activeFormat.videoSupportedFrameRateRanges objectAtIndex:0] maxFrameRate];
        if (maxRate >= fps) {
            if ([vDevice lockForConfiguration:NULL]) {
                vDevice.activeVideoMinFrameDuration = CMTimeMake(10, (int)(fps * 10));
                vDevice.activeVideoMaxFrameDuration = vDevice.activeVideoMinFrameDuration;
                [vDevice unlockForConfiguration];
            }
        }
    }
}

- (void)switchCamera
{
    if ([self.videoInputDevice isEqual: self.frontCamera]) {
        self.videoInputDevice = self.backCamera;
    }else{
        self.videoInputDevice = self.frontCamera;
    }
    //更新fps
    [self updateFps: 20];
}

- (BOOL)startCaptureWithRtmpUrl:(NSString *)rtmpUrl
{
    if (!rtmpUrl || rtmpUrl.length < 8) {
        NSLog(@"rtmpUrl is nil when start capture");
        return NO;
    }
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        //先开启encoder
        weakSelf.audioEncoder = [[LiveAACEncoder alloc] init];
        weakSelf.videoEncoder = [[LiveH264Encoder alloc] init];
        weakSelf.audioEncoder.capture = weakSelf;
        weakSelf.videoEncoder.capture = weakSelf;
        [weakSelf.audioEncoder open];
        [weakSelf.videoEncoder open];
        //再打开rtmp
        int retcode = aw_streamer_open(rtmpUrl.UTF8String, aw_rtmp_state_changed_cb_in_oc);
        if(retcode){
            weakSelf.isCapturing = YES;
        }else{
            NSLog(@"startCapture rtmpOpen error!!! retcode=%d", retcode);
            [weakSelf stopCapture];
        }
    });
    return YES;
}

- (void)stopCapture
{
    self.isCapturing = NO;
    self.isSpsPpsAndAudioSpecificConfigSent = NO;
    __weak typeof(self) weakSelf = self;
    dispatch_sync(self.sendSampleQueue, ^{
        aw_streamer_close();
    });
    dispatch_sync(self.encodeSampleQueue, ^{
        [weakSelf.audioEncoder close];
        [weakSelf.videoEncoder close];
        weakSelf.audioEncoder = nil;
        weakSelf.videoEncoder = nil;
        weakSelf.timestamp = 0;
    });
}

- (UIView *)preview
{
    if (!_preview) {
        _preview = [UIView new];
        _preview.bounds = [UIScreen mainScreen].bounds;
    }
    return _preview;
}

//初始化视频设备
- (void)createCaptureDevice
{
    //创建视频设备
    NSArray *videoDevices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    //初始化摄像头
    self.frontCamera = [AVCaptureDeviceInput deviceInputWithDevice:videoDevices.firstObject error:nil];
    self.backCamera =[AVCaptureDeviceInput deviceInputWithDevice:videoDevices.lastObject error:nil];
    
    //麦克风
    AVCaptureDevice *audioDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeAudio];
    self.audioInputDevice = [AVCaptureDeviceInput deviceInputWithDevice:audioDevice error:nil];
    
    self.videoInputDevice = self.frontCamera;
}

//切换摄像头
- (void)setVideoInputDevice:(AVCaptureDeviceInput *)videoInputDevice
{
    if ([videoInputDevice isEqual:_videoInputDevice]) {
        return;
    }
    //modifyinput
    [self.captureSession beginConfiguration];
    if (_videoInputDevice) {
        [self.captureSession removeInput:_videoInputDevice];
    }
    if (videoInputDevice) {
        [self.captureSession addInput:videoInputDevice];
    }
    
    [self setVideoOutConfig];
    
    [self.captureSession commitConfiguration];
    
    _videoInputDevice = videoInputDevice;
}

//创建预览
- (void)createPreviewLayer
{
    self.previewLayer = [AVCaptureVideoPreviewLayer layerWithSession:self.captureSession];
    self.previewLayer.frame = self.preview.bounds;
    [self.preview.layer addSublayer:self.previewLayer];
}

- (void)setVideoOutConfig
{
    for (AVCaptureConnection *conn in self.videoDataOutput.connections) {
        if (conn.isVideoStabilizationSupported) {
            [conn setPreferredVideoStabilizationMode:AVCaptureVideoStabilizationModeAuto];
        }
        if (conn.isVideoOrientationSupported) {
            [conn setVideoOrientation:AVCaptureVideoOrientationPortrait];
        }
        if (conn.isVideoMirrored) {
            [conn setVideoMirrored: YES];
        }
    }
}

//创建会话
- (void)createCaptureSession
{
    self.captureSession = [AVCaptureSession new];
    
    [self.captureSession beginConfiguration];
    
    if ([self.captureSession canAddInput:self.videoInputDevice]) {
        [self.captureSession addInput:self.videoInputDevice];
    }
    
    if ([self.captureSession canAddInput:self.audioInputDevice]) {
        [self.captureSession addInput:self.audioInputDevice];
    }
    
    if([self.captureSession canAddOutput:self.videoDataOutput]){
        [self.captureSession addOutput:self.videoDataOutput];
        [self setVideoOutConfig];
    }
    
    if([self.captureSession canAddOutput:self.audioDataOutput]){
        [self.captureSession addOutput:self.audioDataOutput];
    }
    
    self.captureSession.sessionPreset = AVCaptureSessionPresetiFrame960x540;
    
    [self.captureSession commitConfiguration];
    
    [self.captureSession startRunning];
}

- (void)createOutput
{
    dispatch_queue_t captureQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    self.videoDataOutput = [[AVCaptureVideoDataOutput alloc] init];
    [self.videoDataOutput setSampleBufferDelegate:self queue:captureQueue];
    [self.videoDataOutput setAlwaysDiscardsLateVideoFrames:YES];
    [self.videoDataOutput setVideoSettings:@{(__bridge NSString *)kCVPixelBufferPixelFormatTypeKey:@(kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange)}];
    
    self.audioDataOutput = [[AVCaptureAudioDataOutput alloc] init];
    [self.audioDataOutput setSampleBufferDelegate:self queue:captureQueue];
}

//音视频捕获到音视频硬编码和RTMP发送的连接点
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection
{
    if (self.isCapturing) {
        if ([self.videoDataOutput isEqual:captureOutput]) {
            [self sendVideoSampleBuffer:sampleBuffer];
        }else if([self.audioDataOutput isEqual:captureOutput]){
            [self sendAudioSampleBuffer:sampleBuffer];
        }
    }
}

//使用rtmp协议发送数据
- (void)sendVideoSampleBuffer:(CMSampleBufferRef)sampleBuffer
{
    CFRetain(sampleBuffer);
    __weak typeof(self) weakSelf = self;
    dispatch_async(self.encodeSampleQueue, ^{
        if (weakSelf.isCapturing) {
            aw_flv_video_tag *video_tag = [weakSelf.videoEncoder encodeVideoSampleBufToFlvTag:sampleBuffer];
            [weakSelf sendFlvVideoTag:video_tag];
        }
        CFRelease(sampleBuffer);
    });
}

- (void)sendAudioSampleBuffer:(CMSampleBufferRef)sampleBuffer
{
    CFRetain(sampleBuffer);
    __weak typeof(self) weakSelf = self;
    dispatch_async(self.encodeSampleQueue, ^{
        if (weakSelf.isCapturing) {
            aw_flv_audio_tag *audio_tag = [weakSelf.audioEncoder encodeAudioSampleBufToFlvTag:sampleBuffer];
            [weakSelf sendFlvAudioTag:audio_tag];
        }
        CFRelease(sampleBuffer);
    });
}

- (void)sendFlvVideoTag:(aw_flv_video_tag *)video_tag
{
    __weak typeof(self) weakSelf = self;
    if (video_tag) {
        dispatch_async(self.sendSampleQueue, ^{
            if(weakSelf.isCapturing){
                if (!weakSelf.isSpsPpsAndAudioSpecificConfigSent) {
                    [weakSelf sendSpsPpsAndAudioSpecificConfigTag];
                    free_aw_flv_video_tag((aw_flv_video_tag **)&video_tag);
                }else{
                    aw_streamer_send_video_data(video_tag);
                }
            }
        });
    }
}

- (void)sendFlvAudioTag:(aw_flv_audio_tag *)audio_tag
{
    __weak typeof(self) weakSelf = self;
    if(audio_tag){
        dispatch_async(self.sendSampleQueue, ^{
            if(weakSelf.isCapturing){
                if (!weakSelf.isSpsPpsAndAudioSpecificConfigSent) {
                    [weakSelf sendSpsPpsAndAudioSpecificConfigTag];
                    free_aw_flv_audio_tag((aw_flv_audio_tag **)&audio_tag);
                }else{
                    aw_streamer_send_audio_data(audio_tag);
                }
            }
        });
    }
}

- (void)sendSpsPpsAndAudioSpecificConfigTag
{
    if (self.isSpsPpsAndAudioSpecificConfigSent) {
        return;
    }
    __weak typeof(self) weakSelf = self;
    dispatch_async(self.sendSampleQueue, ^{
        if (!weakSelf.isCapturing || weakSelf.isSpsPpsAndAudioSpecificConfigSent) {
            return;
        }
        aw_flv_video_tag *spsPpsTag = [weakSelf.videoEncoder createSpsPpsFlvTag];
        if (spsPpsTag) {
            aw_streamer_send_video_sps_pps_tag(spsPpsTag);
        }
        aw_flv_audio_tag *audioSpecificConfigTag = [weakSelf.audioEncoder createAudioSpecificConfigFlvTag];
        if (audioSpecificConfigTag) {
            aw_streamer_send_audio_specific_config_tag(audioSpecificConfigTag);
        }
        weakSelf.isSpsPpsAndAudioSpecificConfigSent = spsPpsTag || audioSpecificConfigTag;
        aw_log("[D] is sps pps and audio sepcific config sent=%d", weakSelf.isSpsPpsAndAudioSpecificConfigSent);
    });
}

@end
