//
//  LiveAACEncoder.h
//  TestLive
//
//  Created by arvin on 2017/9/11.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioToolbox.h>
#include "aw_all.h"

#import "LiveAVCapture.h"

@interface LiveAACEncoder : NSObject

@property (nonatomic, strong) LiveAVCapture* capture;

- (aw_flv_audio_tag *)encodeAudioSampleBufToFlvTag:(CMSampleBufferRef)audioSample;
- (aw_flv_audio_tag *)createAudioSpecificConfigFlvTag;
-(void)open;
-(void)close;

@end
