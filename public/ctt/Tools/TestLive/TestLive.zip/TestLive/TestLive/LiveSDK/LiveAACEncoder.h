
/*
 AAC硬编码器
 */

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>
#include "aw_all.h"

@class LiveAVCapture;
@interface LiveAACEncoder : NSObject

@property (nonatomic, strong) LiveAVCapture* capture;

- (aw_flv_audio_tag *)encodeAudioSampleBufToFlvTag:(CMSampleBufferRef)audioSample;
- (aw_flv_audio_tag *)createAudioSpecificConfigFlvTag;
- (void)open;
- (void)close;

@end
