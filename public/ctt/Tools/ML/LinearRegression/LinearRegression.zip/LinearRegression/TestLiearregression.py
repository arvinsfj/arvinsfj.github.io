#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
batch gradient descent
http://people.sc.fsu.edu/~jburkardt/datasets/regression/regression.html
'''
# h(x) = a0x0 + a1x1 + a2x2 + a3x3 + a4x4

def dataread(filename):
    L = []
    file_object = open(filename, 'r')
    all_lines = file_object.readlines()
    for line in all_lines:
        K = [float(x) for x in line.split()]
        K[0] = 1
        L.append(K)
    return L

print '============================='

def compute_error(weights, samples):
    totalError = 0
    for i in range(0, len(samples)):
        yt = samples[i][len(weights)]
        hx = sum([weights[k]*samples[i][k] for k in range(0, len(weights))])
        totalError += (yt - hx) ** 2
    return totalError / float(len(samples))

def step_gradient(weights, samples, learningRate):
    M = float(len(weights))
    N = float(len(samples))
    weight = weights[:]
    for j in range(0, len(weight)):
        j_gradient = 0;
        for i in range(0, len(samples)):
            j_hx = sum([weight[k]*samples[i][k] for k in range(0, len(weight))])
            j_yt = samples[i][len(weights)]
            j_xt = samples[i][j]
            j_gradient += (M/N)*(j_yt-j_hx)*j_xt
        weights[j] += learningRate * j_gradient
    return weights

def gradient_descent_runner(samples, weights, learning_rate, num_iterations):
    for i in range(num_iterations):
        weights = step_gradient(weights, samples, learning_rate)
    return weights

def run():
    samples = dataread('x33.txt')
    weights = [0,0,0,0,0]
    num_iterations = 10000
    learningRate = 0.0000001
    print "error = {0}".format(compute_error(weights, samples))
    print "Running..."
    weights = gradient_descent_runner(samples, weights, learningRate, num_iterations)
    print "After {0} iterations \nweights {1}".format(num_iterations, weights)
    print "error = {0}".format(compute_error(weights, samples))

run()

