#!/usr/bin/env python
# -*- coding: utf-8 -*-

import math

'''
incremental gradient descent
'''
# h(x) = 1/1+exp(-z)
# z = a0x0 + a1x1 +a2x2

def dataread(filename):
    L = []
    file_object = open(filename, 'r')
    all_lines = file_object.readlines()
    for line in all_lines:
        K = [float(x) for x in line.split()]
        K.insert(0, 1)
        L.append(K)
    return L

print '============================='

def compute_error(weights, samples):
    total = 0
    for i in range(0, len(samples)):
        yt = samples[i][len(weights)]
        hx = sigmod(sum([weights[k]*samples[i][k] for k in range(0, len(weights))]))
        if abs(yt - hx) > 0.1:
            total += 1;
    return total / float(len(samples))

def sigmod(z):
    if z >= 0:
        return 1
    else:
        return 0

def step_gradient(weights, samples, learningRate):
    weight = weights[:]
    for i in range(0, len(samples)):
        for j in range(0, len(weight)):
            j_yt = samples[i][len(weights)]
            j_hx = sigmod(sum([weight[k]*samples[i][k] for k in range(0, len(weight))]))
            j_xt = samples[i][j]
            weights[j] += learningRate*(j_yt-j_hx)*j_xt
    return weights

def gradient_descent_runner(samples, weights, learning_rate, num_iterations):
    for i in range(num_iterations):
        weights = step_gradient(weights, samples, learning_rate)
    return weights

def run():
    samples = dataread('x01.txt')
    weights = [0,0,0]
    num_iterations = 100000
    learningRate = 0.0001
    print "Running..."
    weights = gradient_descent_runner(samples, weights, learningRate, num_iterations)
    print "After {0} iterations \nweights {1}".format(num_iterations, weights)
    samples_test = dataread('x02.txt')
    print "error = {0}".format(compute_error(weights, samples_test))

run()

