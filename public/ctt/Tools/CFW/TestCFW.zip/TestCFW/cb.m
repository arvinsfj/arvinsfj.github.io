
#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface TestObj : NSObject

- (void)test;
    
@end


@implementation TestObj
    
- (void)test
{
    NSLog(@"%@", @"hello, object!");
}
    
@end

void test_main()
{
    printf("%s\n", "hello, bluetooth!");
    TestObj* testObj = [[TestObj alloc] init];
    [testObj test];
}

#include "cfw.c"


