//
//  DeviceInfoObject.h
//  TestCoreBluetooth
//
//  Created by vin on 2018/6/7.
//  Copyright © 2018年 vin. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <CoreBluetooth/CoreBluetooth.h>

#import "BluetoothObject.h"

@interface DeviceInfoObject : NSObject <BluetoothObjectDeviceDelegate>

@end
