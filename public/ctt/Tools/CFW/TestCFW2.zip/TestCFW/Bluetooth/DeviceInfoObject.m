//
//  DeviceInfoObject.m
//  TestCoreBluetooth
//
//  Created by vin on 2018/6/7.
//  Copyright © 2018年 vin. All rights reserved.
//

#import "DeviceInfoObject.h"

#define SIZE_OF(arr) (int)(sizeof(arr)/sizeof(arr[0]))

@interface DeviceInfoObject ()

@property (nonatomic, strong) NSArray* productNameArr;//支持的测距仪名称列表
@property (nonatomic, strong) NSArray* productNotifyNameArr;//支持订阅的特征名称列表
@property (nonatomic, strong) NSArray* productCommandNameArr;//支持命令的特征名称列表
@property (nonatomic, assign) IMP* productSingleSendArr;//支持单次测量的函数名称列表
@property (nonatomic, assign) IMP* productDataParseArr;//原始数据解析的函数名称列表

@end

@implementation DeviceInfoObject

- (void)dealloc
{
    free(_productSingleSendArr);
    free(_productDataParseArr);
}

- (instancetype)init
{
    if (self = [super init]) {
        _productNameArr = @[@[@"MI Band 2"]];
        _productNotifyNameArr = @[@"2A37"];
        _productCommandNameArr = @[@"2A39"];
        
        //单次发送的函数发送列表
        SEL selSendArr[] = {@selector(singleMIHRSend:)};//配置列表
        _productSingleSendArr = malloc(SIZE_OF(selSendArr)*sizeof(IMP));
        for (int i = 0; i < SIZE_OF(selSendArr); ++i) {
            SEL func = selSendArr[i];
            _productSingleSendArr[i] = [self methodForSelector:func];
        }
        
        //设备原始数据解析函数列表
        SEL selParseArr[] = {@selector(deviceMIHRParse:)};//配置列表
        _productDataParseArr = malloc(SIZE_OF(selParseArr)*sizeof(IMP));
        for (int i = 0; i < SIZE_OF(selParseArr); ++i) {
            SEL func = selParseArr[i];
            _productDataParseArr[i] = [self methodForSelector:func];
        }
    }
    return self;
}

- (NSInteger)deviceFilterPeripheral:(CBPeripheral*)peripheral
{
    NSInteger index = -1;
    NSString* peripheralName = peripheral.name;
    
    for (NSArray* pnameArr in _productNameArr) {
        for (NSString* pname in pnameArr) {
            if ([peripheralName containsString:pname]) {
                index = [_productNameArr indexOfObject:pnameArr];
                break;
            }
        }
        if (index != -1) {
            break;
        }
    }
    return index;
}

- (BOOL)deviceFilterNotifyOrWriteCharacteristic:(CBCharacteristic*)character andPeripheral:(CBPeripheral *)peripheral andFilter:(DeviceFilter)filter
{
    NSString* characterName = character.UUID.UUIDString;
    NSInteger index = [self deviceFilterPeripheral:peripheral];//过滤是不是支持的外设
    if (index != -1) {
        //找到了
        NSArray* filterArr = nil;
        if (filter == DF_NOTIFY) {//notify
            filterArr = _productNotifyNameArr;
        } else if (filter == DF_WRITE) {//write
            filterArr = _productCommandNameArr;
        }
        if ([characterName isEqualToString:filterArr[index]]) {
            return YES;
        }
    }
    return NO;
}

//////////////////////////////////下面是单次测量发送方法////////////////////////

//默认协议
- (void)singleNilSend:(BluetoothObject*)bluetooth
{
    //不发送任何指令，作为暂不支持写入命令的设备使用
}

//小米心率测量协议
- (void)singleMIHRSend:(BluetoothObject*)bluetooth
{
    //发送数据
    char data1[] = {21, 2, 1};//单次测量
    [bluetooth sendByteWith:data1 andLength:3];
}

//单次测量
- (void)deviceSingleMeasureWithBluetooth:(BluetoothObject*)bluetooth
{
    NSInteger index = -1;
    int num = 0;
    BOOL done = NO;
    while (!done && num < 10) {
        if (![bluetooth getBluetoothState]) {
            num++;
            sleep(1);
        } else {
            index = [self deviceFilterPeripheral:[bluetooth getPeripheral]];
            done = YES;
        }
    }
    if (_productSingleSendArr[index]) {
        ((void (*)(id, SEL, id))_productSingleSendArr[index])(self, nil, bluetooth);
    }
}

//////////////////////////////////下面是原始数据解析方法////////////////////////

//默认解析协议
- (NSInteger)deviceNilParse:(NSData*)data
{
    //默认解析方法
    return -1;
}

//小米心率解析协议
- (NSInteger)deviceMIHRParse:(NSData*)data
{
    unsigned short bpm = 0;
    Byte *byte =(Byte*)[data bytes];
    if (data.length >= 2) {
        if ((byte[0] & 0x01) == 0) {
            bpm = byte[1];
        } else {
            bpm = byte[1] << 8;
            bpm = bpm | byte[2];
        }
    }
    NSInteger length = (NSInteger)bpm;
    if (length > 0) {
        return length;
    }
    return -1;
}

//蓝牙返回的原始数据解析
- (NSInteger)deviceParseData:(NSData *)data andPeripheral:(CBPeripheral *)peripheral
{
    NSInteger index = [self deviceFilterPeripheral:peripheral];
    if (index != -1 && data && data.length) {
        NSInteger length = -1;
        if (_productDataParseArr[index]) {
            length = ((NSInteger (*)(id, SEL, id))_productDataParseArr[index])(self, nil, data);
        }
        return length;
    }
    return -1;
}

@end
