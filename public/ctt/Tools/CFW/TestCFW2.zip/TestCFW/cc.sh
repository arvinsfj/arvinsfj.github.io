cc -framework CoreBluetooth -framework Foundation cb.m Bluetooth/BluetoothApi.m Bluetooth/BluetoothObject.m Bluetooth/DeviceInfoObject.m -o cb
