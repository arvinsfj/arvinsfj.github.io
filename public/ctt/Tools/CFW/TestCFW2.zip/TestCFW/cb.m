
#import <Foundation/Foundation.h>

#import "Bluetooth/BluetoothApi.h"

@interface TestObj : NSObject <BluetoothObjectDelegate>
    
- (void)test;
    
@end


@implementation TestObj
    
- (void)test
{
    BluetoothApi*  bluetooth = [BluetoothApi shareInstance];
    bluetooth.delegate = self;
    [bluetooth startBluetooth];
    //
    [bluetooth singleMeasure];
}
    
    //蓝牙连接状态回调
- (void)bluetoothConnState:(BluetoothObject*)bluetooth andState:(BluetoothState)state andError:(NSError*)error
{
    
}
    
//数据读写回调
- (void)bluetoothReadData:(BluetoothObject*)bluetooth andData:(NSData*)data andError:(NSError*)error
{
    
}

- (void)bluetoothReadData:(BluetoothObject*)bluetooth andLength:(NSInteger)length//返回毫米数据
{
    NSLog(@"%ld", (long)length);
}

- (void)bluetoothWriteData:(BluetoothObject*)bluetooth andError:(NSError*)error
{
    
}
    
@end

void test_main()
{
    printf("%s\n", "hello, bluetooth!");
    TestObj* testObj = [[TestObj alloc] init];
    [testObj test];
}

#include "cfw.c"


