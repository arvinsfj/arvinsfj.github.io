#include <stdio.h>
#include "fishhook.h"

static int (*original_strlen)(const char *_s);
int new_strlen(const char *_s) {
    printf("%s\n", _s);
    return original_strlen(_s);
}

int main(int argc, const char * argv[]) {
    struct rebinding strlen_rebinding = { "strlen", new_strlen,
        (void *)&original_strlen };
    rebind_symbols((struct rebinding[1]){ strlen_rebinding }, 1);
    char *str = "hellolazy";
    printf("%d\n", strlen(str));
    return 0;
}
