//

//gcc -framework Cocoa -framework CoreImage -o qr main.m QRImageService.m
//clang -framework Cocoa -framework CoreImage -o qr main.m QRImageService.m

#import <Cocoa/Cocoa.h>

#import "QRImageService.h"

int main(int argc, const char * argv[]) {
    
    @autoreleasepool {
        NSApplication *app = [NSApplication sharedApplication];
        QRImageService* delegate = [[QRImageService alloc] init];
        if (argc == 2) {
            delegate.qrStr = [NSString stringWithCString:argv[1] encoding:NSASCIIStringEncoding];
        }
        app.delegate = delegate;
        return NSApplicationMain(argc, (const char**)argv);
    }
}
