//
//  QRImageService.m
//  QRImageService
//
//  Created by arvin on 2017/8/7.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import "QRImageService.h"

#import <CoreImage/CoreImage.h>

@implementation QRImageService

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    NSLog(@"%@", @"loaded!");
    if (_qrStr&&_qrStr.length) {
        NSImage *image = [self createQRImage:_qrStr withSize:200];
        [self saveImage:image];
    }
    exit(0);
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

//业务逻辑
//创建清晰的QR Code
- (NSImage *)createQRImage:(NSString *)str withSize:(CGFloat)size
{
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    [filter setDefaults];
    [filter setValue:[str dataUsingEncoding:NSUTF8StringEncoding] forKeyPath:@"inputMessage"];
    CIImage* image = [filter outputImage];
    
    CGRect extent = CGRectIntegral(image.extent);
    CGFloat scale = MIN(size/CGRectGetWidth(extent), size/CGRectGetHeight(extent));
    size_t width = CGRectGetWidth(extent) * scale;
    size_t height = CGRectGetHeight(extent) * scale;
    
    CGContextRef bitmapRef = CGBitmapContextCreate(nil, width, height, 8, 0, CGColorSpaceCreateDeviceGray(), (CGBitmapInfo)kCGImageAlphaNone);
    CGContextSetInterpolationQuality(bitmapRef, kCGInterpolationNone);
    CGContextScaleCTM(bitmapRef, scale, scale);
    
    CIContext *ctx = [CIContext contextWithOptions:nil];
    CGImageRef bitmapImage = [ctx createCGImage:image fromRect:extent];
    CGContextDrawImage(bitmapRef, extent, bitmapImage);
    
    CGImageRef scaledImage = CGBitmapContextCreateImage(bitmapRef);
    CGContextRelease(bitmapRef);
    CGImageRelease(bitmapImage);
    return [[NSImage alloc] initWithCGImage:scaledImage size:NSMakeSize(width, height)];
}

- (void)saveImage:(NSImage *)image
{
    [image lockFocus];
    NSData *imageData = [image TIFFRepresentation];
    NSBitmapImageRep *imageRep = [NSBitmapImageRep imageRepWithData:imageData];
    [imageRep setSize:[image size]];
    [image unlockFocus];
    imageData = [imageRep representationUsingType:NSPNGFileType properties:[NSDictionary new]];
    NSString* path = [[NSHomeDirectory() stringByAppendingPathComponent:@"Pictures"] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png", _qrStr]];
    BOOL y = [imageData writeToFile:path atomically:YES];
    if (y) {
        NSLog(@"二维码保存成功: \n%@", path);
    }else{
        NSLog(@"%@", @"保存二维码失败！！！");
    }
}

@end
