//
//  QRImageService.h
//  QRImageService
//
//  Created by arvin on 2017/8/7.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface QRImageService : NSObject <NSApplicationDelegate>
{
    
}

@property (strong, nonatomic) NSString* qrStr;

//+ (instancetype)sharePToP;


@end

