//

//gcc -framework Cocoa -framework MultipeerConnectivity -o p2p main.m PeersDataService.m
//clang -framework Cocoa -framework MultipeerConnectivity -o p2p main.m PeersDataService.m

#import <Cocoa/Cocoa.h>

#import "PeersDataService.h"

static const char* plist = "<plist version=\"1.0\"><dict><key>NSPrincipalClass</key><string>NSApplication</string></dict></plist>";

void plistw()
{
    FILE* fd = fopen("Info.plist", "w");
    fputs(plist, fd);
    fclose(fd);
}

int main(int argc, const char * argv[]) {
    plistw();
    @autoreleasepool {
        NSApplication *app = [NSApplication sharedApplication];
        PeersDataService* delegate = [[PeersDataService alloc] init];
        if (argc == 1) {
            delegate.service_id = @"";
        }
        if (argc == 2) {
            delegate.service_id = [NSString stringWithCString:argv[1] encoding:NSASCIIStringEncoding];
        }
        app.delegate = delegate;
        return NSApplicationMain(argc, (const char**)argv);
    }
}
