#!/usr/bin/ruby -w
# -*- coding: UTF-8 -*-

$LOAD_PATH << '.'
require 'apns/core'
require 'apns/notification'

APNS.host = 'gateway.sandbox.push.apple.com'
APNS.pem  = './bm_dev.pem'
APNS.port = 2195

device_token = '84b6738a9fd29f86ada82443337414ca0f22226ad218bf5a110915343597e79d'
APNS.send_notification(device_token, 'Hello iPhone!' )
APNS.send_notification(device_token, :alert => 'Hello iPhone!', :badge => 1, :sound => 'default')
