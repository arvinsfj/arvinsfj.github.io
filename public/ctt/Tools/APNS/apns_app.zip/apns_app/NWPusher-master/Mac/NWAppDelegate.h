//
//  NWAppDelegate.h
//  Pusher
//
//  Copyright (c) 2012 noodlewerk. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NWAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
