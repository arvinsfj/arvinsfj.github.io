//
//  Sec.m
//  SmartPush
//
//  Created by runlin on 2017/2/27.
//  Copyright © 2017年 www.skyfox.org. All rights reserved.
//

#import "Sec.h"

@implementation Sec

@end
