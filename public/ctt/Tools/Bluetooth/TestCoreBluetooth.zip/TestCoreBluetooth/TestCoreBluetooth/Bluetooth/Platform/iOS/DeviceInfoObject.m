//
//  DeviceInfoObject.m
//  TestCoreBluetooth
//
//  Created by vin on 2018/6/7.
//  Copyright © 2018年 vin. All rights reserved.
//

#import "DeviceInfoObject.h"

@interface DeviceInfoObject ()

@property (nonatomic, strong) NSArray* productNameArr;//支持的测距仪名称列表
@property (nonatomic, strong) NSArray* productNotifyNameArr;//支持订阅的特征名称列表
@property (nonatomic, strong) NSArray* productCommandNameArr;//支持命令的特征名称列表
@property (nonatomic, assign) IMP* productSingleSendArr;//支持单次测量的函数名称列表
@property (nonatomic, assign) IMP* productDataParseArr;//原始数据解析的函数名称列表

@end

@implementation DeviceInfoObject

- (void)dealloc
{
    free(_productSingleSendArr);
    free(_productDataParseArr);
}

- (instancetype)init
{
    if (self = [super init]) {
        _productNameArr = @[@[@"Myhome3D"],/* 0 爱福窝量房宝 */
                            @[@"mileseey", @"K3", @"S6", @"laser",@"D5",@"T7",@"P7",@"Laser",@"Mileseey R2B"],/* 1 迈测 */
                            @[@"T40+", @"MX-50", @"T60+", @"PD14 MINI+"],/* 2 星瑞达 */
                            @[@"HC-08"],/* 3 伟创 */
                            @[@"Dobiy"],/* 4 泰瑞 dobiy */
                            @[@"BT12"]];/* 5 洪乐 */
        _productNotifyNameArr = @[@"FFB2", @"FFB2", @"CBB1", @"FFE1", @"FFE1", @"FFE1"];
        _productCommandNameArr = @[@"暂无", @"FFB2", @"CBB1", @"暂无", @"暂无", @"FFE2"];
        
        //单次测量的函数发送列表
        SEL selSendArr[] = {@selector(singleNilSend:), @selector(singleMCSend:), @selector(singleXRDSend:), @selector(singleNilSend:), @selector(singleNilSend:), @selector(singleHLSend:)};//配置列表
        _productSingleSendArr = malloc(sizeof(selSendArr)*sizeof(IMP));
        for (int i = 0; i < sizeof(selSendArr); ++i) {
            IMP func = [self methodForSelector:selSendArr[i]];
            _productSingleSendArr[i] = func;
        }
        
        //设备原始数据解析函数列表
        SEL selParseArr[] = {@selector(deviceAFWParse:), @selector(deviceMCParse:), @selector(deviceXRDParse:), @selector(deviceWCParse:), @selector(deviceTRParse:), @selector(deviceHLParse:)};//配置列表
        _productDataParseArr = malloc(sizeof(selParseArr)*sizeof(IMP));
        for (int i = 0; i < sizeof(selParseArr); ++i) {
            IMP func = [self methodForSelector:selParseArr[i]];
            _productDataParseArr[i] = func;
        }
    }
    return self;
}

- (NSInteger)deviceFilterPeripheral:(CBPeripheral*)peripheral
{
    NSInteger index = -1;
    NSString* peripheralName = peripheral.name;
    
    for (NSArray* pnameArr in _productNameArr) {
        for (NSString* pname in pnameArr) {
            if ([peripheralName containsString:pname]) {
                index = [_productNameArr indexOfObject:pnameArr];
                break;
            }
        }
        if (index != -1) {
            break;
        }
    }
    return index;
}

- (BOOL)deviceFilterNotifyOrWriteCharacteristic:(CBCharacteristic*)character andPeripheral:(CBPeripheral *)peripheral andFilter:(DeviceFilter)filter
{
    NSString* characterName = character.UUID.UUIDString;
    NSInteger index = [self deviceFilterPeripheral:peripheral];//过滤是不是支持的外设
    if (index != -1) {
        //找到了
        NSArray* filterArr = nil;
        if (filter == DF_NOTIFY) {//notify
            filterArr = _productNotifyNameArr;
        } else if (filter == DF_WRITE) {//write
            filterArr = _productCommandNameArr;
        }
        if ([characterName isEqualToString:filterArr[index]]) {
            return YES;
        }
    }
    return NO;
}

//////////////////////////////////下面是单次测量发送方法////////////////////////

//默认协议
- (void)singleNilSend:(BluetoothObject*)bluetooth
{
    //不发送任何指令，作为暂不支持写入命令的设备使用
}

//星瑞达协议
- (void)singleXRDSend:(BluetoothObject*)bluetooth
{
    //星瑞达
    //发送数据
    char data1[] = {0x6B, 0x88};//单次测量
    [bluetooth sendByteWith:data1 andLength:2];
}

//洪乐协议
- (void)singleHLSend:(BluetoothObject*)bluetooth
{
    //洪乐
    //发送数据
    char data1[] = {0x80, 0x07, 0x02, 0x00, 0x00, 0x00, 0x00, 0x77};//单次测量
    [bluetooth sendByteWith:data1 andLength:8];
}

//麦测协议
- (void)singleMCSend:(BluetoothObject*)bluetooth
{
    //麦测
    //发送数据
    char data1[] = {0x64, 0x74};//单次测量
    [bluetooth sendByteWith:data1 andLength:2];
    sleep(0.5);
    [bluetooth sendByteWith:data1 andLength:2];
}

//单次测量
- (void)deviceSingleMeasureWithBluetooth:(BluetoothObject*)bluetooth
{
    NSInteger index = -1;
    int num = 0;
    BOOL done = NO;
    while (!done && num < 10) {
        if (![bluetooth getBluetoothState]) {
            num++;
            sleep(1);
        } else {
            index = [self deviceFilterPeripheral:[bluetooth getPeripheral]];
            done = YES;
        }
    }
    if (_productSingleSendArr[index]) {
        ((void (*)(id, SEL, id))_productSingleSendArr[index])(self, nil, bluetooth);
    }
}

//////////////////////////////////下面是原始数据解析方法////////////////////////

//默认解析协议
- (NSInteger)deviceNilParse:(NSData*)data
{
    //默认解析方法
    return -1;
}

//爱福窝协议
- (NSInteger)deviceAFWParse:(NSData*)data
{
    Byte *byte =(Byte*)[data bytes];
    char bytes[]={byte[3],byte[4],byte[5],byte[6]};
    unsigned char  by1 = (bytes[0] & 0xff); //高8位
    unsigned char  by2 = (bytes[1] & 0xff);//中8位
    unsigned char  by3 = (bytes[2] & 0xff);//低8位
    unsigned char  by4 = (bytes[3] & 0xff);
    int temp = (by4|(by3<<8)|(by2<<16)|(by1<<24));
    NSInteger length = (NSInteger)roundf(temp*0.0001*1000);
    if (length > 0) {
        return length;
    }
    return -1;
}

//麦测协议
- (NSInteger)deviceMCParse:(NSData*)data
{
    Byte* receiveByte = (Byte *)[data bytes];
    NSString *strValue = [NSString stringWithCString:(const char *)receiveByte encoding:NSASCIIStringEncoding];
    NSString *result = [strValue componentsSeparatedByString:@"m"].firstObject;
    result = [result stringByReplacingOccurrencesOfString:@"D" withString:@""];
    result = [result stringByReplacingOccurrencesOfString:@"M" withString:@""];
    NSInteger length = (NSInteger)roundf([result floatValue] * 1000);
    if (length > 0) {
        return length;
    }
    return -1;
}

//星瑞达协议
- (NSInteger)deviceXRDParse:(NSData*)data
{
    Byte* receiveByte = (Byte *)[data bytes];
    NSString *strValue = [NSString stringWithCString:(const char *)receiveByte encoding:NSASCIIStringEncoding];
    NSString *result = [strValue componentsSeparatedByString:@"m"].firstObject;
    result = [result stringByReplacingOccurrencesOfString:@"D" withString:@""];
    result = [result stringByReplacingOccurrencesOfString:@"M" withString:@""];
    NSInteger length = (NSInteger)roundf([result floatValue] * 1000);
    if (length > 0) {
        return length;
    }
    return -1;
}

//伟创协议
- (NSInteger)deviceWCParse:(NSData*)data
{
    if (data.length == 11) {
        Byte* bytes = (Byte*)[data bytes];
        if (bytes[0]==0xaa &&
            bytes[1]==0x43 &&
            bytes[2]==0x00 &&
            bytes[3]==0x2a &&
            bytes[4]==0x00 &&
            bytes[5]==0x02   ) {
            unsigned long len = data.length-7;
            Byte* bytes = malloc(len); memset(bytes, 0, len);
            [data getBytes:bytes range:NSMakeRange(6, len)];
            char *dest = malloc(len*2); const char *src = (const char *)bytes;
            memset(dest, 0, len*2);
            char *t = dest;
            while(len--) {
                *t |= ((*src&0xf0)>>4);
                *t++ |= 0x30;
                *t |= (*src&0xf);
                *t++ |= 0x30;
                src++;
            }
            NSString *strValue = [NSString stringWithCString:dest encoding:NSUTF8StringEncoding];
            NSInteger length = (NSInteger)([strValue intValue]/1000.0 * 1000);
            free(bytes);
            free(dest);
            if (length > 0) {
                return length;
            }
        }
    }
    return -1;
}

//泰瑞（Dobiy）协议
- (NSInteger)deviceTRParse:(NSData*)data
{
    NSInteger length = -1;
    Byte* bytes = (Byte*)[data bytes];
    NSString *strValue = [NSString stringWithCString:(const char *)bytes encoding:NSUTF8StringEncoding];
    unichar type = [strValue characterAtIndex:4];
    if (type == 'g') {
        NSString *result = [strValue substringWithRange:NSMakeRange(5, 5)];
        length = (NSInteger)roundf([result floatValue] * 1000);
        if (length > 0) {
            return length;
        }
    }
    return -1;
}

//洪乐协议
- (NSInteger)deviceHLParse:(NSData*)data
{
    if (data.length == 12) {
        Byte* bytes = (Byte*)[data bytes];
        int a = bytes[4] & 0x0f;
        int b = bytes[5] & 0x0f;
        int c = bytes[7] & 0x0f;
        int d = bytes[8] & 0x0f;
        int e = bytes[9] & 0x0f;
        int result = a * 10000 + b * 1000 + c * 100 + d * 10 + e; // ab.cde
        NSInteger length = (NSInteger)result;
        if (length > 0) {
            return length;
        }
    }
    return -1;
}

//蓝牙返回的原始数据解析
- (NSInteger)deviceParseData:(NSData *)data andPeripheral:(CBPeripheral *)peripheral
{
    NSInteger index = [self deviceFilterPeripheral:peripheral];
    if (index != -1 && data && data.length) {
        NSInteger length = -1; //正常情况下返回单位位毫米的数据
        if (_productSingleSendArr[index]) {
            length = ((NSInteger (*)(id, SEL, id))_productDataParseArr[index])(self, nil, data);
        }
        return length;
    }
    return -1;
}

@end
