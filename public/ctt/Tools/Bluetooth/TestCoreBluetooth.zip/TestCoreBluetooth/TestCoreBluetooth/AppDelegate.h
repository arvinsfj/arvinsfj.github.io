//
//  AppDelegate.h
//  TestCoreBluetooth
//
//  Created by vin on 2018/6/6.
//  Copyright © 2018年 vin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

