//
//  ViewController.m
//  TestCoreBluetooth
//
//  Created by vin on 2018/6/6.
//  Copyright © 2018年 vin. All rights reserved.
//

#import "ViewController.h"

#import "BluetoothApi.h"

@interface ViewController () <BluetoothObjectDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self testBluetooth];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)testBluetooth
{
    BluetoothApi* bluetooth = [BluetoothApi shareInstance];
    bluetooth.delegate = self;
    [bluetooth startBluetooth];
    //
    [bluetooth singleMeasure];//单次测量
}

- (void)bluetoothConnState:(BluetoothObject*)bluetooth andState:(BluetoothState)state andError:(NSError*)error
{
    NSLog(@"%ld", (long)state);
}

- (void)bluetoothReadData:(BluetoothObject*)bluetooth andData:(NSData*)data andError:(NSError*)error
{
    //读数据
    if (!error) {
        NSLog(@"读取成功: %@", data);
        NSUInteger length = data.length;
        Byte* bytes = (Byte*)data.bytes;
        for (int i = 0; i < length; ++i) {
            printf("0x%X ", bytes[i]);
        }
        printf("\n");
        for (int i = 0; i < length; ++i) {
            printf("%c", bytes[i]);
        }
        printf("\n");
        
    } else {
        NSLog(@"%@", error);
    }
}

- (void)bluetoothReadData:(BluetoothObject*)bluetooth andLength:(NSInteger)length
{
    NSLog(@"解析后：%ld mm", (long)length);
    
}

- (void)bluetoothWriteData:(BluetoothObject*)bluetooth andError:(NSError*)error
{
    //写数据
    if (!error) {
        NSLog(@"%@", @"写入成功!");
    } else {
        NSLog(@"%@", error);
    }
}


@end

