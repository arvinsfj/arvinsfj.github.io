//
//  cwnd.c
//  TestNes
//
//  Created by arvin on 2017/8/16.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import <UIKit/UIKit.h>

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "hqx.h"

uint32_t   RGBtoYUV[16777216];
uint32_t   YUV1, YUV2;

HQX_API void HQX_CALLCONV hqxInit(void)
{
    /* Initalize RGB to YUV lookup table */
    uint32_t c, r, g, b, y, u, v;
    for (c = 0; c < 16777215; c++) {
        r = (c & 0xFF0000) >> 16;
        g = (c & 0x00FF00) >> 8;
        b = c & 0x0000FF;
        y = (uint32_t)(0.299*r + 0.587*g + 0.114*b);
        u = (uint32_t)(-0.169*r - 0.331*g + 0.5*b) + 128;
        v = (uint32_t)(0.5*r - 0.419*g - 0.081*b) + 128;
        RGBtoYUV[c] = (y << 16) + (u << 8) + v;
    }
}

#define    WIDTH        256
#define    HEIGHT       240
#define    MAG          1   //magnification;

static uint32_t palette_sys[] =
{
    0x666666, 0x002A88, 0x1412A7, 0x3B00A4, 0x5C007E, 0x6E0040, 0x6C0600, 0x561D00,
    0x333500, 0x0B4800, 0x005200, 0x004F08, 0x00404D, 0x000000, 0x000000, 0x000000,
    0xADADAD, 0x155FD9, 0x4240FF, 0x7527FE, 0xA01ACC, 0xB71E7B, 0xB53120, 0x994E00,
    0x6B6D00, 0x388700, 0x0C9300, 0x008F32, 0x007C8D, 0x000000, 0x000000, 0x000000,
    0xFFFEFF, 0x64B0FF, 0x9290FF, 0xC676FF, 0xF36AFF, 0xFE6ECC, 0xFE8170, 0xEA9E22,
    0xBCBE00, 0x88D800, 0x5CE430, 0x45E082, 0x48CDDE, 0x4F4F4F, 0x000000, 0x000000,
    0xFFFEFF, 0xC0DFFF, 0xD3D2FF, 0xE8C8FF, 0xFBC2FF, 0xFEC4EA, 0xFECCC5, 0xF7D8A5,
    0xE4E594, 0xCFEF96, 0xBDF4AB, 0xB3F3CC, 0xB5EBF2, 0xB8B8B8, 0x000000, 0x000000,
};

static uint8_t pic_mem_orgl[WIDTH * HEIGHT * 4];
static uint8_t pic_mem_frnt[WIDTH * HEIGHT * 4 * MAG * MAG];
static uint32_t frame_counter;
static double time_frame0;

int wnd_init(const char *filename)
{
    hqxInit();
    
    frame_counter = 0;
    time_frame0 =  CFAbsoluteTimeGetCurrent()*1000.0;
    
    return 0;
}

void byte2image(uint8_t *bytes, uint64_t width, uint64_t height, uint64_t depth, uint64_t bits)
{
    CGColorSpaceRef colorRef = CGColorSpaceCreateDeviceRGB();
    CGContextRef ctxRef = CGBitmapContextCreate(bytes, width, height, bits, width*depth, colorRef, kCGImageAlphaPremultipliedFirst);//RGBA
    CGImageRef imgRef = CGBitmapContextCreateImage(ctxRef);
    UIImage* image = [UIImage imageWithCGImage:imgRef];
    if (image) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"nes_image" object:nil userInfo:@{@"image":image}];
    }
    CGColorSpaceRelease(colorRef);
    CGImageRelease(imgRef);
    CGContextRelease(ctxRef);
}

void wnd_draw(uint8_t* pixels)
{
    uint32_t *fb = (uint32_t*)pic_mem_orgl;
    for (unsigned int y = 0; y < HEIGHT; y++){
        for (unsigned int x = 0; x < WIDTH; x++) {
            uint32_t pixel = *(pixels + WIDTH * y + x);
            uint32_t bgr = palette_sys[pixel];
            uint8_t b = (bgr>>16)&0xFF;
            uint8_t g = (bgr>>8)&0xFF;
            uint8_t r = (bgr)&0xFF;
            *fb++ = (r<<16|g<<8|b)<<8|0xFF;//BGRA
        }
    }
    
    if (MAG == 1) {
        memcpy(pic_mem_frnt, pic_mem_orgl, WIDTH*HEIGHT*4);
    }
    if (MAG == 2) {
        hq2x_32((uint32_t*)pic_mem_orgl, (uint32_t*)pic_mem_frnt, WIDTH, HEIGHT);
    }
    if (MAG == 3) {
        hq3x_32((uint32_t*)pic_mem_orgl, (uint32_t*)pic_mem_frnt, WIDTH, HEIGHT);
    }
    if (MAG == 4) {
        hq4x_32((uint32_t*)pic_mem_orgl, (uint32_t*)pic_mem_frnt, WIDTH, HEIGHT);
    }
    
    ++frame_counter;
    uint32_t delay = (frame_counter*16.68+time_frame0) - CFAbsoluteTimeGetCurrent()*1000.0;
    if (delay > 0) {
        [NSThread sleepForTimeInterval:(delay/1000.0)];//多余的时间还给系统
    }
    
    byte2image(pic_mem_orgl, WIDTH, HEIGHT, 4, 8);
}

void wnd_play(float com)
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"nes_audio" object:nil userInfo:@{@"audio":@(com)}];
}

int wnd_poll(uint8_t* ctrl)
{
    return 0;
}

