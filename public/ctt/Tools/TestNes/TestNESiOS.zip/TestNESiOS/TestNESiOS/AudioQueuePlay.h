//
//  AudioQueuePlay.h
//  CyclingProject
//
//  Created by arvin on 2017/8/4.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioToolbox.h>

@interface AudioQueuePlay : NSObject

// 播放并顺带附上数据
- (void)playWithData: (NSData *)data;

// reset
- (void)resetPlay;

@end
