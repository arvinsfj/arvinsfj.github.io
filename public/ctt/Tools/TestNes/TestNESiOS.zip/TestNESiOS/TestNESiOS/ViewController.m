//
//  ViewController.m
//  TestNESiOS
//
//  Created by arvin on 8/25/17.
//  Copyright © 2017 arvin. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>

#import "ViewController.h"

#import "AudioQueuePlay.h"

#import "cnes.h"

@interface ViewController ()
{
    AudioQueuePlay* play;
    float* data_cur;
    float* data_frnt;
    float* data_back;
    unsigned int datalen;
    //
    dispatch_queue_t audio_queue;
}
@property (weak, nonatomic) IBOutlet UIImageView *canvasImageView;
@property (weak, nonatomic) IBOutlet UILabel *fpsLabel;

@end

@implementation ViewController

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
    [[AVAudioSession sharedInstance] setActive:YES error:nil];
    
    play = [[AudioQueuePlay alloc] init];
    datalen = 0;
    data_frnt = malloc(1024*2*sizeof(float));
    data_back = malloc(1024*2*sizeof(float));
    memset(data_frnt, 0, 1024*2*sizeof(float));
    memset(data_back, 0, 1024*2*sizeof(float));
    data_cur = data_frnt;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(note:) name:@"nes_image" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(audio:) name:@"nes_audio" object:nil];
    
    NSString* path = [[NSBundle mainBundle] pathForResource:@"ahdl" ofType:@"nes"];
    
    audio_queue = dispatch_queue_create("nes_audio",NULL);
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        //子线程异步执行下载任务，防止主线程卡顿
        cnes_init([path UTF8String]);
    });
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

double time0 = 0; uint8_t fpsArr[100]; uint16_t len = 0;
- (void)calcFPS
{
    double now = CFAbsoluteTimeGetCurrent();
    uint8_t fps = 1/(now - time0);
    time0 = now;
    if (len < 100) {
        fpsArr[len++] = fps;
    }else{
        uint64_t avgFPS = 0;
        for (int i = 0; i < 100; i++) {
            avgFPS+=fpsArr[i];
        }
        avgFPS/=100;
        dispatch_async(dispatch_get_main_queue(), ^{
            _fpsLabel.text = [NSString stringWithFormat:@"%d", (uint8_t)avgFPS];
        });
        len = 0;
        fpsArr[len++] = fps;
    }
}

- (void)note:(NSNotification*)n
{
    [self calcFPS];
    UIImage* image = [n.userInfo objectForKey:@"image"];
    dispatch_async(dispatch_get_main_queue(), ^{
        _canvasImageView.image = nil;
        _canvasImageView.image = image;
    });
}

- (void)audio:(NSNotification*)n
{
    NSNumber* num = [n.userInfo objectForKey:@"audio"];
    float byte = [num floatValue];
    if (datalen < 1024 * 2) {
        data_back[datalen++] = byte;
    } else {
        
        dispatch_async(audio_queue, ^{
            [play playWithData:[NSData dataWithBytes:data_frnt length:4096*2]];
        });
        datalen = 0;
        data_cur = data_back;
        data_back = data_frnt;
        data_frnt = data_cur;
        data_back[datalen++] = byte;
    }
}

- (IBAction)btnDown:(id)sender {
    NSInteger tag = ((UIButton*)sender).tag;
    [self wnd_key2btn:(int)tag andState:YES];
}
- (IBAction)btnUp:(id)sender {
    NSInteger tag = ((UIButton*)sender).tag;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^(void){
        [self wnd_key2btn:(int)tag andState:NO];
    });
}

- (void)wnd_key2btn:(int)key andState:(BOOL)isDown
{
    uint8_t btn = 0;
    switch (key) {
        case 7:
            btn = 1 << 7;//A
            break;
        case 6:
            btn = 1 << 6;//B
            break;
        case 5:
            btn = 1 << 5;//SELECT
            break;
        case 4:
            btn = 1 << 4;//START
            break;
        case 3:
            btn = 1 << 3;//UP
            break;
        case 2:
            btn = 1 << 2;//DOWN
            break;
        case 1:
            btn = 1 << 1;//LEFT
            break;
        case 0:
            btn = 1 << 0;//RIGHT
            break;
    }
    if (isDown){
        cnes.ctrl[0] |= btn;
        cnes.ctrl[1] |= btn;
    }else if (!isDown){
        cnes.ctrl[0] &= ~btn;
        cnes.ctrl[1] &= ~btn;
    }
}


@end
