//
//  cppu.c
//  TestNes
//
//  Created by arvin on 2017/8/16.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#include <assert.h>

#include "cnes.h"
#include "cppu.h"

#define  PPU_TICKS_PER_FRAME    89342 // = 341 * 262

#define  PPU_PRIO_NONE     0
#define  PPU_PRIO_BEHIND   1
#define  PPU_PRIO_BG       2
#define  PPU_PRIO_FRONT    3

#define	 REG_PPUCTRL	0
#define	 PPUCTRL_V	    (1 << 7)	/* Vertical blank NMI enable */
#define	 PPUCTRL_H	    (1 << 5)	/* Sprite size (0: 8x8; 1: 8x16) */
#define	 PPUCTRL_B	    (1 << 4)	/* Background palette table address */
#define	 PPUCTRL_S	    (1 << 3)	/* Sprite pattern table address for 8x8 sprites */
#define	 PPUCTRL_I	    (1 << 2)	/* VRAM address increment per CPU read/write of PPUDATA */
#define	 PPUCTRL_N	    (3 << 0)	/* Base nametable address */
#define	 PPUCTRL_N_X	(1 << 0)	/* Add 256 to the X scroll position */
#define	 PPUCTRL_N_Y	(2 << 0)	/* Add 240 to the Y scroll position */
#define	 REG_PPUMASK	1
#define	 PPUMASK_s	    (1 << 4)	/* Show sprites */
#define	 PPUMASK_b	    (1 << 3)	/* Show background */
#define	 PPUMASK_m	    (1 << 1)	/* Show background in leftmost 8 pixels */
#define	 REG_PPUSTATUS	2
#define	 PPUSTATUS_V	(1 << 7)	/* Vertical blank */
#define	 PPUSTATUS_S	(1 << 6)	/* Sprite 0 Hit */
#define	 REG_OAMADDR	3
#define	 REG_OAMDATA	4
#define	 REG_PPUSCROLL	5
#define	 REG_PPUADDR	6
#define	 REG_PPUDATA	7

#define	 PPU_TILE_ADDR(v)	(0x2000 | ((v) & 0x0fff))
#define	 PPU_ATTR_ADDR(v)	(0x23c0 | ((v) & 0x0c00) | (((v) >> 4) & 0x38) | (((v) >> 2) & 0x07))

static uint16_t ppu_incr_x(ppu_context *p)
{
	uint16_t v = p->reg_v;

	if ((v & 0x001f) == 31) {
		v &= ~0x001f;
		v ^= 0x0400;
	} else {
		v += 1;
	}

	return v;
}

static uint16_t ppu_incr_y(ppu_context *p)
{
	uint16_t v = p->reg_v;

	if ((v & 0x7000) != 0x7000) {
		v += 0x1000;
	} else {
		v &= ~0x7000;
		uint16_t y = (v & 0x03e0) >> 5;
		if (y == 29) {
			y = 0;
			v ^= 0x0800;
		} else if (y == 31) {
			y = 0;
		} else {
			y += 1;
		}
		v = (v & ~0x03e0) | (y << 5);
	}

	return v;
}

int ppu_init(ppu_context *p)
{
	p->frame = 0;
    p->frame_ticks = PPU_TICKS_PER_FRAME;
	return 0;
}

uint8_t ppu_read(ppu_context *p, uint16_t addr)
{
	uint16_t vaddr;
	uint8_t reg, val;
	int incr;

	if (addr < 0x2000 || addr > 0x3FFF)
		assert("ppu: address out of range");

	reg = (addr - 0x2000) & (8-1);

	switch (reg) {
	case REG_PPUSTATUS:
		/* Get current state */
		val = p->regs[reg];

		/* Clear vblank flag */
		p->regs[reg] &= ~PPUSTATUS_V;

		/* Clear write toggle bit */
		p->reg_w = 0;

		break;
	case REG_PPUDATA:
		vaddr = p->reg_v & (0x4000 - 1);

		if (vaddr <= 0x3eff) {
			/* Emulate PPUDATA read buffer (post-fetch) */
			val = p->ppudata;//第一次读取，不是真实数据，第二次才是真实数据，调色板例外读取一次就是真实数据
			p->ppudata = p->read8(vaddr);
        } else {
			val = p->read8(vaddr);
        }
        //读取数据后，vram地址增长1或者32
		incr = (p->regs[REG_PPUCTRL] & PPUCTRL_I) ? 32 : 1;
		p->reg_v = (p->reg_v + incr) & (0x4000 - 1);
		break;

	default:
		val = p->regs[reg];
		break;
	}

	return val;
}

void ppu_write(ppu_context *p, uint16_t addr, uint8_t val)
{
	uint16_t vaddr;
	uint8_t reg;
	int incr;

	if (addr < 0x2000 || addr > 0x3FFF)
		assert("ppu: address out of range");

	reg = (addr - 0x2000) & (8-1);

	switch (reg) {
	case REG_PPUSCROLL:
		if (p->reg_w == 0) {
			/* First write */
            //整体效果是将val的低3位放到reg_x中，高5位作为reg_t的低5位
			p->reg_t &= ~0x1f;//取reg_t的高3位，低5位置0
			p->reg_t |= (val >> 3);//取val的高5位，低3位去掉（右移动3位），并与reg_t作按位或运算。
			p->reg_x = (val & 7);//取val的后3位，并赋值给reg_x
		} else {
			/* Second write */
			p->reg_t &= ~(0x1f << 5);//取reg_t的低5位，即第一次写的val的高5位
			p->reg_t |= ((uint16_t)val >> 3) << 5;//删除val的低3位和高2位，空出低5位，与reg_t作按位或运算
			p->reg_t &= ~(0x7 << 12);//取reg_t的低12位
			p->reg_t |= ((uint16_t)val & 0x7) << 12;//取val的低3位，作为reg_t的高4位
		}
		p->reg_w ^= 1;//写2次的跳动,0->1->0
		p->regs[reg] = val;//regs中是第二次写的val数值
		break;

	case REG_PPUADDR:
		if (p->reg_w == 0) {
			/* First write */
			p->reg_t &= ~(0x3f << 8);
			p->reg_t |= ((uint16_t)val & 0x3f) << 8;
			p->reg_t &= ~(1 << 14);//取低14位
		} else {
			/* Second write */
			p->reg_t &= ~0xff;
			p->reg_t |= val;//第二次的val作为vram地址的低8位
			p->reg_v = p->reg_t;//赋值给vram地址，临时地址作为正式地址
		}
		p->reg_w ^= 1;//写2次的跳动,0->1->0
		p->regs[reg] = val;
		break;

	case REG_PPUCTRL:
		p->regs[reg] = val;
		p->reg_t &= ~(0x3 << 10);//取后10位
		p->reg_t |= ((uint16_t)val & 0x3) << 10;//取val的低2位（Name Table Address）

		break;

	case REG_PPUDATA:
		vaddr = p->reg_v & (0x4000 - 1);

		p->write8(vaddr, val);
            
        //每读一次或写一次reg_v地址增加1或者32
		incr = (p->regs[REG_PPUCTRL] & PPUCTRL_I) ? 32 : 1;
		p->reg_v = (p->reg_v + incr) & (0x4000 - 1);

		break;

	case REG_OAMADDR:
		p->oamaddr = val;
		p->regs[reg] = val;
		break;

	case REG_OAMDATA:
		p->oam[p->oamaddr] = val;
		p->oamaddr = (p->oamaddr + 1) & (256 - 1);//地址加1，位第二次写入做准备
		p->regs[reg] = val;
		break;

	case REG_PPUSTATUS:
		break;

	default:
		p->regs[reg] = val;
		break;

	}
}

static uint8_t ppu_get_cs_for_bgpixel(uint8_t attr, unsigned int x, unsigned int y)
{
	if ((x & 0x1f) < 16 && (y & 0x1f) < 16)
		return (attr >> 0) & 0x3;	/* top left */
	else if ((x & 0x1f) < 16 && (y & 0x1f) >= 16)
		return (attr >> 4) & 0x3;	/* bottom left */
	else if ((x & 0x1f) >= 16 && (y & 0x1f) < 16)
		return (attr >> 2) & 0x3;	/* top right */
	else
		return (attr >> 6) & 0x3;	/* bottom right */
}

//获取某条扫描线需要绘制的精灵
static void ppu_get_sprites(ppu_context *p, unsigned int y)
{
	/* Sprite height (8 or 16 pixels) */
	const uint16_t sprite_height = (p->regs[REG_PPUCTRL] & PPUCTRL_H) ? 16 : 8;

	p->scanline_num_sprites = 0;

	for (int n = 0; n < 64 && p->scanline_num_sprites < 8; n++) {
		const uint8_t sprite_y = p->oam[n * 4 + 0] + 1;//精灵的左上角坐标y值+1

        if (sprite_y == 0 || sprite_y >= 0xf0){
			continue;//过滤显示不全的精灵，有效范围是[0,238]，超出范围不显示
        }

        if (y >= sprite_y && y < sprite_y + sprite_height){//扫描线穿过精灵，则改精灵需要进行渲染
			p->scanline_sprites[p->scanline_num_sprites++] = n;//存放精灵在oam的下标索引
        }
	}
}

//像素绘制函数
static void ppu_put_pixel(ppu_context *p, unsigned int x, unsigned int y)
{

	/* Rendering control flags */
	const int show_background = (p->regs[REG_PPUMASK] & PPUMASK_b) != 0;
	const int show_sprites = (p->regs[REG_PPUMASK] & PPUMASK_s) != 0;

	/* Palette address */
	const uint16_t pal_start = 0x3f00;//调色板基地址

	if (show_background) {

		/* Colour set */
		const uint8_t cs = (p->attr >> 30) & 3;//调色板编号

		/* Palette entry */
		const int bit = 1 << (15 - p->reg_x);
		const uint8_t pal = ((p->tile_l & bit) ? 1 : 0) |
				    ((p->tile_h & bit) ? 2 : 0);//调色板内的颜色编号

        //删除对应的缓存数据位
		p->tile_l <<= 1;
		p->tile_h <<= 1;
		p->attr <<= 2;

		if (x <= 0xff) {//绘制可视区域扫描线
			p->pixels[y][x].pal = pal;
			p->pixels[y][x].has_sprite = 0;

			if (pal) {
				p->pixels[y][x].priority = PPU_PRIO_BG;

				p->pixels[y][x].c = p->read8(pal_start + (cs * 4) + pal) & 0x3f;//真实的系统调色板颜色索引
			} else {
				/* Default background colour */
				p->pixels[y][x].priority = PPU_PRIO_NONE;
				p->pixels[y][x].c = p->read8(pal_start) & 0x3f;//系统默认背景颜色
			}

			if (x < 8 && (p->regs[REG_PPUMASK] & PPUMASK_m) == 0) {
				/* Hide background in leftmost 8 pixels */
				p->pixels[y][x].priority = PPU_PRIO_NONE;
				p->pixels[y][x].pal = 0;
				p->pixels[y][x].c = p->read8(pal_start) & 0x3f;
			}
		}
	} else {
		if (x <= 0xff) {
			p->pixels[y][x].priority = PPU_PRIO_NONE;
			p->pixels[y][x].pal = 0;
			p->pixels[y][x].c = p->read8(pal_start) & 0x3f;
			p->pixels[y][x].has_sprite = 0;
		}
	}

	if (x > 0xff)
		return;

	if (show_sprites) {
		/* Sprite height (8 or 16 pixels) */
		const uint16_t sprite_height = (p->regs[REG_PPUCTRL] & PPUCTRL_H) ? 16 : 8;

		for (int i = 0; i < p->scanline_num_sprites; i++) {
			const int n = p->scanline_sprites[i];//获取精灵oam中的下标索引
			const uint8_t sprite_y = p->oam[n * 4 + 0] + 1;
			const uint8_t sprite_x = p->oam[n * 4 + 3];

            //过滤Y显示不全的精灵
			if (sprite_y == 0 || sprite_y >= 0xf0)
				continue;

            //过滤不在精灵X范围的像素绘制
			if (x < sprite_x || x >= sprite_x + 8)
				continue;

			const unsigned int xrel = x - sprite_x;
			const unsigned int yrel = y - sprite_y;
			const uint8_t sprite_tile = p->oam[n * 4 + 1];
			const uint8_t sprite_attr = p->oam[n * 4 + 2];

			/* Horizontal flip flag */
			const int flip_h = (sprite_attr & 0x40) != 0;
			/* Vertical flip flag */
			const int flip_v = (sprite_attr & 0x80) != 0;
			/* Priority */
			const int priority = (sprite_attr & 0x20) != 0 ? PPU_PRIO_BEHIND : PPU_PRIO_FRONT;

			/* Sprite pattern table address */
			const uint16_t pat_start = sprite_height == 8 ?
			    ((p->regs[REG_PPUCTRL] & PPUCTRL_S) ? 0x1000 : 0x0000) :
			    (sprite_tile & 1) << 12;

			/* Sprite tile start */
			const uint16_t sprite_tile_start = sprite_height == 8 ?
			    sprite_tile : (sprite_tile & 0xfe);

			/* Offset of pattern table entry (low) */
			uint16_t pat_off = sprite_tile_start * 16 +
			    (flip_v ? ((sprite_height - 1) - (yrel & (sprite_height - 1))) : (yrel & (sprite_height - 1)));
			if (yrel >= 8)
				pat_off += 8;
			if (sprite_height == 16 && flip_v) {
				if (yrel >= 8)
					pat_off -= 8;
				else
					pat_off += 8;
			}

			/* Pattern table entry */
			const uint8_t pat_l = p->read8(pat_start + pat_off);
			const uint8_t pat_h = p->read8(pat_start + pat_off + 8);
			/* Bit in pattern table */
			const int bit = flip_h ? (xrel & 7) : 7 - (xrel & 7);
			/* Palette entry */
			const uint8_t pal = ((pat_l & (1 << bit)) ? 1 : 0) |
					    ((pat_h & (1 << bit)) ? 2 : 0);//获取真实的像素点深度,调色板内的颜色编号

			/*
			 * When a nonzero pixel of sprite 0 overlaps a nonzero background pixel,
			 * set the Sprite 0 Hit flag in PPUSTATUS
			 */
			if (n == 0 && p->pixels[y][x].pal != 0 && pal != 0) {
				if (p->sprite0_hit == 0) {//Sprite 0 Hit
					p->regs[REG_PPUSTATUS] |= PPUSTATUS_S;
					p->sprite0_hit = 1;
				}
			}

			/* Non-transparent back-priority sprites with a lower sprite index have a higher priority */
			if (p->pixels[y][x].has_sprite)
				continue;
			if (pal)
				p->pixels[y][x].has_sprite = 1;

			/* Skip pixels in front of this one. If sprites overlap, the lower numbered sprite wins. */
			if (priority <= p->pixels[y][x].priority || pal == 0)
				continue;

			/* Colour set */
			const uint8_t cs = (sprite_attr & 0x3) + 4;

			p->pixels[y][x].priority = priority;
			p->pixels[y][x].pal = pal;
			p->pixels[y][x].c = p->read8(pal_start + (cs * 4) + pal) & 0x3f;//获取真实的系统调色板索引数值

			/* Emulate sprite priority quirk; visible sprites with the lowest OAM index win regardless of front/back priority */
			break;
		}
	}
}

//渲染资源更新函数
static void ppu_fetch(ppu_context *p)
{
	/* Nametable entry */
	const uint8_t nt = p->read8(PPU_TILE_ADDR(p->reg_v));//reg_v地址的低12位为nametable地址，首位加上2

	/* Fine Y scroll */
	const uint8_t fine_y = p->reg_v >> 12;//reg_v地址的高4位为fine_y数值
	const uint8_t fine_x = p->reg_x;//reg_x存放fine_x

	/* X/Y scroll positions */
	const int xscroll = ((p->reg_v & 0x1f) << 3) | fine_x;
	const int yscroll = (((p->reg_v >> 5) & 0x1f) << 3) | fine_y;

	/* Attribute table entry */
	uint16_t attr = 0;
	uint8_t curattr = p->read8(PPU_ATTR_ADDR(p->reg_v));
	for (int i = 0; i < 8; i++) {
		if (i == (8 - p->reg_x))
			curattr = p->read8(PPU_ATTR_ADDR(ppu_incr_x(p)));
		attr <<= 2;
		attr |= ppu_get_cs_for_bgpixel(curattr, xscroll + i, yscroll);
	}
	p->attr |= attr;//设置attr

	/* Pattern table start offset */
	const uint16_t pat_start = (p->regs[REG_PPUCTRL] & PPUCTRL_B) ? 0x1000 : 0x0000;

	/* Offset of pattern table entry (low) */
	const uint16_t pat_off = (uint16_t)nt * 16 + (p->reg_v >> 12);
			
	/* Pattern table entry */
	p->tile_l |= p->read8(pat_start + pat_off);//设置tile
	p->tile_h |= p->read8(pat_start + pat_off + 8);

	p->reg_v = ppu_incr_x(p);//vram地址增加
}

int ppu_step(ppu_context *p)
{
	int ret = 0;

	if (p->frame_ticks == 0) {//时钟周期用完了
        if (p->draw){//绘图
            for (unsigned int y = 0; y < PPU_HEIGHT; y++){
                for (unsigned int x = 0; x < PPU_WIDTH; x++) {
                    p->pallete_index[y][x] = p->pixels[y][x].c;
                }
            }
			p->draw((uint8_t*)p->pallete_index);
        }

		p->frame_ticks = PPU_TICKS_PER_FRAME;//重新分配时钟周期
		if ((p->frame & 1) != 0 || (p->regs[REG_PPUMASK] & PPUMASK_b) != 0) {
			/* Pre-render scanline -1, cycle 0 is skipped for odd[奇数] PPU frames and when the BG is disabled */
			p->frame_ticks -= 1;//Pre-render scanline -1,cycle 0 is skipped
		}

		p->frame++;//帧数加1

		ret = 1;
	} else {
        //每行需要341个tick，总共262行(262条扫描线)
		const unsigned int tick = PPU_TICKS_PER_FRAME - p->frame_ticks;//已经用完的tick数目
		const int scanline = (tick / 341) - 1;//当前扫描线，扫描线从-1开始
		const unsigned int scanline_cycle = tick % 341;//当前扫描线下的第几个tick

		/* Rendering control flags */
        const int show_background = (p->regs[REG_PPUMASK] & PPUMASK_b) != 0;//0:不显示背景，1:显示背景
        const int show_sprites = (p->regs[REG_PPUMASK] & PPUMASK_s) != 0;//0:不显示精灵，1:显示精灵
		const int render_enable = show_background || show_sprites;//只要需要显示背景或者精灵，就需要重新渲染

		if (render_enable && scanline == -1) {
			/* Pre-render scanline */
			if (scanline_cycle == 1) {//1个tick
				/* Clear VBlank, Sprite 0 Hit */
				p->regs[REG_PPUSTATUS] &= ~(PPUSTATUS_S | PPUSTATUS_V);//将ppustatus的6、7位设置0
				p->sprite0_hit = 0;
			} else if (scanline_cycle >= 280 && scanline_cycle <= 304) {//25个tick
				/* Reload vertical scroll position */
				p->reg_v &= ~0x7be0;
				p->reg_v |= (p->reg_t & 0x7be0);//设置vram的地址
			}
		} else if (render_enable && scanline >= 0 && scanline <= 239) {//可视区域的扫描线
			/* Visible scanlines */
			if (scanline_cycle == 0) {//1个tick
				/* Idle cycle */
				ppu_get_sprites(p, scanline);//每条可视扫描线的第0个tick进行精灵获取，每条扫描线下最多8个精灵
			} else if (scanline_cycle >= 1 && scanline_cycle <= 256) {//256个tick
				/* Fetch cycle */
				ppu_put_pixel(p, scanline_cycle - 1, scanline);//每条扫描线像素绘制ticks（256个tick，256个像素点）
			} else if (scanline_cycle >= 257 && scanline_cycle <= 320) {//64个tick
				/* Tile data for sprites on the next scanline are fetched (XXX) */
			} else if (scanline_cycle >= 321 && scanline_cycle <= 336) {//16个tick
				/* First two tiles for the next scanline are fetched (XXX) */
			} else if (scanline_cycle >= 337 && scanline_cycle <= 340) {//4个tick
				/* Two nametable bytes are fetched for unknown purposes (XXX) */
			}
		} else if (scanline == 240) {//1个tick
			/* Post-render scanline */
		} else if (scanline >= 241 && scanline <= 260) {//20个tick
			/* Vertical blanking lines */
			if (scanline == 241 && scanline_cycle == 1) {
				/* Set VBlank flag on second tick of scanline 241 */
				p->regs[REG_PPUSTATUS] |= PPUSTATUS_V;//设置ppustatus的vblank位（7）为1，进入vblank处理

				/* VBlank NMI */
				if (p->regs[REG_PPUCTRL] & PPUCTRL_V) {//如果vblank有效，则进行nmi处理
					cpu_nmi(p->cpu);//调用cpu的nmi中断处理
				}
			}
		}

		if (render_enable && scanline >= -1 && scanline <= 239) {
			if (scanline_cycle > 0 && (scanline_cycle & 7) == 0 && scanline_cycle < 256) {
				ppu_fetch(p);//按照间隔去更新渲染资源（attr和tile）
			}
			if (scanline_cycle == 256) {//1个tick
				p->reg_v = ppu_incr_y(p);//某条扫描线的第256个tick，需要返回到下一行的开始
			}
			if (scanline_cycle == 257) {//1个tick
				/* Reload horizontal scroll position */
				p->reg_v &= ~0x41f;
				p->reg_v |= (p->reg_t & 0x41f);//加载水平移动的位置
			}

			if (scanline_cycle == 321) {//1个tick
				p->tile_l = p->tile_h = 0;
				ppu_fetch(p);//更新渲染资源（attr和tile）
				p->tile_l <<= 8;
				p->tile_h <<= 8;
				p->attr <<= 16;
			} else if (scanline_cycle == 329) {//1个tick
				ppu_fetch(p);//更新渲染资源（attr和tile）
			}
		}

		--p->frame_ticks;//ticks用完，每次减小1
	}

	return ret;
}
