#ifndef NSF_PLAYER_H
#define NSF_PLAYER_H

int main(int argc, char **argv);

#endif  //NSF_PLAYER_H
