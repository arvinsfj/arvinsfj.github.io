#ifndef APU_H_INCLUDED
#define APU_H_INCLUDED

#include <stdint.h>

#include "ccpu.h"

#define SAMPLE_RATE 48000
#define SAMPLE_BITS 16

#ifndef BYTE_TYPE_DEFINED
#define BYTE_TYPE_DEFINED
typedef unsigned char byte;
#endif
#ifndef WORD_TYPE_DEFINED
#define WORD_TYPE_DEFINED
typedef unsigned short word;
#endif

#define APU_NTSC 0
#define APU_PAL 1

#define BIT(v, b) (((v>>b)&1) == 1)

struct apu_s;

struct apu_s* apu_create(int samplerate, byte clockstandard);
void apu_destroy(struct apu_s* apu);
void apu_setcontext(struct apu_s* apu, cpu_context *cpu, void* read8f, void* write8f);
void apu_write(word addr, byte data);
byte apu_read(word addr);
void apu_process(uint32_t cpu_cycles);
int32_t apu_output(void);
void apu_reset(byte snd_mappers);



#endif // APU_H_INCLUDED
