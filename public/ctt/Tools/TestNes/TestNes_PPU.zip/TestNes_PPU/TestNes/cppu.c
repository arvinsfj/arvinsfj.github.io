//
//  cppu.c
//  TestNes
//
//  Created by arvin on 2017/8/16.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#include <assert.h>

#include "cnes.h"
#include "cppu.h"

// NTSC Timing Helper Functions

void ppu_writePalette(ppu_context *ppu, uint16_t address, uint8_t value)
{
    if ((address >= 16) && (address%4 == 0)) {
        address -= 16;
    }
    ppu->paletteData[address] = value;
}

uint8_t ppu_readPalette(ppu_context *ppu, uint16_t address)
{
    if ((address >= 16) && (address%4 == 0)) {
        address -= 16;
    }
    return ppu->paletteData[address];
}

void ppu_incrementX(ppu_context *ppu)
{
    // increment hori(v)
    // if coarse X == 31
    if ((ppu->v&0x001F) == 31) {
        // coarse X = 0
        ppu->v &= 0xFFE0;
        // switch horizontal nametable
        ppu->v ^= 0x0400;
    } else {
        // increment coarse X
        ppu->v++;
    }
}

void ppu_incrementY(ppu_context *ppu)
{
    // increment vert(v)
    // if fine Y < 7
    if ((ppu->v&0x7000) != 0x7000) {
        // increment fine Y
        ppu->v += 0x1000;
    } else {
        // fine Y = 0
        ppu->v &= 0x8FFF;
        // let y = coarse Y
        uint16_t y = (ppu->v & 0x03E0) >> 5;
        if (y == 29) {
            // coarse Y = 0
            y = 0;
            // switch vertical nametable
            ppu->v ^= 0x0800;
        } else if (y == 31) {
            // coarse Y = 0, nametable not switched
            y = 0;
        } else {
            // increment coarse Y
            y++;
        }
        // put coarse Y back into v
        ppu->v = (ppu->v & 0xFC1F) | (y << 5);
    }
}

void ppu_copyX(ppu_context *ppu)
{
    // hori(v) = hori(t)
    // v: .....F.. ...EDCBA = t: .....F.. ...EDCBA
    ppu->v = (ppu->v & 0xFBE0) | (ppu->t & 0x041F);
}

void ppu_copyY(ppu_context *ppu)
{
    // vert(v) = vert(t)
    // v: .IHGF.ED CBA..... = t: .IHGF.ED CBA.....
    ppu->v = (ppu->v & 0x841F) | (ppu->t & 0x7BE0);
}

void ppu_nmiChange(ppu_context *ppu)
{
    char nmi = ppu->nmiOutput && ppu->nmiOccurred;
    if (nmi && !ppu->nmiPrevious) {
        // TODO: this fixes some games but the delay shouldn't have to be so
        // long, so the timings are off somewhere
        ppu->nmiDelay = 15;
    }
    ppu->nmiPrevious = nmi;
}

void ppu_setVerticalBlank(ppu_context *ppu)
{
    //ppu.front, ppu.back = ppu.back, ppu.front//交换front 和 back
    if (ppu->draw) {
        ppu->draw((uint8_t*)ppu->back);
    }
    ppu->nmiOccurred = 1;
    ppu_nmiChange(ppu);
}

void ppu_clearVerticalBlank(ppu_context *ppu)
{
    ppu->nmiOccurred = 0;
    ppu_nmiChange(ppu);
}

void ppu_fetchNameTableByte(ppu_context *ppu)
{
    uint16_t v = ppu->v;
    uint16_t address = 0x2000 | (v & 0x0FFF);
    ppu->nameTableByte = ppu->read8(address);
}

void ppu_fetchAttributeTableByte(ppu_context *ppu)
{
    uint16_t v = ppu->v;
    uint16_t address = 0x23C0 | (v & 0x0C00) | ((v >> 4) & 0x38) | ((v >> 2) & 0x07);
    uint16_t shift = ((v >> 4) & 4) | (v & 2);
    ppu->attributeTableByte = ((ppu->read8(address) >> shift) & 3) << 2;
}

void ppu_fetchLowTileByte(ppu_context *ppu)
{
    uint16_t fineY = (ppu->v >> 12) & 7;
    uint8_t table = ppu->flagBackgroundTable;
    uint8_t tile = ppu->nameTableByte;
    uint16_t address = 0x1000*(uint16_t)(table) + (uint16_t)(tile)*16 + fineY;
    ppu->lowTileByte = ppu->read8(address);
}

void ppu_fetchHighTileByte(ppu_context *ppu)
{
    uint16_t fineY = (ppu->v >> 12) & 7;
    uint8_t table = ppu->flagBackgroundTable;
    uint8_t tile = ppu->nameTableByte;
    uint16_t address = 0x1000*(uint16_t)(table) + (uint16_t)(tile)*16 + fineY;
    ppu->highTileByte = ppu->read8(address + 8);
}

void ppu_storeTileData(ppu_context *ppu)
{
    uint32_t data = 0;
    for (int i = 0; i < 8; i++) {
        uint8_t a = ppu->attributeTableByte;
        uint8_t p1 = (ppu->lowTileByte & 0x80) >> 7;
        uint8_t p2 = (ppu->highTileByte & 0x80) >> 6;
        ppu->lowTileByte <<= 1;
        ppu->highTileByte <<= 1;
        data <<= 4;
        data |= (uint32_t)(a | p1 | p2);
    }
    ppu->tileData |= (uint64_t)(data);
}

uint32_t ppu_fetchTileData(ppu_context *ppu)
{
    return (uint32_t)(ppu->tileData >> 32);
}

uint8_t ppu_backgroundPixel(ppu_context *ppu)
{
    if (ppu->flagShowBackground == 0) {
        return 0;
    }
    uint32_t data = ppu_fetchTileData(ppu) >> ((7 - ppu->x) * 4);
    return (uint8_t)(data & 0x0F);
}

sprite_pixel ppu_spritePixel(ppu_context *ppu)
{
    sprite_pixel sprite = {0, 0};
    if (ppu->flagShowSprites == 0) {
        return sprite;
    }
    for (int i = 0; i < ppu->spriteCount; i++) {
        int offset = (ppu->cycle - 1) - (int)(ppu->spritePositions[i]);
        if (offset < 0 || offset > 7) {
            continue;
        }
        offset = 7 - offset;
        uint8_t color = (uint8_t)((ppu->spritePatterns[i] >> (uint8_t)(offset*4)) & 0x0F);
        if (color%4 == 0) {
            continue;
        }
        sprite.i = i;
        sprite.color = color;
        return sprite;
    }
    return sprite;
}

void ppu_renderPixel(ppu_context *ppu)
{
    uint16_t x = ppu->cycle - 1;
    uint16_t y = ppu->scanLine;
    uint8_t background = ppu_backgroundPixel(ppu);
    sprite_pixel sprite = ppu_spritePixel(ppu);
    if ((x < 8) && (ppu->flagShowLeftBackground == 0)) {
        background = 0;
    }
    if ((x < 8) && (ppu->flagShowLeftSprites == 0)) {
        sprite.color = 0;
    }
    char b = (background%4) != 0;
    char s = (sprite.color%4) != 0;
    uint8_t color = 0;
    if (!b && !s) {
        color = 0;
    } else if (!b && s) {
        color = sprite.color | 0x10;
    } else if (b && !s) {
        color = background;
    } else {
        if ((ppu->spriteIndexes[sprite.i] == 0) && (x < 255)) {
            ppu->flagSpriteZeroHit = 1;
        }
        if (ppu->spritePriorities[sprite.i] == 0) {
            color = sprite.color | 0x10;
        } else {
            color = background;
        }
    }
    ppu->back[y][x] = ppu_readPalette(ppu, (uint16_t)(color))%64;
}

uint32_t ppu_fetchSpritePattern(ppu_context *ppu, int i, int row)
{
    uint8_t tile = ppu->oamData[i*4+1];
    uint8_t attributes = ppu->oamData[i*4+2];
    uint16_t address;
    if (ppu->flagSpriteSize == 0) {
        if ((attributes&0x80) == 0x80) {
            row = 7 - row;
        }
        uint8_t table = ppu->flagSpriteTable;
        address = 0x1000*(uint16_t)(table) + (uint16_t)(tile)*16 + (uint16_t)(row);
    } else {
        if ((attributes&0x80) == 0x80) {
            row = 15 - row;
        }
        uint8_t table = tile & 1;
        tile &= 0xFE;
        if (row > 7) {
            tile++;
            row -= 8;
        }
        address = 0x1000*(uint16_t)(table) + (uint16_t)(tile)*16 + (uint16_t)(row);
    }
    uint8_t a = (attributes & 3) << 2;
    uint8_t lowTileByte = ppu->read8(address);
    uint8_t highTileByte = ppu->read8(address + 8);
    uint32_t data = 0;
    for (int i = 0; i < 8; i++) {
        uint8_t p1 = 0, p2 = 0;
        if ((attributes&0x40) == 0x40) {
            p1 = (lowTileByte & 1) << 0;
            p2 = (highTileByte & 1) << 1;
            lowTileByte >>= 1;
            highTileByte >>= 1;
        } else {
            p1 = (lowTileByte & 0x80) >> 7;
            p2 = (highTileByte & 0x80) >> 6;
            lowTileByte <<= 1;
            highTileByte <<= 1;
        }
        data <<= 4;
        data |= (uint32_t)(a | p1 | p2);
    }
    return data;
}

void ppu_evaluateSprites(ppu_context *ppu)
{
    int h = 0;
    if (ppu->flagSpriteSize == 0) {
        h = 8;
    } else {
        h = 16;
    }
    uint16_t count = 0;
    for (int i = 0; i < 64; i++) {
        uint8_t y = ppu->oamData[i*4+0];
        uint8_t a = ppu->oamData[i*4+2];
        uint8_t x = ppu->oamData[i*4+3];
        int row = ppu->scanLine - (int)(y);
        if (row < 0 || row >= h) {
            continue;
        }
        if (count < 8) {
            ppu->spritePatterns[count] = ppu_fetchSpritePattern(ppu, i, row);
            ppu->spritePositions[count] = x;
            ppu->spritePriorities[count] = (a >> 5) & 1;
            ppu->spriteIndexes[count] = (uint8_t)(i);
        }
        count++;
    }
    if (count > 8) {
        count = 8;
        ppu->flagSpriteOverflow = 1;
    }
    ppu->spriteCount = count;
}

// tick updates Cycle, ScanLine and Frame counters
void ppu_tick(ppu_context *ppu)
{
    if (ppu->nmiDelay > 0) {
        ppu->nmiDelay--;
        if ((ppu->nmiDelay == 0) && ppu->nmiOutput && ppu->nmiOccurred) {
            cpu_nmi(ppu->cpu);
        }
    }
    
    if ((ppu->flagShowBackground != 0) || (ppu->flagShowSprites != 0)) {
        if ((ppu->f == 1) && (ppu->scanLine == 261) && (ppu->cycle == 339)) {
            ppu->cycle = 0;
            ppu->scanLine = 0;
            ppu->frame++;
            ppu->f ^= 1;
            return;
        }
    }
    ppu->cycle++;
    if (ppu->cycle > 340) {
        ppu->cycle = 0;
        ppu->scanLine++;
        if (ppu->scanLine > 261) {
            ppu->scanLine = 0;
            ppu->frame++;
            ppu->f ^= 1;
        }
    }
}

// Step executes a single PPU cycle
void ppu_step_i(ppu_context *ppu)
{
    ppu_tick(ppu);
    
    char renderingEnabled = (ppu->flagShowBackground != 0) || (ppu->flagShowSprites != 0);
    char preLine = ppu->scanLine == 261;
    char visibleLine = ppu->scanLine < 240;
    // postLine := ppu.ScanLine == 240
    char renderLine = preLine || visibleLine;
    char preFetchCycle = (ppu->cycle >= 321) && (ppu->cycle <= 336);
    char visibleCycle = (ppu->cycle >= 1) && (ppu->cycle <= 256);
    char fetchCycle = preFetchCycle || visibleCycle;
    
    // background logic
    if (renderingEnabled) {
        if (visibleLine && visibleCycle) {
            ppu_renderPixel(ppu);
        }
        if (renderLine && fetchCycle) {
            ppu->tileData <<= 4;
            switch (ppu->cycle % 8) {
                case 1:
                    ppu_fetchNameTableByte(ppu);
                    break;
                case 3:
                    ppu_fetchAttributeTableByte(ppu);
                    break;
                case 5:
                    ppu_fetchLowTileByte(ppu);
                    break;
                case 7:
                    ppu_fetchHighTileByte(ppu);
                    break;
                case 0:
                    ppu_storeTileData(ppu);
                    break;
                default:
                    break;
            }
        }
        if (preLine && (ppu->cycle >= 280) && (ppu->cycle <= 304)) {
            ppu_copyY(ppu);
        }
        if (renderLine) {
            if (fetchCycle && ((ppu->cycle%8) == 0)) {
                ppu_incrementX(ppu);
            }
            if (ppu->cycle == 256) {
                ppu_incrementY(ppu);
            }
            if (ppu->cycle == 257) {
                ppu_copyX(ppu);
            }
        }
    }
    
    // sprite logic
    if (renderingEnabled) {
        if (ppu->cycle == 257) {
            if (visibleLine) {
                ppu_evaluateSprites(ppu);
            } else {
                ppu->spriteCount = 0;
            }
        }
    }
    
    // vblank logic
    if ((ppu->scanLine == 241) && (ppu->cycle == 1)) {
        ppu_setVerticalBlank(ppu);
    }
    if (preLine && (ppu->cycle == 1)) {
        ppu_clearVerticalBlank(ppu);
        ppu->flagSpriteZeroHit = 0;
        ppu->flagSpriteOverflow = 0;
    }
}

// $2000: PPUCTRL
void ppu_writeControl(ppu_context *ppu, uint8_t value)
{
    ppu->flagNameTable = (value >> 0) & 3;
    ppu->flagIncrement = (value >> 2) & 1;
    ppu->flagSpriteTable = (value >> 3) & 1;
    ppu->flagBackgroundTable = (value >> 4) & 1;
    ppu->flagSpriteSize = (value >> 5) & 1;
    ppu->flagMasterSlave = (value >> 6) & 1;
    ppu->nmiOutput = ((value>>7)&1) == 1;
    ppu_nmiChange(ppu);
    // t: ....BA.. ........ = d: ......BA
    ppu->t = (ppu->t & 0xF3FF) | (((uint16_t)(value) & 0x03) << 10);
}

// $2001: PPUMASK
void ppu_writeMask(ppu_context *ppu, uint8_t value)
{
    ppu->flagGrayscale = (value >> 0) & 1;
    ppu->flagShowLeftBackground = (value >> 1) & 1;
    ppu->flagShowLeftSprites = (value >> 2) & 1;
    ppu->flagShowBackground = (value >> 3) & 1;
    ppu->flagShowSprites = (value >> 4) & 1;
    ppu->flagRedTint = (value >> 5) & 1;
    ppu->flagGreenTint = (value >> 6) & 1;
    ppu->flagBlueTint = (value >> 7) & 1;
}

// $2002: PPUSTATUS
uint8_t ppu_readStatus(ppu_context *ppu)
{
    uint8_t result = ppu->regist & 0x1F;
    result |= ppu->flagSpriteOverflow << 5;
    result |= ppu->flagSpriteZeroHit << 6;
    if (ppu->nmiOccurred) {
        result |= 1 << 7;
    }
    ppu->nmiOccurred = 0;
    ppu_nmiChange(ppu);
    // w:                   = 0
    ppu->w = 0;
    return result;
}

// $2003: OAMADDR
void ppu_writeOAMAddress(ppu_context *ppu, uint8_t value)
{
    ppu->oamAddress = value;
}

// $2004: OAMDATA (read)
uint8_t ppu_readOAMData(ppu_context *ppu)
{
    return ppu->oamData[ppu->oamAddress];
}

// $2004: OAMDATA (write)
void ppu_writeOAMData(ppu_context *ppu, uint8_t value)
{
    ppu->oamData[ppu->oamAddress] = value;
    ppu->oamAddress++;
}

// $2005: PPUSCROLL
void ppu_writeScroll(ppu_context *ppu, uint8_t value)
{
    if (ppu->w == 0) {
        // t: ........ ...HGFED = d: HGFED...
        // x:               CBA = d: .....CBA
        // w:                   = 1
        ppu->t = (ppu->t & 0xFFE0) | ((uint16_t)(value) >> 3);
        ppu->x = value & 0x07;
        ppu->w = 1;
    } else {
        // t: .CBA..HG FED..... = d: HGFEDCBA
        // w:                   = 0
        ppu->t = (ppu->t & 0x8FFF) | (((uint16_t)(value) & 0x07) << 12);
        ppu->t = (ppu->t & 0xFC1F) | (((uint16_t)(value) & 0xF8) << 2);
        ppu->w = 0;
    }
}

// $2006: PPUADDR
void ppu_writeAddress(ppu_context *ppu, uint8_t value)
{
    if (ppu->w == 0) {
        // t: ..FEDCBA ........ = d: ..FEDCBA
        // t: .X...... ........ = 0
        // w:                   = 1
        ppu->t = (ppu->t & 0x80FF) | (((uint16_t)(value) & 0x3F) << 8);
        ppu->w = 1;
    } else {
        // t: ........ HGFEDCBA = d: HGFEDCBA
        // v                    = t
        // w:                   = 0
        ppu->t = (ppu->t & 0xFF00) | (uint16_t)(value);
        ppu->v = ppu->t;
        ppu->w = 0;
    }
}

// $2007: PPUDATA (read)
uint8_t ppu_readData(ppu_context *ppu)
{
    uint8_t value = ppu->read8(ppu->v);
    // emulate buffered reads
    if ((ppu->v%0x4000) < 0x3F00) {
        uint8_t buffered = ppu->bufferedData;
        ppu->bufferedData = value;
        value = buffered;
    } else {
        ppu->bufferedData = ppu->read8(ppu->v - 0x1000);
    }
    // increment address
    if (ppu->flagIncrement == 0) {
        ppu->v += 1;
    } else {
        ppu->v += 32;
    }
    return value;
}

// $2007: PPUDATA (write)
void ppu_writeData(ppu_context *ppu, uint8_t value)
{
    ppu->write8(ppu->v, value);
    if (ppu->flagIncrement == 0) {
        ppu->v += 1;
    } else {
        ppu->v += 32;
    }
}

// $4014: OAMDMA
void ppu_writeDMA(ppu_context *ppu, uint8_t value)
{
    cpu_context *cpu = ppu->cpu;
    uint16_t address = (uint16_t)(value) << 8;
    for (int i = 0; i < 256; i++) {
        ppu->oamData[ppu->oamAddress] = cpu->read8(address);
        ppu->oamAddress++;
        address++;
    }
    cpu->stall += 513;
    if ((cpu->cycles%2) == 1) {
        cpu->stall++;
    }
}

void ppu_write_r(ppu_context *ppu, uint16_t address, uint8_t value)
{
    ppu->regist = value;
    switch (address) {
        case 0x2000:
            ppu_writeControl(ppu, value);
            break;
        case 0x2001:
            ppu_writeMask(ppu, value);
            break;
        case 0x2003:
            ppu_writeOAMAddress(ppu, value);
            break;
        case 0x2004:
            ppu_writeOAMData(ppu, value);
            break;
        case 0x2005:
            ppu_writeScroll(ppu, value);
            break;
        case 0x2006:
            ppu_writeAddress(ppu, value);
            break;
        case 0x2007:
            ppu_writeData(ppu, value);
            break;
        case 0x4014:
            ppu_writeDMA(ppu, value);
            break;
        default:
            break;
    }
}

uint8_t ppu_read_r(ppu_context *ppu, uint16_t address)
{
    switch (address) {
        case 0x2002:
            return ppu_readStatus(ppu);
        case 0x2004:
            return ppu_readOAMData(ppu);
        case 0x2007:
            return ppu_readData(ppu);
        default:
            break;
    }
    return 0;
}

void ppu_reset(ppu_context *ppu)
{
    ppu->cycle = 340;
    ppu->scanLine = 240;
    ppu->frame = 0;
    ppu_writeControl(ppu, 0);
    ppu_writeMask(ppu, 0);
    ppu_writeOAMAddress(ppu, 0);
}

//对外接口
void ppu_init(ppu_context *ppu)
{
    ppu_reset(ppu);
}

void ppu_step(ppu_context *ppu)
{
    ppu_step_i(ppu);
}

uint8_t ppu_read(ppu_context *ppu, uint16_t addr)
{
    return ppu_read_r(ppu, addr);
}

void ppu_write(ppu_context *ppu, uint16_t addr, uint8_t value)
{
    ppu_write_r(ppu, addr, value);
}







