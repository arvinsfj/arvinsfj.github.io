//
//  cppu.h
//  TestNes
//
//  Created by arvin on 2017/8/16.
//  Copyright © 2017年 com.fuwo. All rights reserved.
//

#ifndef cppu_h
#define cppu_h

#define    PPU_WIDTH        256
#define    PPU_HEIGHT       240

typedef struct
{
    uint8_t i;
    uint8_t color;
    
} sprite_pixel;


typedef struct
{
    uint64_t frame_ticks;//test
    int cycle;         // 0-340
    int scanLine;      // 0-261, 0-239=visible, 240=post, 241-260=vblank, 261=pre
    uint64_t frame;         // frame counter
    
    // storage variables
    uint8_t paletteData[32];
    uint8_t nameTableData[2048];
    uint8_t oamData[256];
    uint8_t front[PPU_HEIGHT][PPU_WIDTH];
    uint8_t back[PPU_HEIGHT][PPU_WIDTH];
    
    // PPU registers
    uint16_t v; // current vram address (15 bit)
    uint16_t t; // temporary vram address (15 bit)
    uint8_t x;   // fine x scroll (3 bit)
    uint8_t w;   // write toggle (1 bit)
    uint8_t f;   // even/odd frame flag (1 bit)
    
    uint8_t regist;
    
    // NMI flags
    char nmiOccurred;
    char nmiOutput;
    char nmiPrevious;
    uint8_t nmiDelay;
    
    // background temporary variables
    uint8_t nameTableByte;
    uint8_t attributeTableByte;
    uint8_t lowTileByte;
    uint8_t highTileByte;
    uint64_t tileData;
    
    // sprite temporary variables
    int spriteCount;
    uint32_t spritePatterns[8];
    uint8_t spritePositions[8];
    uint8_t spritePriorities[8];
    uint8_t spriteIndexes[8];
    
    // $2000 PPUCTRL
    uint8_t flagNameTable; // 0: $2000; 1: $2400; 2: $2800; 3: $2C00
    uint8_t flagIncrement; // 0: add 1; 1: add 32
    uint8_t flagSpriteTable; // 0: $0000; 1: $1000; ignored in 8x16 mode
    uint8_t flagBackgroundTable; // 0: $0000; 1: $1000
    uint8_t flagSpriteSize; // 0: 8x8; 1: 8x16
    uint8_t flagMasterSlave; // 0: read EXT; 1: write EXT
    
    // $2001 PPUMASK
    uint8_t flagGrayscale; // 0: color; 1: grayscale
    uint8_t flagShowLeftBackground; // 0: hide; 1: show
    uint8_t flagShowLeftSprites; // 0: hide; 1: show
    uint8_t flagShowBackground; // 0: hide; 1: show
    uint8_t flagShowSprites; // 0: hide; 1: show
    uint8_t flagRedTint; // 0: normal; 1: emphasized
    uint8_t flagGreenTint; // 0: normal; 1: emphasized
    uint8_t flagBlueTint; // 0: normal; 1: emphasized
    
    // $2002 PPUSTATUS
    uint8_t flagSpriteZeroHit;
    uint8_t flagSpriteOverflow;
    
    // $2003 OAMADDR
    uint8_t oamAddress;
    
    // $2007 PPUDATA
    uint8_t bufferedData; // for buffered reads
    
    cpu_context *cpu;
    void (*draw)(uint8_t *);
    uint8_t (*read8)(uint16_t);
    void (*write8)(uint16_t, uint8_t);
    
} ppu_context;

void    ppu_init(ppu_context *);
void    ppu_step(ppu_context *);
uint8_t ppu_read(ppu_context *, uint16_t);
void    ppu_write(ppu_context *, uint16_t, uint8_t);

#endif /* cppu_h */
