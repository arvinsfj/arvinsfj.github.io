//
//  main.m
//  TestNESiOS
//
//  Created by arvin on 8/25/17.
//  Copyright © 2017 arvin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

#include "SDL_main.h"

#include "cnes.h"


int main(int argc, char * argv[]) {
    /*
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }*/
    
    NSString* path = [[NSBundle mainBundle] pathForResource:@"ahdl" ofType:@"nes"];
    
    if (argc < 2) {
        printf("Please enter a rom name!!!\n");
        return 0;
    }
    
    cnes_init([path UTF8String]);
    
    return 0;
}
